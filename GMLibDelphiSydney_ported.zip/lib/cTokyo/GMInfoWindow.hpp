﻿// CodeGear C++Builder
// Copyright (c) 1995, 2020 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMInfoWindow.pas' rev: 34.00 (Windows)

#ifndef GminfowindowHPP
#define GminfowindowHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <GMLinkedComponents.hpp>
#include <GMClasses.hpp>
#include <GMMap.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gminfowindow
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TInfoWindow;
class DELPHICLASS TInfoWindows;
class DELPHICLASS TGMInfoWindow;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TInfoWindow : public Gmlinkedcomponents::TLinkedComponent
{
	typedef Gmlinkedcomponents::TLinkedComponent inherited;
	
private:
	Gmclasses::TLatLng* FPosition;
	bool FAutoOpen;
	System::UnicodeString __fastcall GetContent();
	bool __fastcall GetDisableAutoPan();
	int __fastcall GetMaxWidth();
	Gmclasses::TGMSize* __fastcall GetPixelOffset();
	bool __fastcall GetCloseOtherBeforeOpen();
	void __fastcall SetContent(const System::UnicodeString Value);
	void __fastcall SetDisableAutoPan(const bool Value);
	void __fastcall SetMaxWidth(const int Value);
	void __fastcall SetPixelOffset(Gmclasses::TGMSize* const Value);
	void __fastcall SetCloseOtherBeforeOpen(const bool Value);
	void __fastcall OnPositionChange(System::TObject* Sender);
	
protected:
	virtual System::UnicodeString __fastcall GetDisplayName();
	virtual bool __fastcall ChangeProperties();
	
public:
	__fastcall virtual TInfoWindow(System::Classes::TCollection* Collection);
	__fastcall virtual ~TInfoWindow();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	virtual void __fastcall CenterMapTo();
	void __fastcall OpenClose();
	
__published:
	__property System::UnicodeString HTMLContent = {read=GetContent, write=SetContent};
	__property bool DisableAutoPan = {read=GetDisableAutoPan, write=SetDisableAutoPan, nodefault};
	__property int MaxWidth = {read=GetMaxWidth, write=SetMaxWidth, nodefault};
	__property Gmclasses::TGMSize* PixelOffset = {read=GetPixelOffset, write=SetPixelOffset};
	__property bool CloseOtherBeforeOpen = {read=GetCloseOtherBeforeOpen, write=SetCloseOtherBeforeOpen, nodefault};
	__property Gmclasses::TLatLng* Position = {read=FPosition, write=FPosition};
	__property bool AutoOpen = {read=FAutoOpen, write=FAutoOpen, nodefault};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TInfoWindows : public Gmlinkedcomponents::TLinkedComponents
{
	typedef Gmlinkedcomponents::TLinkedComponents inherited;
	
public:
	TInfoWindow* operator[](int I) { return this->Items[I]; }
	
private:
	HIDESBASE TInfoWindow* __fastcall GetItems(int I);
	HIDESBASE void __fastcall SetItems(int I, TInfoWindow* const Value);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	HIDESBASE TInfoWindow* __fastcall Add();
	HIDESBASE TInfoWindow* __fastcall Insert(int Index);
	__property TInfoWindow* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TLinkedComponents.Create */ inline __fastcall virtual TInfoWindows(Gmlinkedcomponents::TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass) : Gmlinkedcomponents::TLinkedComponents(GMLinkedComponent, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TInfoWindows() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TGMInfoWindow : public Gmlinkedcomponents::TGMLinkedComponent
{
	typedef Gmlinkedcomponents::TGMLinkedComponent inherited;
	
public:
	TInfoWindow* operator[](int I) { return this->Items[I]; }
	
private:
	Gmlinkedcomponents::TLatLngIdxEvent FOnPositionChange;
	
protected:
	virtual System::UnicodeString __fastcall GetAPIUrl();
	HIDESBASE TInfoWindow* __fastcall GetItems(int I);
	virtual Gmlinkedcomponents::TLinkedComponentClass __fastcall GetCollectionItemClass();
	virtual Gmlinkedcomponents::TLinkedComponentsClass __fastcall GetCollectionClass();
	
public:
	HIDESBASE TInfoWindow* __fastcall Add(double Lat = 0.000000E+00, double Lng = 0.000000E+00, System::UnicodeString HTMLContent = System::UnicodeString());
	__property TInfoWindow* Items[int I] = {read=GetItems/*, default*/};
	
__published:
	__property VisualObjects;
	__property Gmlinkedcomponents::TLatLngIdxEvent OnPositionChange = {read=FOnPositionChange, write=FOnPositionChange};
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual TGMInfoWindow(System::Classes::TComponent* AOwner) : Gmlinkedcomponents::TGMLinkedComponent(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~TGMInfoWindow() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gminfowindow */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMINFOWINDOW)
using namespace Gminfowindow;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GminfowindowHPP
