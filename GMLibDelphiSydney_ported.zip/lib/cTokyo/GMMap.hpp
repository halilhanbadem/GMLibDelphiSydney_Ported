﻿// CodeGear C++Builder
// Copyright (c) 1995, 2020 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMMap.pas' rev: 34.00 (Windows)

#ifndef GmmapHPP
#define GmmapHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Contnrs.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <GMClasses.hpp>
#include <GMConstants.hpp>
#include <WebControl.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmmap
{
//-- forward type declarations -----------------------------------------------
struct TEventsFired;
struct TEventsMapForm;
struct TEventsMarkerForm;
struct TEventsInfoWindowForm;
struct TEventsPolylineForm;
struct TEventsRectangleForm;
struct TEventsCircleForm;
struct TEventsGOForm;
struct TEventsDirectionForm;
class DELPHICLASS TMapTypeControlOptions;
class DELPHICLASS TOverviewMapControlOptions;
class DELPHICLASS TPanControlOptions;
class DELPHICLASS TRotateControlOptions;
class DELPHICLASS TScaleControlOptions;
class DELPHICLASS TStreetViewControlOptions;
class DELPHICLASS TZoomControlOptions;
class DELPHICLASS TCustomVisualProp;
class DELPHICLASS TRequiredProp;
class DELPHICLASS TNonVisualProp;
class DELPHICLASS TPanoramio;
class DELPHICLASS TPanoramioFeature;
class DELPHICLASS TKml;
class DELPHICLASS TTraffic;
class DELPHICLASS TTransit;
class DELPHICLASS TBicycling;
class DELPHICLASS TWeather;
class DELPHICLASS TWeatherConditions;
class DELPHICLASS TWeatherForecast;
class DELPHICLASS TWeatherFeature;
class DELPHICLASS TLayers;
class DELPHICLASS TStreetView;
class DELPHICLASS TCustomGMMap;
class DELPHICLASS TGMObjects;
//-- type declarations -------------------------------------------------------
struct DECLSPEC_DRECORD TEventsFired
{
public:
	bool Map;
	bool InfoWin;
	bool Marker;
	bool Polyline;
	bool Rectangle;
	bool Circle;
	bool GO;
	bool Direction;
};


struct DECLSPEC_DRECORD TEventsMapForm
{
public:
	bool BoundsChanged;
	bool CenterChanged;
	bool Click;
	bool DblClick;
	bool Drag;
	bool DragEnd;
	bool DragStart;
	bool MapTypeIdChanged;
	bool MouseMove;
	bool MouseOut;
	bool MouseOver;
	bool RightClick;
	bool TilesLoaded;
	bool ZoomChanged;
	double SWLat;
	double SWLng;
	double NELat;
	double NELng;
	double Lat;
	double Lng;
	double X;
	double Y;
	System::UnicodeString MapTypeId;
	int Zoom;
	bool WeatherClick;
	double WeatherLat;
	double WeatherLng;
	System::UnicodeString WeatherFeature;
	bool PanoClick;
	double PanoLat;
	double PanoLng;
	System::UnicodeString PanoAuthor;
	System::UnicodeString PanoPhotoId;
	System::UnicodeString PanoTitle;
	System::UnicodeString PanoUrl;
	System::UnicodeString PanoUserId;
};


struct DECLSPEC_DRECORD TEventsMarkerForm
{
public:
	int LinkCompId;
	int LinkCompZIndex;
	double Lat;
	double Lng;
	bool Click;
	bool DblClick;
	bool Drag;
	bool DragEnd;
	bool DragStart;
	bool MouseDown;
	bool MouseOut;
	bool MouseOver;
	bool MouseUp;
	bool RightClick;
};


struct DECLSPEC_DRECORD TEventsInfoWindowForm
{
public:
	int LinkCompId;
	int LinkCompZIndex;
	bool InfoWinCloseClick;
};


struct DECLSPEC_DRECORD TEventsPolylineForm
{
public:
	int LinkCompId;
	int LinkCompZIndex;
	double Lat;
	double Lng;
	bool Click;
	bool DblClick;
	bool MouseDown;
	bool MouseMove;
	bool MouseOut;
	bool MouseOver;
	bool MouseUp;
	bool RightClick;
};


struct DECLSPEC_DRECORD TEventsRectangleForm
{
public:
	int LinkCompId;
	int LinkCompZIndex;
	double Lat;
	double Lng;
	double NELat;
	double NELng;
	double SWLat;
	double SWLng;
	bool BoundsChange;
	bool Click;
	bool DblClick;
	bool MouseDown;
	bool MouseMove;
	bool MouseOut;
	bool MouseOver;
	bool MouseUp;
	bool RightClick;
};


struct DECLSPEC_DRECORD TEventsCircleForm
{
public:
	int LinkCompId;
	int LinkCompZIndex;
	double Lat;
	double Lng;
	double Radius;
	bool CenterChange;
	bool RadiusChange;
	bool Click;
	bool DblClick;
	bool MouseDown;
	bool MouseMove;
	bool MouseOut;
	bool MouseOver;
	bool MouseUp;
	bool RightClick;
};


struct DECLSPEC_DRECORD TEventsGOForm
{
public:
	int LinkCompId;
	int LinkCompZIndex;
	double Lat;
	double Lng;
	bool Click;
	bool DblClick;
};


struct DECLSPEC_DRECORD TEventsDirectionForm
{
public:
	int LinkCompId;
	int LinkCompZIndex;
	System::UnicodeString XML;
	bool DirectionsChanged;
};


typedef void __fastcall (__closure *TAfterPageLoaded)(System::TObject* Sender, bool First);

typedef void __fastcall (__closure *TBoundsChanged)(System::TObject* Sender, Gmclasses::TLatLngBounds* NewBounds);

typedef void __fastcall (__closure *TLatLngEvent)(System::TObject* Sender, Gmclasses::TLatLng* LatLng, double X, double Y);

typedef void __fastcall (__closure *TMapTypeIdChanged)(System::TObject* Sender, Gmconstants::TMapTypeId NewMapTypeId);

typedef void __fastcall (__closure *TZoomChanged)(System::TObject* Sender, int NewZoom);

typedef void __fastcall (__closure *TWeatherClick)(System::TObject* Sender, Gmclasses::TLatLng* LatLng, TWeatherFeature* FeatureDetails);

typedef void __fastcall (__closure *TPanoramioClick)(System::TObject* Sender, Gmclasses::TLatLng* LatLng, TPanoramioFeature* PanoramioFeature);

#pragma pack(push,4)
class PASCALIMPLEMENTATION TMapTypeControlOptions : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	Gmconstants::TControlPosition FPosition;
	Gmconstants::TMapTypeControlStyle FStyle;
	Gmconstants::TMapTypeIds FMapTypeIds;
	bool FShow;
	
public:
	__fastcall virtual TMapTypeControlOptions();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property Gmconstants::TMapTypeIds MapTypeIds = {read=FMapTypeIds, write=FMapTypeIds, default=31};
	__property Gmconstants::TControlPosition Position = {read=FPosition, write=FPosition, default=11};
	__property Gmconstants::TMapTypeControlStyle Style = {read=FStyle, write=FStyle, default=0};
	__property bool Show = {read=FShow, write=FShow, default=1};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TMapTypeControlOptions() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TOverviewMapControlOptions : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	bool FOpened;
	bool FShow;
	
public:
	__fastcall virtual TOverviewMapControlOptions();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property bool Opened = {read=FOpened, write=FOpened, default=1};
	__property bool Show = {read=FShow, write=FShow, default=1};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TOverviewMapControlOptions() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TPanControlOptions : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	Gmconstants::TControlPosition FPosition;
	bool FShow;
	
public:
	__fastcall virtual TPanControlOptions();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property Gmconstants::TControlPosition Position = {read=FPosition, write=FPosition, default=10};
	__property bool Show = {read=FShow, write=FShow, default=1};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TPanControlOptions() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TRotateControlOptions : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	Gmconstants::TControlPosition FPosition;
	bool FShow;
	
public:
	__fastcall virtual TRotateControlOptions();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property Gmconstants::TControlPosition Position = {read=FPosition, write=FPosition, default=10};
	__property bool Show = {read=FShow, write=FShow, default=1};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TRotateControlOptions() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TScaleControlOptions : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	Gmconstants::TControlPosition FPosition;
	Gmconstants::TScaleControlStyle FStyle;
	bool FShow;
	
public:
	__fastcall virtual TScaleControlOptions();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property Gmconstants::TControlPosition Position = {read=FPosition, write=FPosition, default=1};
	__property Gmconstants::TScaleControlStyle Style = {read=FStyle, write=FStyle, default=0};
	__property bool Show = {read=FShow, write=FShow, default=1};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TScaleControlOptions() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TStreetViewControlOptions : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	Gmconstants::TControlPosition FPosition;
	bool FShow;
	
public:
	__fastcall virtual TStreetViewControlOptions();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property Gmconstants::TControlPosition Position = {read=FPosition, write=FPosition, default=10};
	__property bool Show = {read=FShow, write=FShow, default=1};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TStreetViewControlOptions() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TZoomControlOptions : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	Gmconstants::TControlPosition FPosition;
	Gmconstants::TZoomControlStyle FStyle;
	bool FShow;
	
public:
	__fastcall virtual TZoomControlOptions();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property Gmconstants::TControlPosition Position = {read=FPosition, write=FPosition, default=10};
	__property Gmconstants::TZoomControlStyle Style = {read=FStyle, write=FStyle, default=0};
	__property bool Show = {read=FShow, write=FShow, default=1};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TZoomControlOptions() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomVisualProp : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TMapTypeControlOptions* FMapTypeCtrl;
	TOverviewMapControlOptions* FOverviewMapCtrl;
	TPanControlOptions* FPanCtrl;
	TRotateControlOptions* FRotateCtrl;
	TScaleControlOptions* FScaleCtrl;
	TStreetViewControlOptions* FStreetViewCtrl;
	TZoomControlOptions* FZoomCtrl;
	
protected:
	virtual System::UnicodeString __fastcall ToStr();
	virtual System::UnicodeString __fastcall GetBckgroundColor() = 0 ;
	
public:
	__fastcall virtual TCustomVisualProp();
	__fastcall virtual ~TCustomVisualProp();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property TMapTypeControlOptions* MapTypeCtrl = {read=FMapTypeCtrl, write=FMapTypeCtrl};
	__property TOverviewMapControlOptions* OverviewMapCtrl = {read=FOverviewMapCtrl, write=FOverviewMapCtrl};
	__property TPanControlOptions* PanCtrl = {read=FPanCtrl, write=FPanCtrl};
	__property TRotateControlOptions* RotateCtrl = {read=FRotateCtrl, write=FRotateCtrl};
	__property TScaleControlOptions* ScaleCtrl = {read=FScaleCtrl, write=FScaleCtrl};
	__property TStreetViewControlOptions* StreetViewCtrl = {read=FStreetViewCtrl, write=FStreetViewCtrl};
	__property TZoomControlOptions* ZoomCtrl = {read=FZoomCtrl, write=FZoomCtrl};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TRequiredProp : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	int FZoom;
	Gmconstants::TMapTypeId FMapType;
	TCustomGMMap* FGMMap;
	Gmclasses::TLatLng* FCenter;
	void __fastcall SetMapType(const Gmconstants::TMapTypeId Value);
	void __fastcall SetZoom(const int Value);
	
public:
	__fastcall virtual TRequiredProp(TCustomGMMap* GMMap);
	__fastcall virtual ~TRequiredProp();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property Gmclasses::TLatLng* Center = {read=FCenter, write=FCenter};
	__property Gmconstants::TMapTypeId MapType = {read=FMapType, write=SetMapType, default=1};
	__property int Zoom = {read=FZoom, write=SetZoom, default=8};
};

#pragma pack(pop)

enum DECLSPEC_DENUM TBoolOption : unsigned char { DisableDoubleClickZoom, Draggable, KeyboardShortcuts, NoClear, ScrollWheel };

typedef System::Set<TBoolOption, TBoolOption::DisableDoubleClickZoom, TBoolOption::ScrollWheel> TBoolOptions;

#pragma pack(push,4)
class PASCALIMPLEMENTATION TNonVisualProp : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TBoolOptions FOptions;
	int FMinZoom;
	int FMaxZoom;
	bool FMapMaker;
	void __fastcall SetMaxZoom(const int Value);
	void __fastcall SetMinZoom(const int Value);
	
public:
	__fastcall virtual TNonVisualProp();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property TBoolOptions Options = {read=FOptions, write=FOptions, default=22};
	__property int MaxZoom = {read=FMaxZoom, write=SetMaxZoom, default=0};
	__property int MinZoom = {read=FMinZoom, write=SetMinZoom, default=0};
	__property bool MapMaker = {read=FMapMaker, write=FMapMaker, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TNonVisualProp() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TPanoramio : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TCustomGMMap* FGMMap;
	bool FShow;
	bool FFiltered;
	System::UnicodeString FFilterTag;
	bool FClickable;
	System::UnicodeString FFilterUserId;
	void __fastcall SetShow(const bool Value);
	void __fastcall SetFilterTag(const System::UnicodeString Value);
	void __fastcall SetFiltered(const bool Value);
	void __fastcall SetClickable(const bool Value);
	void __fastcall SetFilterUserId(const System::UnicodeString Value);
	void __fastcall SetOptions();
	
public:
	__fastcall virtual TPanoramio(TCustomGMMap* GMMap);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::UnicodeString FilterTag = {read=FFilterTag, write=SetFilterTag};
	__property System::UnicodeString FilterUserId = {read=FFilterUserId, write=SetFilterUserId};
	__property bool Filtered = {read=FFiltered, write=SetFiltered, default=0};
	__property bool Clickable = {read=FClickable, write=SetClickable, default=1};
	__property bool Show = {read=FShow, write=SetShow, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TPanoramio() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TPanoramioFeature : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FAuthor;
	System::UnicodeString FUserId;
	System::UnicodeString FPhotoId;
	System::UnicodeString FTitle;
	System::UnicodeString FUrl;
	
public:
	__property System::UnicodeString Author = {read=FAuthor};
	__property System::UnicodeString PhotoId = {read=FPhotoId};
	__property System::UnicodeString Title = {read=FTitle};
	__property System::UnicodeString Url = {read=FUrl};
	__property System::UnicodeString UserId = {read=FUserId};
public:
	/* TObject.Create */ inline __fastcall TPanoramioFeature() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TPanoramioFeature() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TKml : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TCustomGMMap* FGMMap;
	bool FShow;
	System::UnicodeString FUrl;
	bool FScreenOverlays;
	bool FSuppressInfoWindows;
	bool FClickable;
	bool FPreserveViewport;
	void __fastcall SetShow(const bool Value);
	void __fastcall SetUrl(const System::UnicodeString Value);
	void __fastcall SetClickable(const bool Value);
	void __fastcall SetPreserveViewport(const bool Value);
	void __fastcall SetScreenOverlays(const bool Value);
	void __fastcall SetSuppressInfoWindows(const bool Value);
	
protected:
	void __fastcall CallJavaScriptFunction();
	
public:
	__fastcall virtual TKml(TCustomGMMap* GMMap);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property bool Clickable = {read=FClickable, write=SetClickable, default=1};
	__property bool PreserveViewport = {read=FPreserveViewport, write=SetPreserveViewport, default=0};
	__property bool ScreenOverlays = {read=FScreenOverlays, write=SetScreenOverlays, default=1};
	__property bool SuppressInfoWindows = {read=FSuppressInfoWindows, write=SetSuppressInfoWindows, default=0};
	__property bool Show = {read=FShow, write=SetShow, default=0};
	__property System::UnicodeString Url = {read=FUrl, write=SetUrl};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TKml() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TTraffic : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TCustomGMMap* FGMMap;
	bool FShow;
	void __fastcall SetShow(const bool Value);
	
public:
	__fastcall virtual TTraffic(TCustomGMMap* GMMap);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property bool Show = {read=FShow, write=SetShow, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TTraffic() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TTransit : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TCustomGMMap* FGMMap;
	bool FShow;
	void __fastcall SetShow(const bool Value);
	
public:
	__fastcall virtual TTransit(TCustomGMMap* GMMap);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property bool Show = {read=FShow, write=SetShow, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TTransit() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TBicycling : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TCustomGMMap* FGMMap;
	bool FShow;
	void __fastcall SetShow(const bool Value);
	
public:
	__fastcall virtual TBicycling(TCustomGMMap* GMMap);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property bool Show = {read=FShow, write=SetShow, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TBicycling() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TWeather : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TCustomGMMap* FGMMap;
	bool FShow;
	Gmconstants::TWindSpeedUnit FWindSpeedUnit;
	Gmconstants::TTemperatureUnit FTemperatureUnit;
	Gmconstants::TLabelColor FLabelColor;
	bool FSuppressInfoWindows;
	bool FClickable;
	void __fastcall SetShow(const bool Value);
	void __fastcall SetClickable(const bool Value);
	void __fastcall SetLabelColor(const Gmconstants::TLabelColor Value);
	void __fastcall SetSuppressInfoWindows(const bool Value);
	void __fastcall SetTemperatureUnit(const Gmconstants::TTemperatureUnit Value);
	void __fastcall SetWindSpeedUnit(const Gmconstants::TWindSpeedUnit Value);
	void __fastcall SetOptions();
	
public:
	__fastcall virtual TWeather(TCustomGMMap* GMMap);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property bool Show = {read=FShow, write=SetShow, default=0};
	__property bool Clickable = {read=FClickable, write=SetClickable, default=1};
	__property Gmconstants::TLabelColor LabelColor = {read=FLabelColor, write=SetLabelColor, default=0};
	__property bool SuppressInfoWindows = {read=FSuppressInfoWindows, write=SetSuppressInfoWindows, default=0};
	__property Gmconstants::TTemperatureUnit TemperatureUnit = {read=FTemperatureUnit, write=SetTemperatureUnit, default=0};
	__property Gmconstants::TWindSpeedUnit WindSpeedUnit = {read=FWindSpeedUnit, write=SetWindSpeedUnit, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TWeather() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TWeatherConditions : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	int FLow;
	int FHumidity;
	int FWindSpeed;
	System::UnicodeString FDay;
	System::UnicodeString FWindDirection;
	int FHigh;
	System::UnicodeString FDescription;
	int FTemperature;
	System::UnicodeString FShortDay;
	
public:
	virtual void __fastcall Assign(System::TObject* Source);
	__property System::UnicodeString Day = {read=FDay};
	__property System::UnicodeString Description = {read=FDescription};
	__property int High = {read=FHigh, nodefault};
	__property int Humidity = {read=FHumidity, nodefault};
	__property int Low = {read=FLow, nodefault};
	__property System::UnicodeString ShortDay = {read=FShortDay};
	__property int Temperature = {read=FTemperature, nodefault};
	__property System::UnicodeString WindDirection = {read=FWindDirection};
	__property int WindSpeed = {read=FWindSpeed, nodefault};
public:
	/* TObject.Create */ inline __fastcall TWeatherConditions() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TWeatherConditions() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TWeatherForecast : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	int FLow;
	System::UnicodeString FDay;
	int FHigh;
	System::UnicodeString FDescription;
	System::UnicodeString FShortDay;
	
public:
	__property System::UnicodeString Day = {read=FDay};
	__property System::UnicodeString Description = {read=FDescription};
	__property int High = {read=FHigh, nodefault};
	__property int Low = {read=FLow, nodefault};
	__property System::UnicodeString ShortDay = {read=FShortDay};
public:
	/* TObject.Create */ inline __fastcall TWeatherForecast() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TWeatherForecast() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TWeatherFeature : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FLocation;
	TWeatherConditions* FCurrent;
	Gmconstants::TTemperatureUnit FTemperatureUnit;
	Gmconstants::TWindSpeedUnit FWindSpeedUnit;
	System::Contnrs::TObjectList* FForecast;
	int __fastcall GetCount();
	TWeatherForecast* __fastcall GetForecast(int Index);
	
protected:
	void __fastcall ProcessXMLData(System::UnicodeString Data);
	
public:
	__fastcall virtual TWeatherFeature();
	__fastcall virtual ~TWeatherFeature();
	virtual void __fastcall Assign(System::TObject* Source);
	__property TWeatherConditions* Current = {read=FCurrent};
	__property System::UnicodeString Location = {read=FLocation};
	__property Gmconstants::TTemperatureUnit TemperatureUnit = {read=FTemperatureUnit, nodefault};
	__property Gmconstants::TWindSpeedUnit WindSpeedUnit = {read=FWindSpeedUnit, nodefault};
	__property TWeatherForecast* Forecast[int Index] = {read=GetForecast};
	__property int Count = {read=GetCount, nodefault};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TLayers : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TCustomGMMap* FGMMap;
	TPanoramio* FPanoramio;
	TKml* FKml;
	TTraffic* FTraffic;
	TTransit* FTransit;
	TBicycling* FBicycling;
	TWeather* FWeather;
	
public:
	__fastcall virtual TLayers(TCustomGMMap* GMMap);
	__fastcall virtual ~TLayers();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property TPanoramio* Panoramio = {read=FPanoramio, write=FPanoramio};
	__property TKml* Kml = {read=FKml, write=FKml};
	__property TTraffic* Traffic = {read=FTraffic, write=FTraffic};
	__property TTransit* Transit = {read=FTransit, write=FTransit};
	__property TBicycling* Bicycling = {read=FBicycling, write=FBicycling};
	__property TWeather* Weather = {read=FWeather, write=FWeather};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TStreetView : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TCustomGMMap* FGMMap;
	bool FVisible;
	void __fastcall SetVisible(const bool Value);
	void __fastcall SetOptions();
	
public:
	__fastcall virtual TStreetView(TCustomGMMap* GMMap);
	
__published:
	__property bool Visible = {read=FVisible, write=SetVisible, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TStreetView() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TCustomGMMap : public Gmclasses::TGMBase
{
	typedef Gmclasses::TGMBase inherited;
	
private:
	bool FIsDoMap;
	bool FIsUpdating;
	System::Classes::TList* FLinkedComponents;
	unsigned FCountLinkedCom;
	bool FActive;
	TAfterPageLoaded FAfterPageLoaded;
	System::Classes::TNotifyEvent FOnActiveChange;
	int FIntervalEvents;
	System::Classes::TNotifyEvent FOnIntervalEventsChange;
	int FPrecision;
	System::Classes::TNotifyEvent FOnPrecisionChange;
	TRequiredProp* FRequiredProp;
	TMapTypeIdChanged FOnMapTypeIdChanged;
	TZoomChanged FOnZoomChanged;
	TNonVisualProp* FNonVisualProp;
	TLayers* FLayers;
	TStreetView* FStreetView;
	TLatLngEvent FOnRightClick;
	System::Classes::TNotifyEvent FOnDrag;
	TLatLngEvent FOnMouseMove;
	TLatLngEvent FOnMouseOut;
	System::Classes::TNotifyEvent FOnDragStart;
	TPanoramioClick FOnPanoramioClick;
	TWeatherClick FOnWeatherClick;
	TBoundsChanged FOnBoundsChanged;
	TLatLngEvent FOnDblClick;
	TLatLngEvent FOnMouseOver;
	TLatLngEvent FOnClick;
	System::Classes::TNotifyEvent FOnDragEnd;
	TLatLngEvent FOnCenterChanged;
	System::UnicodeString FAPIKey;
	int __fastcall AddLinkedComponent(TGMObjects* GMObject);
	void __fastcall RemoveLinkedComponent(TGMObjects* GMObject);
	int __fastcall ExistLinkedComponent(unsigned Id);
	void __fastcall SetActive(const bool Value);
	void __fastcall SetIntervalEvents(const int Value);
	void __fastcall SetPrecision(const int Value);
	void __fastcall SetAPIKey(const System::UnicodeString Value);
	
protected:
	bool FDocLoaded;
	System::Classes::TComponent* FWebBrowser;
	Webcontrol::TCustomWeb* FWC;
	virtual System::UnicodeString __fastcall VisualPropToStr() = 0 ;
	virtual void __fastcall SetIntervalTimer(int Interval) = 0 ;
	virtual void __fastcall SetEnableTimer(bool State) = 0 ;
	System::UnicodeString __fastcall GetBaseHTMLCode();
	bool __fastcall Check();
	bool __fastcall MapIsNull();
	virtual bool __fastcall ExecuteScript(System::UnicodeString NameFunct, System::UnicodeString Params) = 0 ;
	virtual void __fastcall BrowserEventsControl() = 0 ;
	virtual void __fastcall Notification(System::Classes::TComponent* AComponent, System::Classes::TOperation Operation);
	virtual System::UnicodeString __fastcall GetAPIUrl();
	void __fastcall ChangeCenter(System::TObject* Sender);
	virtual void __fastcall OnTimer(System::TObject* Sender);
	virtual void __fastcall LoadBaseWeb() = 0 ;
	virtual void __fastcall LoadBlankPage() = 0 ;
	void __fastcall SetMapTypeId(Gmconstants::TMapTypeId MapTypeId)/* overload */;
	void __fastcall SetMapTypeId(const System::UnicodeString MapTypeId)/* overload */;
	void __fastcall SetZoom(int Zoom);
	
public:
	__fastcall virtual TCustomGMMap(System::Classes::TComponent* AOwner);
	__fastcall virtual ~TCustomGMMap();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	int __fastcall GetMaxZoom(Gmclasses::TLatLng* LL);
	void __fastcall ZoomToPoints(Gmclasses::TLatLng* *Points, const int Points_High);
	void __fastcall LatLngBoundsSetBounds(double SWLat, double SWLng, double NELat, double NELng)/* overload */;
	void __fastcall LatLngBoundsSetBounds(Gmclasses::TLatLngBounds* Bounds)/* overload */;
	void __fastcall LatLngBoundsGetBounds(Gmclasses::TLatLngBounds* LLB);
	void __fastcall LatLngBoundsExtend(Gmclasses::TLatLng* LatLng, Gmclasses::TLatLngBounds* LLB)/* overload */;
	void __fastcall LatLngBoundsExtend(double Lat, double Lng, Gmclasses::TLatLngBounds* LLB)/* overload */;
	void __fastcall MapLatLngBoundsExtend(Gmclasses::TLatLng* LatLng, Gmclasses::TLatLngBounds* LLB)/* overload */;
	bool __fastcall LatLngBoundsContains(Gmclasses::TLatLng* LatLng, Gmclasses::TLatLngBounds* LLB)/* overload */;
	bool __fastcall LatLngBoundsContains(double Lat, double Lng, Gmclasses::TLatLngBounds* LLB)/* overload */;
	bool __fastcall MapLatLngBoundsContains(Gmclasses::TLatLng* LatLng)/* overload */;
	void __fastcall LatLngBoundsGetCenter(Gmclasses::TLatLngBounds* LLB, Gmclasses::TLatLng* LL);
	void __fastcall LatLngBoundsToSpan(Gmclasses::TLatLng* LL);
	void __fastcall GetCenter(Gmclasses::TLatLng* LL);
	Gmconstants::TMapTypeId __fastcall GetMapTypeId();
	int __fastcall GetZoom();
	void __fastcall PanBy(int x, int y);
	void __fastcall PanTo(Gmclasses::TLatLng* LatLng)/* overload */;
	void __fastcall PanTo(const double Lat, const double Lng)/* overload */;
	void __fastcall SetCenter(Gmclasses::TLatLng* LatLng)/* overload */;
	void __fastcall SetCenter(const double Lat, const double Lng)/* overload */;
	virtual void __fastcall PrintNoDialog();
	virtual void __fastcall PrintWithDialog();
	virtual void __fastcall PrintPreview();
	virtual void __fastcall PrintPageSetup();
	virtual void __fastcall SaveToJPGFile(System::Sysutils::TFileName FileName = System::Sysutils::TFileName()) = 0 ;
	virtual void __fastcall SaveHTML(System::Sysutils::TFileName FileName = System::Sysutils::TFileName()) = 0 ;
	virtual void __fastcall DoMap();
	
__published:
	__property System::UnicodeString APIKey = {read=FAPIKey, write=SetAPIKey};
	__property bool Active = {read=FActive, write=SetActive, default=0};
	__property int IntervalEvents = {read=FIntervalEvents, write=SetIntervalEvents, default=200};
	__property int Precision = {read=FPrecision, write=SetPrecision, default=0};
	__property TRequiredProp* RequiredProp = {read=FRequiredProp, write=FRequiredProp};
	__property TNonVisualProp* NonVisualProp = {read=FNonVisualProp, write=FNonVisualProp};
	__property TLayers* Layers = {read=FLayers, write=FLayers};
	__property TStreetView* StreetView = {read=FStreetView, write=FStreetView};
	__property TAfterPageLoaded AfterPageLoaded = {read=FAfterPageLoaded, write=FAfterPageLoaded};
	__property TBoundsChanged OnBoundsChanged = {read=FOnBoundsChanged, write=FOnBoundsChanged};
	__property TLatLngEvent OnCenterChanged = {read=FOnCenterChanged, write=FOnCenterChanged};
	__property TLatLngEvent OnClick = {read=FOnClick, write=FOnClick};
	__property TLatLngEvent OnDblClick = {read=FOnDblClick, write=FOnDblClick};
	__property System::Classes::TNotifyEvent OnDrag = {read=FOnDrag, write=FOnDrag};
	__property System::Classes::TNotifyEvent OnDragEnd = {read=FOnDragEnd, write=FOnDragEnd};
	__property System::Classes::TNotifyEvent OnDragStart = {read=FOnDragStart, write=FOnDragStart};
	__property TMapTypeIdChanged OnMapTypeIdChanged = {read=FOnMapTypeIdChanged, write=FOnMapTypeIdChanged};
	__property TLatLngEvent OnMouseMove = {read=FOnMouseMove, write=FOnMouseMove};
	__property TLatLngEvent OnMouseOut = {read=FOnMouseOut, write=FOnMouseOut};
	__property TLatLngEvent OnMouseOver = {read=FOnMouseOver, write=FOnMouseOver};
	__property TLatLngEvent OnRightClick = {read=FOnRightClick, write=FOnRightClick};
	__property TZoomChanged OnZoomChanged = {read=FOnZoomChanged, write=FOnZoomChanged};
	__property TWeatherClick OnWeatherClick = {read=FOnWeatherClick, write=FOnWeatherClick};
	__property TPanoramioClick OnPanoramioClick = {read=FOnPanoramioClick, write=FOnPanoramioClick};
	__property System::Classes::TNotifyEvent OnActiveChange = {read=FOnActiveChange, write=FOnActiveChange};
	__property System::Classes::TNotifyEvent OnIntervalEventsChange = {read=FOnIntervalEventsChange, write=FOnIntervalEventsChange};
	__property System::Classes::TNotifyEvent OnPrecisionChange = {read=FOnPrecisionChange, write=FOnPrecisionChange};
};


class PASCALIMPLEMENTATION TGMObjects : public Gmclasses::TGMBase
{
	typedef Gmclasses::TGMBase inherited;
	
private:
	unsigned FIdxList;
	TCustomGMMap* FMap;
	
protected:
	virtual void __fastcall SetIdxList(const unsigned Value);
	virtual void __fastcall SetMap(TCustomGMMap* const Value);
	virtual void __fastcall Notification(System::Classes::TComponent* AComponent, System::Classes::TOperation Operation);
	virtual bool __fastcall ExecuteScript(System::UnicodeString NameFunct, System::UnicodeString Params);
	virtual void __fastcall DeleteMapObjects() = 0 ;
	virtual void __fastcall ShowElements() = 0 ;
	virtual void __fastcall EventFired(Gmconstants::TEventType EventType, System::TVarRec *Params, const int Params_High) = 0 ;
	bool __fastcall IsMapActive();
	int __fastcall GetIntegerField(const System::UnicodeString FormName, const System::UnicodeString FieldName, int DefaultValue = 0x0);
	System::UnicodeString __fastcall GetStringField(const System::UnicodeString FormName, const System::UnicodeString FieldName, System::UnicodeString DefaultValue = System::UnicodeString());
	double __fastcall GetFloatField(const System::UnicodeString FormName, const System::UnicodeString FieldName, double DefaultValue = 0.000000E+00);
	bool __fastcall GetBoolField(const System::UnicodeString FormName, const System::UnicodeString FieldName, bool DefaultValue = false);
	int __fastcall GetMapPrecision();
	__property unsigned IdxList = {read=FIdxList, write=SetIdxList, nodefault};
	
public:
	__fastcall virtual TGMObjects(System::Classes::TComponent* AOwner);
	__fastcall virtual ~TGMObjects();
	
__published:
	__property TCustomGMMap* Map = {read=FMap, write=SetMap};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmmap */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMMAP)
using namespace Gmmap;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmmapHPP
