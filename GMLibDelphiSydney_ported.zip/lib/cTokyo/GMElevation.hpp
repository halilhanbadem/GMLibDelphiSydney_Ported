﻿// CodeGear C++Builder
// Copyright (c) 1995, 2020 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMElevation.pas' rev: 34.00 (Windows)

#ifndef GmelevationHPP
#define GmelevationHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.Contnrs.hpp>
#include <Data.DB.hpp>
#include <GMMap.hpp>
#include <GMClasses.hpp>
#include <GMConstants.hpp>
#include <GMMarker.hpp>
#include <GMPolyline.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmelevation
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TElevationResult;
class DELPHICLASS TElevationResults;
class DELPHICLASS TCustomGMElevation;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TElevationResult : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Gmclasses::TLatLng* FLocation;
	double FResolution;
	double FElevation;
	
public:
	__fastcall virtual TElevationResult();
	__fastcall virtual ~TElevationResult();
	__property Gmclasses::TLatLng* Location = {read=FLocation};
	__property double Elevation = {read=FElevation};
	__property double Resolution = {read=FResolution};
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TElevationResults : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	TElevationResult* operator[](int Index) { return this->Items[Index]; }
	
private:
	System::Contnrs::TObjectList* FElevationResult;
	Gmconstants::TElevationStatus FStatus;
	TElevationResult* __fastcall GetItems(int Index);
	int __fastcall GetCount();
	void __fastcall ParseElevations(System::UnicodeString Elevations);
	int __fastcall AddElevationResult(System::UnicodeString Elevation, System::UnicodeString Resolution, System::UnicodeString Lat, System::UnicodeString Lng);
	
public:
	__fastcall virtual TElevationResults();
	__fastcall virtual ~TElevationResults();
	void __fastcall Clear();
	__property Gmconstants::TElevationStatus Status = {read=FStatus, nodefault};
	__property TElevationResult* Items[int Index] = {read=GetItems/*, default*/};
	__property int Count = {read=GetCount, nodefault};
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TCustomGMElevation : public Gmmap::TGMObjects
{
	typedef Gmmap::TGMObjects inherited;
	
public:
	Gmclasses::TLinePoint* operator[](int I) { return this->Items[I]; }
	
private:
	Gmclasses::TLinePoints* FLinePoints;
	int FSamples;
	Gmconstants::TElevationType FElevationType;
	TElevationResults* FElevationResult;
	int __fastcall GetCountLinePoints();
	Gmclasses::TLinePoint* __fastcall GetItems(int I);
	void __fastcall SetSamples(const int Value);
	
protected:
	virtual System::UnicodeString __fastcall GetAPIUrl();
	virtual void __fastcall DeleteMapObjects();
	virtual void __fastcall ShowElements();
	virtual void __fastcall EventFired(Gmconstants::TEventType EventType, System::TVarRec *Params, const int Params_High);
	void __fastcall LinePointChanged();
	
public:
	__fastcall virtual TCustomGMElevation(System::Classes::TComponent* aOwner);
	__fastcall virtual ~TCustomGMElevation();
	Gmclasses::TLinePoint* __fastcall AddLatLng(Gmclasses::TLatLng* LatLng)/* overload */;
	Gmclasses::TLinePoint* __fastcall AddLatLng(double Lat, double Lng)/* overload */;
	void __fastcall AddLatLngFromCSV(int LatColumn, int LngColumn, System::UnicodeString FileName, System::WideChar Delimiter = (System::WideChar)(0x2c), bool DeleteBeforeLoad = true, bool WithRownTitle = true);
	void __fastcall AddLatLngFromDataSet(Data::Db::TDataSet* DataSet, System::UnicodeString LatField, System::UnicodeString LngField, bool DeleteBeforeLoad = true);
	virtual void __fastcall AddLatLngFromPoly(Gmpolyline::TBasePolyline* Poly, bool DeleteBeforeLoad = true);
	void __fastcall Clear();
	void __fastcall DelLatLng(int Index);
	void __fastcall Execute();
	__property int CountLinePoints = {read=GetCountLinePoints, nodefault};
	__property Gmclasses::TLinePoint* Items[int I] = {read=GetItems/*, default*/};
	__property TElevationResults* ElevationResult = {read=FElevationResult};
	
__published:
	__property Gmclasses::TLinePoints* LinePoints = {read=FLinePoints, write=FLinePoints};
	__property int Samples = {read=FSamples, write=SetSamples, default=2};
	__property Gmconstants::TElevationType ElevationType = {read=FElevationType, write=FElevationType, default=1};
private:
	void *__ILinePoint;	// Gmclasses::ILinePoint 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {35926390-118A-4604-A343-73D200A36006}
	operator Gmclasses::_di_ILinePoint()
	{
		Gmclasses::_di_ILinePoint intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Gmclasses::ILinePoint*(void) { return (Gmclasses::ILinePoint*)&__ILinePoint; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmelevation */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMELEVATION)
using namespace Gmelevation;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmelevationHPP
