﻿// CodeGear C++Builder
// Copyright (c) 1995, 2020 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'WebControl.pas' rev: 34.00 (Windows)

#ifndef WebcontrolHPP
#define WebcontrolHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.SysUtils.hpp>

//-- user supplied -----------------------------------------------------------

namespace Webcontrol
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCustomWeb;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomWeb : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	System::Classes::TComponent* FWebBrowser;
	System::Classes::TStringList* FLinks;
	System::Classes::TStringList* FForms;
	System::Classes::TStringList* FFields;
	virtual void __fastcall SetBrowser(System::Classes::TComponent* Browser);
	virtual System::UnicodeString __fastcall WebFormFieldValue(const int FormIdx, const System::UnicodeString FieldName) = 0 /* overload */;
	System::UnicodeString __fastcall WebFormFieldValue(const System::UnicodeString FormName, const System::UnicodeString FieldName)/* overload */;
	
public:
	__fastcall virtual TCustomWeb(System::Classes::TComponent* WebBrowser);
	__fastcall virtual ~TCustomWeb();
	void __fastcall Clear();
	virtual void __fastcall WebFormNames() = 0 ;
	void __fastcall WebFormFields(const System::UnicodeString FormName)/* overload */;
	virtual void __fastcall WebFormFields(const int FormIdx) = 0 /* overload */;
	virtual void __fastcall WebFormSetFieldValue(const int FormIdx, const System::UnicodeString FieldName, const System::UnicodeString NewValue) = 0 /* overload */;
	void __fastcall WebFormSetFieldValue(const System::UnicodeString FormName, const System::UnicodeString FieldName, const System::UnicodeString NewValue)/* overload */;
	virtual void __fastcall WebFormSubmit(const int FormIdx) = 0 /* overload */;
	void __fastcall WebFormSubmit(const System::UnicodeString FormName)/* overload */;
	System::UnicodeString __fastcall GetStringField(const System::UnicodeString FormName, const System::UnicodeString FieldName, System::UnicodeString DefaultValue = System::UnicodeString());
	int __fastcall GetIntegerField(const System::UnicodeString FormName, const System::UnicodeString FieldName, int DefaultValue = 0x0);
	double __fastcall GetFloatField(const System::UnicodeString FormName, const System::UnicodeString FieldName, double DefaultValue = 0.000000E+00);
	bool __fastcall GetBoolField(const System::UnicodeString FormName, const System::UnicodeString FieldName, bool DefaultValue = false);
	virtual System::UnicodeString __fastcall WebHTMLCode() = 0 ;
	virtual void __fastcall WebPrintWithoutDialog() = 0 ;
	virtual void __fastcall WebPrintWithDialog() = 0 ;
	virtual void __fastcall WebPrintPageSetup() = 0 ;
	virtual void __fastcall WebPreview() = 0 ;
	virtual void __fastcall SaveToJPGFile(System::Sysutils::TFileName FileName = System::Sysutils::TFileName()) = 0 ;
	__property System::Classes::TStringList* Forms = {read=FForms};
	__property System::Classes::TStringList* Fields = {read=FFields};
	__property System::Classes::TStringList* Links = {read=FLinks};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Webcontrol */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_WEBCONTROL)
using namespace Webcontrol;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// WebcontrolHPP
