﻿// CodeGear C++Builder
// Copyright (c) 1995, 2020 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMPolyline.pas' rev: 34.00 (Windows)

#ifndef GmpolylineHPP
#define GmpolylineHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <GMLinkedComponents.hpp>
#include <GMConstants.hpp>
#include <GMClasses.hpp>
#include <GMMap.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmpolyline
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCustomSymbol;
class DELPHICLASS TValue;
class DELPHICLASS TCustomIconSequence;
class DELPHICLASS TCurveLine;
class DELPHICLASS TBasePolyline;
class DELPHICLASS TBasePolylines;
class DELPHICLASS TGMBasePolyline;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCustomSymbol : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	Gmconstants::TSymbolPath FPath;
	int FStrokeWeight;
	double FFillOpacity;
	double FStrokeOpacity;
	System::Classes::TNotifyEvent FOnChange;
	void __fastcall SetFillOpacity(const double Value);
	void __fastcall SetPath(const Gmconstants::TSymbolPath Value);
	void __fastcall SetStrokeOpacity(const double Value);
	void __fastcall SetStrokeWeight(const int Value);
	
protected:
	virtual System::UnicodeString __fastcall GetFillColor() = 0 ;
	virtual System::UnicodeString __fastcall GetStrokeColor() = 0 ;
	__property System::Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	
public:
	__fastcall virtual TCustomSymbol();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property double FillOpacity = {read=FFillOpacity, write=SetFillOpacity};
	__property Gmconstants::TSymbolPath Path = {read=FPath, write=SetPath, default=0};
	__property double StrokeOpacity = {read=FStrokeOpacity, write=SetStrokeOpacity};
	__property int StrokeWeight = {read=FStrokeWeight, write=SetStrokeWeight, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TCustomSymbol() { }
	
};


class PASCALIMPLEMENTATION TValue : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	int FValue;
	Gmconstants::TMeasure FMeasure;
	System::Classes::TNotifyEvent FOnChange;
	void __fastcall SetMeasure(const Gmconstants::TMeasure Value);
	void __fastcall SetValue(const int Value);
	
protected:
	__property System::Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	
public:
	__fastcall virtual TValue();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property int Value = {read=FValue, write=SetValue, default=100};
	__property Gmconstants::TMeasure Measure = {read=FMeasure, write=SetMeasure, default=1};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TValue() { }
	
};


class PASCALIMPLEMENTATION TCustomIconSequence : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TBasePolyline* FOwner;
	TValue* FDistRepeat;
	TValue* FOffSet;
	System::Classes::TNotifyEvent FOnChange;
	
protected:
	void __fastcall OnOffSetChange(System::TObject* Sender);
	void __fastcall OnDistRepeatChange(System::TObject* Sender);
	void __fastcall OnIconChange(System::TObject* Sender);
	virtual void __fastcall CreatePropertiesWithColor() = 0 ;
	__property System::Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	
public:
	__fastcall virtual TCustomIconSequence(TBasePolyline* aOwner);
	__fastcall virtual ~TCustomIconSequence();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property TValue* OffSet = {read=FOffSet, write=FOffSet};
	__property TValue* DistRepeat = {read=FDistRepeat, write=FDistRepeat};
};


class PASCALIMPLEMENTATION TCurveLine : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	bool FHorizontal;
	int FMultiplier;
	bool FActive;
	double FResolution;
	System::Classes::TNotifyEvent FOnChange;
	void __fastcall SetActive(const bool Value);
	void __fastcall SetHorizontal(const bool Value);
	void __fastcall SetMultiplier(const int Value);
	void __fastcall SetResolution(const double Value);
	
public:
	__fastcall virtual TCurveLine();
	__property System::Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	
__published:
	__property bool Active = {read=FActive, write=SetActive, default=0};
	__property bool Horizontal = {read=FHorizontal, write=SetHorizontal, default=1};
	__property int Multiplier = {read=FMultiplier, write=SetMultiplier, default=1};
	__property double Resolution = {read=FResolution, write=SetResolution};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TCurveLine() { }
	
};


class PASCALIMPLEMENTATION TBasePolyline : public Gmlinkedcomponents::TLinkedComponent
{
	typedef Gmlinkedcomponents::TLinkedComponent inherited;
	
public:
	Gmclasses::TLinePoint* operator[](int I) { return this->Items[I]; }
	
private:
	bool FVisible;
	int FStrokeWeight;
	bool FGeodesic;
	bool FClickable;
	double FStrokeOpacity;
	bool FEditable;
	Gmclasses::TLinePoints* FLinePoints;
	bool FAutoUpdatePath;
	bool FIsUpdating;
	System::_di_IInterface FOwnerInterface;
	void __fastcall SetClickable(const bool Value);
	void __fastcall SetEditable(const bool Value);
	void __fastcall SetGeodesic(const bool Value);
	void __fastcall SetStrokeOpacity(const double Value);
	void __fastcall SetStrokeWeight(const int Value);
	void __fastcall SetVisible(const bool Value);
	Gmclasses::TLinePoint* __fastcall GetItems(int I);
	
protected:
	virtual System::UnicodeString __fastcall GetStrokeColor() = 0 ;
	int __fastcall GetCountLinePoints();
	void __fastcall LinePointChanged();
	virtual HRESULT __stdcall QueryInterface(const GUID &IID, /* out */ void *Obj);
	int __stdcall _AddRef();
	int __stdcall _Release();
	
public:
	virtual void __fastcall AfterConstruction();
	__fastcall virtual TBasePolyline(System::Classes::TCollection* Collection);
	__fastcall virtual ~TBasePolyline();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	void __fastcall GetCenter(Gmclasses::TLatLng* LL);
	void __fastcall ZoomToPoints();
	System::UnicodeString __fastcall PolylineToStr();
	double __fastcall ComputeArea(double Radius = -1.000000E+00);
	bool __fastcall IsLocationOnEdge(Gmclasses::TLatLng* LatLng, int Tolerance = 0xffffffff)/* overload */;
	bool __fastcall IsLocationOnEdge(double Lat, double Lng, int Tolerance = 0xffffffff)/* overload */;
	System::UnicodeString __fastcall EncodePath();
	void __fastcall DecodePath(System::UnicodeString EncodedPath, bool Add = false);
	virtual void __fastcall CenterMapTo();
	void __fastcall GetPath();
	void __fastcall SetPath();
	Gmclasses::TLinePoint* __fastcall AddLinePoint(double Lat = 0.000000E+00, double Lng = 0.000000E+00)/* overload */;
	Gmclasses::TLinePoint* __fastcall AddLinePoint(System::UnicodeString Lat, System::UnicodeString Lng)/* overload */;
	Gmclasses::TLinePoint* __fastcall InsertLinePoint(int Index, double Lat, double Lng);
	void __fastcall DeleteLinePoint(int Index);
	void __fastcall MoveLinePoint(int CurIndex, int NewIndex);
	void __fastcall ClearLinePoints();
	__property int CountLinePoints = {read=GetCountLinePoints, nodefault};
	__property Gmclasses::TLinePoint* Items[int I] = {read=GetItems/*, default*/};
	
__published:
	__property bool Clickable = {read=FClickable, write=SetClickable, default=1};
	__property bool Editable = {read=FEditable, write=SetEditable, default=0};
	__property bool Geodesic = {read=FGeodesic, write=SetGeodesic, default=0};
	__property double StrokeOpacity = {read=FStrokeOpacity, write=SetStrokeOpacity};
	__property int StrokeWeight = {read=FStrokeWeight, write=SetStrokeWeight, default=2};
	__property bool Visible = {read=FVisible, write=SetVisible, default=1};
	__property bool AutoUpdatePath = {read=FAutoUpdatePath, write=FAutoUpdatePath, default=1};
	__property Gmclasses::TLinePoints* LinePoints = {read=FLinePoints, write=FLinePoints};
	__property InfoWindow;
	__property Text = {default=0};
private:
	void *__ILinePoint;	// Gmclasses::ILinePoint 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {35926390-118A-4604-A343-73D200A36006}
	operator Gmclasses::_di_ILinePoint()
	{
		Gmclasses::_di_ILinePoint intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Gmclasses::ILinePoint*(void) { return (Gmclasses::ILinePoint*)&__ILinePoint; }
	#endif
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TBasePolylines : public Gmlinkedcomponents::TLinkedComponents
{
	typedef Gmlinkedcomponents::TLinkedComponents inherited;
	
public:
	TBasePolyline* operator[](int I) { return this->Items[I]; }
	
private:
	HIDESBASE void __fastcall SetItems(int I, TBasePolyline* const Value);
	HIDESBASE TBasePolyline* __fastcall GetItems(int I);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	HIDESBASE TBasePolyline* __fastcall Add();
	HIDESBASE TBasePolyline* __fastcall Insert(int Index);
	__property TBasePolyline* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TLinkedComponents.Create */ inline __fastcall virtual TBasePolylines(Gmlinkedcomponents::TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass) : Gmlinkedcomponents::TLinkedComponents(GMLinkedComponent, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TBasePolylines() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TGMBasePolyline : public Gmlinkedcomponents::TGMLinkedComponent
{
	typedef Gmlinkedcomponents::TGMLinkedComponent inherited;
	
public:
	TBasePolyline* operator[](int I) { return this->Items[I]; }
	
private:
	Gmlinkedcomponents::TLatLngIdxEvent FOnRightClick;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseDown;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseMove;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseUp;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseOut;
	Gmlinkedcomponents::TLatLngIdxEvent FOnDblClick;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseOver;
	Gmlinkedcomponents::TLatLngIdxEvent FOnClick;
	Gmlinkedcomponents::TLinkedComponentChange FOnStrokeColorChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnVisibleChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnStrokeWeightChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnGeodesicChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnClickableChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnStrokeOpacityChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnEditableChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnPathChange;
	
protected:
	HIDESBASE TBasePolyline* __fastcall GetItems(int I);
	virtual void __fastcall EventFired(Gmconstants::TEventType EventType, System::TVarRec *Params, const int Params_High);
	
public:
	void __fastcall GetPath();
	void __fastcall SetPath();
	__property TBasePolyline* Items[int I] = {read=GetItems/*, default*/};
	
__published:
	__property VisualObjects;
	__property Gmlinkedcomponents::TLatLngIdxEvent OnClick = {read=FOnClick, write=FOnClick};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnDblClick = {read=FOnDblClick, write=FOnDblClick};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseDown = {read=FOnMouseDown, write=FOnMouseDown};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseMove = {read=FOnMouseMove, write=FOnMouseMove};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseOut = {read=FOnMouseOut, write=FOnMouseOut};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseOver = {read=FOnMouseOver, write=FOnMouseOver};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseUp = {read=FOnMouseUp, write=FOnMouseUp};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnRightClick = {read=FOnRightClick, write=FOnRightClick};
	__property Gmlinkedcomponents::TLinkedComponentChange OnClickableChange = {read=FOnClickableChange, write=FOnClickableChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnEditableChange = {read=FOnEditableChange, write=FOnEditableChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnGeodesicChange = {read=FOnGeodesicChange, write=FOnGeodesicChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnStrokeColorChange = {read=FOnStrokeColorChange, write=FOnStrokeColorChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnStrokeOpacityChange = {read=FOnStrokeOpacityChange, write=FOnStrokeOpacityChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnStrokeWeightChange = {read=FOnStrokeWeightChange, write=FOnStrokeWeightChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnVisibleChange = {read=FOnVisibleChange, write=FOnVisibleChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnPathChange = {read=FOnPathChange, write=FOnPathChange};
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual TGMBasePolyline(System::Classes::TComponent* AOwner) : Gmlinkedcomponents::TGMLinkedComponent(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~TGMBasePolyline() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmpolyline */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMPOLYLINE)
using namespace Gmpolyline;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmpolylineHPP
