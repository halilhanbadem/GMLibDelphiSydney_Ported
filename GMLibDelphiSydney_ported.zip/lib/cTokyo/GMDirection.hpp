﻿// CodeGear C++Builder
// Copyright (c) 1995, 2020 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMDirection.pas' rev: 34.00 (Windows)

#ifndef GmdirectionHPP
#define GmdirectionHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Vcl.Controls.hpp>
#include <System.Classes.hpp>
#include <System.Contnrs.hpp>
#include <GMClasses.hpp>
#include <GMConstants.hpp>
#include <GMMap.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmdirection
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TDistance;
class DELPHICLASS TDuration;
class DELPHICLASS TTransitAgency;
class DELPHICLASS TTransitStop;
class DELPHICLASS TTimeClass;
class DELPHICLASS TTransitVehicle;
class DELPHICLASS TTransitLine;
class DELPHICLASS TTransitDetails;
class DELPHICLASS TDirectionsStep;
class DELPHICLASS TDirectionsLeg;
class DELPHICLASS TDirectionsRoute;
class DELPHICLASS TCustomDirectionsResult;
class DELPHICLASS TLatLngStr;
class DELPHICLASS TTransitOptions;
class DELPHICLASS TWaypoint;
class DELPHICLASS TWaypointsList;
class DELPHICLASS TDirectionsRequest;
class DELPHICLASS TMarkerOptions;
class DELPHICLASS TCustomPolylineOptions;
class DELPHICLASS TCustomDirectionsRenderer;
class DELPHICLASS TCustomGMDirection;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TDistance : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	int FValue;
	System::UnicodeString FText;
	
public:
	__fastcall virtual TDistance();
	virtual void __fastcall Assign(System::TObject* Source);
	__property System::UnicodeString Text = {read=FText};
	__property int Value = {read=FValue, nodefault};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TDistance() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TDuration : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	int FValue;
	System::UnicodeString FText;
	
public:
	__fastcall virtual TDuration();
	virtual void __fastcall Assign(System::TObject* Source);
	__property System::UnicodeString Text = {read=FText};
	__property int Value = {read=FValue, nodefault};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TDuration() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TTransitAgency : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FName;
	System::UnicodeString FPhone;
	System::UnicodeString FUrl;
	
public:
	__fastcall virtual TTransitAgency();
	virtual void __fastcall Assign(System::TObject* Source);
	__property System::UnicodeString Name = {read=FName};
	__property System::UnicodeString Phone = {read=FPhone};
	__property System::UnicodeString Url = {read=FUrl};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TTransitAgency() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TTransitStop : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FName;
	Gmclasses::TLatLng* FLocation;
	
public:
	__fastcall virtual TTransitStop();
	__fastcall virtual ~TTransitStop();
	virtual void __fastcall Assign(System::TObject* Source);
	__property Gmclasses::TLatLng* Location = {read=FLocation};
	__property System::UnicodeString Name = {read=FName};
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TTimeClass : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::TDateTime FValue;
	System::UnicodeString FTimeZone;
	System::UnicodeString FText;
	
public:
	__fastcall virtual TTimeClass();
	virtual void __fastcall Assign(System::TObject* Source);
	__property System::UnicodeString Text = {read=FText};
	__property System::UnicodeString TimeZone = {read=FTimeZone};
	__property System::TDateTime Value = {read=FValue};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TTimeClass() { }
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TTransitVehicle : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FName;
	System::UnicodeString FLocalIcon;
	System::UnicodeString FIcon;
	Gmconstants::TVehicleType FVehicleType;
	
public:
	__fastcall virtual TTransitVehicle();
	virtual void __fastcall Assign(System::TObject* Source);
	__property System::UnicodeString Icon = {read=FIcon};
	__property System::UnicodeString LocalIcon = {read=FLocalIcon};
	__property System::UnicodeString Name = {read=FName};
	__property Gmconstants::TVehicleType VehicleType = {read=FVehicleType, nodefault};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TTransitVehicle() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TTransitLine : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::Contnrs::TObjectList* FAgencie;
	System::UnicodeString FName;
	System::UnicodeString FTextColor;
	TTransitVehicle* FVehicle;
	System::UnicodeString FColor;
	System::UnicodeString FIcon;
	System::UnicodeString FShortName;
	System::UnicodeString FUrl;
	TTransitAgency* __fastcall GetAgencie(int Index);
	int __fastcall GetCountAgencie();
	
public:
	__fastcall virtual TTransitLine();
	__fastcall virtual ~TTransitLine();
	virtual void __fastcall Assign(System::TObject* Source);
	__property TTransitAgency* Agencie[int Index] = {read=GetAgencie};
	__property int CountAgencie = {read=GetCountAgencie, nodefault};
	__property System::UnicodeString Color = {read=FColor};
	__property System::UnicodeString Icon = {read=FIcon};
	__property System::UnicodeString Name = {read=FName};
	__property System::UnicodeString ShortName = {read=FShortName};
	__property System::UnicodeString TextColor = {read=FTextColor};
	__property System::UnicodeString Url = {read=FUrl};
	__property TTransitVehicle* Vehicle = {read=FVehicle};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TTransitDetails : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TTransitStop* FArribalStop;
	TTimeClass* FArribalTime;
	TTransitStop* FDepartureStop;
	TTimeClass* FDepartureTime;
	System::UnicodeString FHeadsign;
	int FNumStops;
	TTransitLine* FLine;
	int FHeadway;
	
public:
	__fastcall virtual TTransitDetails();
	__fastcall virtual ~TTransitDetails();
	virtual void __fastcall Assign(System::TObject* Source);
	__property TTransitStop* ArribalStop = {read=FArribalStop};
	__property TTimeClass* ArribalTime = {read=FArribalTime};
	__property TTransitStop* DepartureStop = {read=FDepartureStop};
	__property TTimeClass* DepartureTime = {read=FDepartureTime};
	__property System::UnicodeString Headsign = {read=FHeadsign};
	__property int Headway = {read=FHeadway, nodefault};
	__property TTransitLine* Line = {read=FLine};
	__property int NumStops = {read=FNumStops, nodefault};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TDirectionsStep : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::Contnrs::TObjectList* FPath;
	TDistance* FDistance;
	Gmconstants::TTravelMode FTravelMode;
	TDuration* FDuration;
	Gmclasses::TLatLng* FStartLocation;
	System::UnicodeString FInstructions;
	TTransitDetails* FTransit;
	Gmclasses::TLatLng* FEndLocation;
	TDirectionsStep* FSteps;
	Gmclasses::TLatLng* __fastcall GetPath(int Index);
	int __fastcall GetCountPath();
	
public:
	__fastcall virtual TDirectionsStep();
	__fastcall virtual ~TDirectionsStep();
	virtual void __fastcall Assign(System::TObject* Source);
	__property TDistance* Distance = {read=FDistance};
	__property TDuration* Duration = {read=FDuration};
	__property Gmclasses::TLatLng* EndLocation = {read=FEndLocation};
	__property System::UnicodeString Instructions = {read=FInstructions};
	__property Gmclasses::TLatLng* Path[int Index] = {read=GetPath};
	__property int CountPath = {read=GetCountPath, nodefault};
	__property Gmclasses::TLatLng* StartLocation = {read=FStartLocation};
	__property TDirectionsStep* Steps = {read=FSteps};
	__property TTransitDetails* Transit = {read=FTransit};
	__property Gmconstants::TTravelMode TravelMode = {read=FTravelMode, nodefault};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TDirectionsLeg : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TTimeClass* FDepartureTime;
	TTimeClass* FArrivalTime;
	TDistance* FDistance;
	TDuration* FDuration;
	System::UnicodeString FEndAddress;
	System::UnicodeString FStartAddress;
	Gmclasses::TLatLng* FEndLocation;
	Gmclasses::TLatLng* FStartLocation;
	System::Contnrs::TObjectList* FViaWaypoints;
	System::Contnrs::TObjectList* FStep;
	Gmclasses::TLatLng* __fastcall GetViaWaypoints(int Index);
	TDirectionsStep* __fastcall GetStep(int Index);
	int __fastcall GetCountStep();
	int __fastcall GetCountViaWaypoints();
	
public:
	__fastcall virtual TDirectionsLeg();
	__fastcall virtual ~TDirectionsLeg();
	virtual void __fastcall Assign(System::TObject* Source);
	__property TTimeClass* ArrivalTime = {read=FArrivalTime};
	__property TTimeClass* DepartureTime = {read=FDepartureTime};
	__property TDistance* Distance = {read=FDistance};
	__property TDuration* Duration = {read=FDuration};
	__property System::UnicodeString EndAddress = {read=FEndAddress};
	__property System::UnicodeString StartAddress = {read=FStartAddress};
	__property Gmclasses::TLatLng* EndLocation = {read=FEndLocation};
	__property Gmclasses::TLatLng* StartLocation = {read=FStartLocation};
	__property Gmclasses::TLatLng* ViaWaypoints[int Index] = {read=GetViaWaypoints};
	__property TDirectionsStep* Step[int Index] = {read=GetStep};
	__property int CountViaWaypoints = {read=GetCountViaWaypoints, nodefault};
	__property int CountStep = {read=GetCountStep, nodefault};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TDirectionsRoute : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FSumary;
	Gmclasses::TLatLngBounds* FBounds;
	System::UnicodeString FCopyrights;
	System::Classes::TStringList* FWarning;
	System::Classes::TStringList* FWaypointOrder;
	System::Contnrs::TObjectList* FOverviewPath;
	System::Contnrs::TObjectList* FLeg;
	TDirectionsLeg* __fastcall GetLeg(int Index);
	Gmclasses::TLatLng* __fastcall GetOverviewPath(int Index);
	System::UnicodeString __fastcall GetWarning(int Index);
	int __fastcall GetWaypointOrder(int Index);
	int __fastcall GetCountLeg();
	int __fastcall GetCountOverviewPath();
	int __fastcall GetCountWarning();
	int __fastcall GetCountWaypointOrder();
	
public:
	__fastcall virtual TDirectionsRoute();
	__fastcall virtual ~TDirectionsRoute();
	virtual void __fastcall Assign(System::TObject* Source);
	__property System::UnicodeString Sumary = {read=FSumary};
	__property Gmclasses::TLatLngBounds* Bounds = {read=FBounds};
	__property System::UnicodeString Copyrights = {read=FCopyrights};
	__property System::UnicodeString Warning[int Index] = {read=GetWarning};
	__property int WaypointOrder[int Index] = {read=GetWaypointOrder};
	__property Gmclasses::TLatLng* OverviewPath[int Index] = {read=GetOverviewPath};
	__property TDirectionsLeg* Leg[int Index] = {read=GetLeg};
	__property int CountWarning = {read=GetCountWarning, nodefault};
	__property int CountWaypointOrder = {read=GetCountWaypointOrder, nodefault};
	__property int CountOverviewPath = {read=GetCountOverviewPath, nodefault};
	__property int CountLeg = {read=GetCountLeg, nodefault};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomDirectionsResult : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TCustomGMDirection* FOwner;
	System::Contnrs::TObjectList* FRoutes;
	System::Classes::TStringList* FXMLData;
	int FIndex;
	Gmconstants::TDirectionsStatus FStatus;
	System::UnicodeString FFromTo;
	int __fastcall GetCount();
	TDirectionsRoute* __fastcall GetRoutes(int Index);
	void __fastcall OnXMLChange(System::TObject* Sender);
	
protected:
	virtual System::UnicodeString __fastcall DirectionsRenderToStr() = 0 ;
	void __fastcall OnDirectionsRenderChange(System::TObject* Sender);
	void __fastcall SetFromTo(System::UnicodeString Value);
	virtual void __fastcall CreateDirectionsRenderObject() = 0 ;
	
public:
	__fastcall virtual TCustomDirectionsResult(TCustomGMDirection* aOwner, int Index);
	__fastcall virtual ~TCustomDirectionsResult();
	virtual void __fastcall Assign(System::TObject* Source);
	void __fastcall ShowRoute(int RouteIndex = 0x0, bool HiddeOthers = true);
	__property int Index = {read=FIndex, nodefault};
	__property System::Classes::TStringList* XMLData = {read=FXMLData};
	__property Gmconstants::TDirectionsStatus Status = {read=FStatus, nodefault};
	__property System::UnicodeString FromTo = {read=FFromTo};
	__property TDirectionsRoute* Routes[int Index] = {read=GetRoutes};
	__property int Count = {read=GetCount, nodefault};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TLatLngStr : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	Gmclasses::TLatLng* FLatLng;
	System::UnicodeString FAddress;
	
public:
	__fastcall virtual TLatLngStr();
	__fastcall virtual ~TLatLngStr();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	HIDESBASE virtual System::UnicodeString __fastcall ToString();
	
__published:
	__property Gmclasses::TLatLng* LatLng = {read=FLatLng, write=FLatLng};
	__property System::UnicodeString Address = {read=FAddress, write=FAddress};
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TTransitOptions : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	System::TTime FArrivalTime;
	System::TTime FDepartureTime;
	System::TDate FArrivalDate;
	System::TDate FDepartureDate;
	void __fastcall SetArrivalDate(const System::TDate Value);
	void __fastcall SetArrivalTime(const System::TTime Value);
	void __fastcall SetDepartureDate(const System::TDate Value);
	void __fastcall SetDepartureTime(const System::TTime Value);
	
public:
	__fastcall virtual TTransitOptions();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::TTime ArrivalTime = {read=FArrivalTime, write=SetArrivalTime};
	__property System::TDate ArrivalDate = {read=FArrivalDate, write=SetArrivalDate};
	__property System::TTime DepartureTime = {read=FDepartureTime, write=SetDepartureTime};
	__property System::TDate DepartureDate = {read=FDepartureDate, write=SetDepartureDate};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TTransitOptions() { }
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TWaypoint : public System::Classes::TCollectionItem
{
	typedef System::Classes::TCollectionItem inherited;
	
private:
	bool FStopOver;
	TLatLngStr* FLocation;
	System::UnicodeString FTitle;
	void __fastcall SetTitle(const System::UnicodeString Value);
	
protected:
	virtual System::UnicodeString __fastcall GetDisplayName();
	
public:
	__fastcall virtual TWaypoint(System::Classes::TCollection* Collection);
	__fastcall virtual ~TWaypoint();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property TLatLngStr* Location = {read=FLocation, write=FLocation};
	__property bool StopOver = {read=FStopOver, write=FStopOver, default=0};
	__property System::UnicodeString Title = {read=FTitle, write=SetTitle};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TWaypointsList : public System::Classes::TCollection
{
	typedef System::Classes::TCollection inherited;
	
public:
	TWaypoint* operator[](int I) { return this->Items[I]; }
	
private:
	System::Classes::TPersistent* FOwner;
	TWaypoint* __fastcall GetItems(int I);
	void __fastcall SetItems(int I, TWaypoint* const Value);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	__fastcall virtual TWaypointsList(System::Classes::TPersistent* aOwner);
	HIDESBASE TWaypoint* __fastcall Add();
	HIDESBASE TWaypoint* __fastcall Insert(int Index);
	HIDESBASE void __fastcall Delete(int Index);
	void __fastcall Move(int CurIndex, int NewIndex);
	HIDESBASE void __fastcall Clear();
	__property TWaypoint* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TWaypointsList() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TDirectionsRequest : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
public:
	TWaypoint* operator[](int I) { return this->Waypoints[I]; }
	
private:
	TLatLngStr* FDestination;
	TWaypointsList* FWaypointsList;
	TLatLngStr* FOrigin;
	bool FOptimizeWaypoints;
	Gmconstants::TTravelMode FTravelMode;
	TTransitOptions* FTransitOpt;
	Gmconstants::TUnitSystem FUnitSystem;
	bool FAvoidHighways;
	Gmconstants::TRegion FRegion;
	bool FAvoidTolls;
	bool FProvideRouteAlt;
	System::Classes::TPersistent* FOwner;
	int __fastcall GetCount();
	TWaypoint* __fastcall GetWaypoint(int I);
	void __fastcall SetWaypointsList(TWaypointsList* const Value);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	__fastcall virtual TDirectionsRequest(System::Classes::TPersistent* aOwner);
	__fastcall virtual ~TDirectionsRequest();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	__property int Count = {read=GetCount, nodefault};
	__property TWaypoint* Waypoints[int I] = {read=GetWaypoint/*, default*/};
	
__published:
	__property bool AvoidHighways = {read=FAvoidHighways, write=FAvoidHighways, default=0};
	__property bool AvoidTolls = {read=FAvoidTolls, write=FAvoidTolls, default=0};
	__property TLatLngStr* Destination = {read=FDestination, write=FDestination};
	__property bool OptimizeWaypoints = {read=FOptimizeWaypoints, write=FOptimizeWaypoints, default=0};
	__property TLatLngStr* Origin = {read=FOrigin, write=FOrigin};
	__property bool ProvideRouteAlt = {read=FProvideRouteAlt, write=FProvideRouteAlt, default=1};
	__property Gmconstants::TRegion Region = {read=FRegion, write=FRegion, default=0};
	__property TTransitOptions* TransitOpt = {read=FTransitOpt, write=FTransitOpt};
	__property Gmconstants::TTravelMode TravelMode = {read=FTravelMode, write=FTravelMode, default=1};
	__property Gmconstants::TUnitSystem UnitSystem = {read=FUnitSystem, write=FUnitSystem, default=1};
	__property TWaypointsList* WaypointsList = {read=FWaypointsList, write=SetWaypointsList};
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TMarkerOptions : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	bool FDraggable;
	System::UnicodeString FIcon;
	bool FFlat;
	bool FClickable;
	System::Classes::TNotifyEvent FOnChange;
	void __fastcall SetClickable(const bool Value);
	void __fastcall SetDraggable(const bool Value);
	void __fastcall SetFlat(const bool Value);
	void __fastcall SetIcon(const System::UnicodeString Value);
	
protected:
	__property System::Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	
public:
	__fastcall virtual TMarkerOptions(System::Classes::TPersistent* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property bool Clickable = {read=FClickable, write=SetClickable, default=1};
	__property bool Draggable = {read=FDraggable, write=SetDraggable, default=0};
	__property bool Flat = {read=FFlat, write=SetFlat, default=1};
	__property System::UnicodeString Icon = {read=FIcon, write=SetIcon};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TMarkerOptions() { }
	
};


class PASCALIMPLEMENTATION TCustomPolylineOptions : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	int FStrokeWeight;
	bool FGeodesic;
	bool FClickable;
	double FStrokeOpacity;
	System::Classes::TNotifyEvent FOnChange;
	void __fastcall SetStrokeOpacity(const double Value);
	void __fastcall SetStrokeWeight(const int Value);
	void __fastcall SetClickable(const bool Value);
	void __fastcall SetGeodesic(const bool Value);
	
protected:
	virtual System::UnicodeString __fastcall GetStrokeColor() = 0 ;
	__property System::Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	
public:
	__fastcall virtual TCustomPolylineOptions(System::Classes::TPersistent* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property bool Clickable = {read=FClickable, write=SetClickable, default=1};
	__property bool Geodesic = {read=FGeodesic, write=SetGeodesic, default=0};
	__property double StrokeOpacity = {read=FStrokeOpacity, write=SetStrokeOpacity};
	__property int StrokeWeight = {read=FStrokeWeight, write=SetStrokeWeight, default=2};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TCustomPolylineOptions() { }
	
};


class PASCALIMPLEMENTATION TCustomDirectionsRenderer : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	bool FSuppressPolylines;
	bool FSuppressMarkers;
	bool FSuppressBicyclingLayer;
	TMarkerOptions* FMarkerOptions;
	bool FDraggable;
	bool FSuppressInfoWindows;
	bool FPreserveViewport;
	System::Classes::TNotifyEvent FOnChange;
	void __fastcall SetDraggable(const bool Value);
	void __fastcall SetPreserveViewport(const bool Value);
	void __fastcall SetSuppressBicyclingLayer(const bool Value);
	void __fastcall SetSuppressInfoWindows(const bool Value);
	void __fastcall SetSuppressMarkers(const bool Value);
	void __fastcall SetSuppressPolylines(const bool Value);
	
protected:
	void __fastcall OnMarkerOptionsChange(System::TObject* Sender);
	void __fastcall OnPolylineOptionsChange(System::TObject* Sender);
	virtual void __fastcall CreatePolylineOptions() = 0 ;
	virtual System::UnicodeString __fastcall PolylineOptionsToStr() = 0 ;
	__property System::Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	
public:
	__fastcall virtual TCustomDirectionsRenderer(System::TObject* aOwner);
	__fastcall virtual ~TCustomDirectionsRenderer();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property bool Draggable = {read=FDraggable, write=SetDraggable, default=0};
	__property TMarkerOptions* MarkerOptions = {read=FMarkerOptions, write=FMarkerOptions};
	__property bool PreserveViewport = {read=FPreserveViewport, write=SetPreserveViewport, default=0};
	__property bool SuppressBicyclingLayer = {read=FSuppressBicyclingLayer, write=SetSuppressBicyclingLayer, default=0};
	__property bool SuppressInfoWindows = {read=FSuppressInfoWindows, write=SetSuppressInfoWindows, default=0};
	__property bool SuppressMarkers = {read=FSuppressMarkers, write=SetSuppressMarkers, default=0};
	__property bool SuppressPolylines = {read=FSuppressPolylines, write=SetSuppressPolylines, default=0};
};


class PASCALIMPLEMENTATION TCustomGMDirection : public Gmmap::TGMObjects
{
	typedef Gmmap::TGMObjects inherited;
	
public:
	TCustomDirectionsResult* operator[](int I) { return this->DirectionsResult[I]; }
	
private:
	TDirectionsRequest* FDirectionsRequest;
	bool FAutoShow;
	bool FHiddeOthers;
	System::Classes::TNotifyEvent FOnDirectionsChanged;
	int __fastcall GetCount();
	TCustomDirectionsResult* __fastcall GetDirectionResult(int I);
	
protected:
	int FCountDirResult;
	System::Contnrs::TObjectList* FDirectionsResult;
	virtual System::UnicodeString __fastcall GetAPIUrl();
	virtual void __fastcall DeleteMapObjects();
	virtual void __fastcall ShowElements();
	virtual void __fastcall EventFired(Gmconstants::TEventType EventType, System::TVarRec *Params, const int Params_High);
	virtual System::UnicodeString __fastcall DirectionsRenderToStr() = 0 ;
	virtual void __fastcall CreateDirectionsRenderObject() = 0 ;
	virtual int __fastcall GetRetournedData() = 0 ;
	
public:
	__fastcall virtual TCustomGMDirection(System::Classes::TComponent* aOwner);
	__fastcall virtual ~TCustomGMDirection();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	virtual void __fastcall Execute();
	TWaypoint* __fastcall AddWaypoint();
	void __fastcall DeleteWaypoint(int Index);
	void __fastcall MoveWaypoint(int CurIndex, int NewIndex);
	void __fastcall ClearWaypoint();
	void __fastcall ShowRoute(int ResultIndex, int RouteIndex, bool HiddeOthers = true);
	void __fastcall Delete(int ResultIndex);
	__property int Count = {read=GetCount, nodefault};
	__property TCustomDirectionsResult* DirectionsResult[int I] = {read=GetDirectionResult/*, default*/};
	
__published:
	__property bool AutoShow = {read=FAutoShow, write=FAutoShow, default=1};
	__property bool HiddeOthers = {read=FHiddeOthers, write=FHiddeOthers, default=1};
	__property TDirectionsRequest* DirectionsRequest = {read=FDirectionsRequest, write=FDirectionsRequest};
	__property System::Classes::TNotifyEvent OnDirectionsChanged = {read=FOnDirectionsChanged, write=FOnDirectionsChanged};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmdirection */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMDIRECTION)
using namespace Gmdirection;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmdirectionHPP
