﻿// CodeGear C++Builder
// Copyright (c) 1995, 2020 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMLinkedComponents.pas' rev: 34.00 (Windows)

#ifndef GmlinkedcomponentsHPP
#define GmlinkedcomponentsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <GMMap.hpp>
#include <GMClasses.hpp>
#include <GMConstants.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmlinkedcomponents
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TLinkedComponent;
class DELPHICLASS TLinkedComponents;
class DELPHICLASS TGMLinkedComponent;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TLinkedComponent : public System::Classes::TCollectionItem
{
	typedef System::Classes::TCollectionItem inherited;
	
private:
	unsigned FIdxList;
	Gmclasses::TBaseInfoWindow* FInfoWindow;
	int FTag;
	System::TObject* FFObject;
	System::UnicodeString FText;
	bool FShowInfoWinMouseOver;
	void __fastcall SetShowInfoWinMouseOver(const bool Value);
	
protected:
	virtual void __fastcall SetIdxList(const unsigned Value);
	void __fastcall OnHTMLContentChange(System::TObject* Sender);
	void __fastcall OnDisableAutoPanChange(System::TObject* Sender);
	void __fastcall OnMaxWidthChange(System::TObject* Sender);
	void __fastcall OnPixelOffsetChange(System::TObject* Sender);
	void __fastcall OnCloseOtherBeforeOpenChange(System::TObject* Sender);
	bool __fastcall SetProperty(System::UnicodeString FunctionName, System::UnicodeString EventName, System::UnicodeString Value, bool Quoted = true)/* overload */;
	bool __fastcall SetProperty(System::UnicodeString FunctionName, System::UnicodeString EventName, bool Value)/* overload */;
	bool __fastcall SetProperty(System::UnicodeString FunctionName, System::UnicodeString EventName, int Value)/* overload */;
	bool __fastcall SetProperty(System::UnicodeString FunctionName, System::UnicodeString EventName, double Value)/* overload */;
	virtual System::UnicodeString __fastcall GetDisplayName();
	virtual bool __fastcall ChangeProperties() = 0 ;
	virtual void __fastcall CenterMapTo() = 0 ;
	__property unsigned IdxList = {read=FIdxList, write=SetIdxList, nodefault};
	__property Gmclasses::TBaseInfoWindow* InfoWindow = {read=FInfoWindow, write=FInfoWindow};
	__property System::UnicodeString Text = {read=FText, write=FText};
	__property bool ShowInfoWinMouseOver = {read=FShowInfoWinMouseOver, write=SetShowInfoWinMouseOver, default=0};
	
public:
	__fastcall virtual TLinkedComponent(System::Classes::TCollection* Collection);
	__fastcall virtual ~TLinkedComponent();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	virtual void __fastcall OpenCloseInfoWin();
	__property System::TObject* FObject = {read=FFObject, write=FFObject};
	
__published:
	__property int Tag = {read=FTag, write=FTag, default=0};
};

#pragma pack(pop)

typedef System::TMetaClass* TLinkedComponentClass;

#pragma pack(push,4)
class PASCALIMPLEMENTATION TLinkedComponents : public System::Classes::TCollection
{
	typedef System::Classes::TCollection inherited;
	
public:
	TLinkedComponent* operator[](int I) { return this->Items[I]; }
	
private:
	TLinkedComponent* __fastcall GetItems(int I);
	void __fastcall SetItems(int I, TLinkedComponent* const Value);
	
protected:
	TGMLinkedComponent* FGMLinkedComponent;
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	HIDESBASE TLinkedComponent* __fastcall Add();
	HIDESBASE TLinkedComponent* __fastcall Insert(int Index);
	HIDESBASE void __fastcall Delete(int Index);
	void __fastcall Move(int CurIndex, int NewIndex);
	HIDESBASE void __fastcall Clear();
	__property TLinkedComponent* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
	
public:
	__fastcall virtual TLinkedComponents(TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TLinkedComponents() { }
	
};

#pragma pack(pop)

typedef System::TMetaClass* TLinkedComponentsClass;

typedef void __fastcall (__closure *TLinkedComponentChange)(System::TObject* Sender, int Index, TLinkedComponent* LinkedComponent);

typedef void __fastcall (__closure *TLatLngIdxEvent)(System::TObject* Sender, Gmclasses::TLatLng* LatLng, int Index, TLinkedComponent* LinkedComponent);

class PASCALIMPLEMENTATION TGMLinkedComponent : public Gmmap::TGMObjects
{
	typedef Gmmap::TGMObjects inherited;
	
public:
	TLinkedComponent* operator[](int I) { return this->Items[I]; }
	
private:
	TLinkedComponents* FVisualObjects;
	TLinkedComponentChange FOnCloseClick;
	bool FAutoUpdate;
	TLinkedComponentChange FOnCloseOtherBeforeOpenChange;
	TLinkedComponentChange FOnDisableAutoPanChange;
	TLinkedComponentChange FOnMaxWidthChange;
	TLinkedComponentChange FOnPixelOffsetChange;
	TLinkedComponentChange FOnHTMLContentChange;
	void __fastcall SetAutoUpdate(const bool Value);
	
protected:
	virtual void __fastcall SetIdxList(const unsigned Value);
	TLinkedComponent* __fastcall GetItems(int I);
	virtual void __fastcall ErrorControl();
	virtual void __fastcall DeleteMapObjects();
	virtual void __fastcall EventFired(Gmconstants::TEventType EventType, System::TVarRec *Params, const int Params_High);
	virtual TLinkedComponentClass __fastcall GetCollectionItemClass();
	virtual TLinkedComponentsClass __fastcall GetCollectionClass();
	int __fastcall GetCount();
	__property TLinkedComponent* Items[int I] = {read=GetItems/*, default*/};
	
public:
	__fastcall virtual TGMLinkedComponent(System::Classes::TComponent* AOwner);
	__fastcall virtual ~TGMLinkedComponent();
	virtual void __fastcall ShowElements();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	TLinkedComponent* __fastcall Add();
	void __fastcall Delete(int Index);
	void __fastcall Move(int CurIndex, int NewIndex);
	void __fastcall Clear();
	__property int Count = {read=GetCount, nodefault};
	__property TLinkedComponents* VisualObjects = {read=FVisualObjects, write=FVisualObjects};
	
__published:
	__property bool AutoUpdate = {read=FAutoUpdate, write=SetAutoUpdate, default=1};
	__property TLinkedComponentChange OnCloseClick = {read=FOnCloseClick, write=FOnCloseClick};
	__property TLinkedComponentChange OnHTMLContentChange = {read=FOnHTMLContentChange, write=FOnHTMLContentChange};
	__property TLinkedComponentChange OnDisableAutoPanChange = {read=FOnDisableAutoPanChange, write=FOnDisableAutoPanChange};
	__property TLinkedComponentChange OnMaxWidthChange = {read=FOnMaxWidthChange, write=FOnMaxWidthChange};
	__property TLinkedComponentChange OnPixelOffsetChange = {read=FOnPixelOffsetChange, write=FOnPixelOffsetChange};
	__property TLinkedComponentChange OnCloseOtherBeforeOpenChange = {read=FOnCloseOtherBeforeOpenChange, write=FOnCloseOtherBeforeOpenChange};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmlinkedcomponents */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMLINKEDCOMPONENTS)
using namespace Gmlinkedcomponents;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmlinkedcomponentsHPP
