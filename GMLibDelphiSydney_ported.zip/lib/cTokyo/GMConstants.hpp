﻿// CodeGear C++Builder
// Copyright (c) 1995, 2020 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMConstants.pas' rev: 34.00 (Windows)

#ifndef GmconstantsHPP
#define GmconstantsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmconstants
{
//-- forward type declarations -----------------------------------------------
//-- type declarations -------------------------------------------------------
enum DECLSPEC_DENUM TLang : unsigned char { Espanol, English, French, PortuguesBR, Danish, German, Russian, Hungarian, Italian };

enum DECLSPEC_DENUM TEventType : unsigned char { etMarkerClick, etMarkerDblClick, etMarkerDrag, etMarkerDragEnd, etMarkerDragStart, etMarkerMouseDown, etMarkerMouseOut, etMarkerMouseOver, etMarkerMouseUp, etMarkerRightClick, etInfoWinCloseClick, etInfoWinCloseOBO, etInfoWinDisableAP, etInfoWinHTMLContent, etInfoWinMaxWidth, etPixelOffset, etPolylineClick, etPolylineDblClick, etPolylineMouseDown, etPolylineMouseMove, etPolylineMouseOut, etPolylineMouseOver, etPolylineMouseUp, etPolylineRightClick, etRectangleClick, etRectangleDblClick, etRectangleMouseDown, etRectangleMouseMove, etRectangleMouseOut, etRectangleMouseOver, etRectangleMouseUp, etRectangleRightClick, etRectangleBoundsChange, etCircleClick, etCircleDblClick, etCircleMouseDown, etCircleMouseMove, 
	etCircleMouseOut, etCircleMouseOver, etCircleMouseUp, etCircleRightClick, etCircleCenterChange, etCircleRadiusChange, etGOClick, etGODblClick, etDirectionsChanged };

enum DECLSPEC_DENUM TMapTypeId : unsigned char { mtHYBRID, mtROADMAP, mtSATELLITE, mtTERRAIN, mtOSM };

typedef System::Set<TMapTypeId, TMapTypeId::mtHYBRID, TMapTypeId::mtOSM> TMapTypeIds;

enum DECLSPEC_DENUM TMapTypeControlStyle : unsigned char { mtcDEFAULT, mtcDROPDOWN_MENU, mtcHORIZONTAL_BAR };

enum DECLSPEC_DENUM TScaleControlStyle : unsigned char { scDEFAULT };

enum DECLSPEC_DENUM TZoomControlStyle : unsigned char { zcDEFAULT, zcLARGE, zcSMALL };

enum DECLSPEC_DENUM TControlPosition : unsigned char { cpBOTTOM_CENTER, cpBOTTOM_LEFT, cpBOTTOM_RIGHT, cpLEFT_BOTTOM, cpLEFT_CENTER, cpLEFT_TOP, cpRIGHT_BOTTOM, cpRIGHT_CENTER, cpRIGHT_TOP, cpTOP_CENTER, cpTOP_LEFT, cpTOP_RIGHT };

enum DECLSPEC_DENUM TAnimation : unsigned char { anBOUNCE, anDROP };

enum DECLSPEC_DENUM TGeocoderStatus : unsigned char { gsERROR, gsINVALID_REQUEST, gsOK, gsOVER_QUERY_LIMIT, gsREQUEST_DENIED, gsUNKNOWN_ERROR, gsZERO_RESULTS, gsWithoutState };

enum DECLSPEC_DENUM TGeocoderLocationType : unsigned char { gltAPPROXIMATE, gltGEOMETRIC_CENTER, gltRANGE_INTERPOLATED, gltROOFTOP, gltNOTHING };

enum DECLSPEC_DENUM TLangCode : unsigned char { lc_NOT_DEFINED, lcARABIC, lcBASQUE, lcBENGALI, lcBULGARIAN, lcCATALAN, lcCHINESE_SIMPLIFIED, lcCHINESE_TRADITIONAL, lcCROATIAN, lcCZECH, lcDANISH, lcDUTCH, lcENGLISH, lcENGLISH_AUSTRALIAN, lcENGLISH_GREAT_BRITAIN, lcFARSI, lcFILIPINO, lcFINNISH, lcFRENCH, lcGALICIAN, lcGERMAN, lcGREEK, lcGUJARATI, lcHEBREW, lcHINDI, lcHUNGARIAN, lcINDONESIAN, lcITALIAN, lcJAPANESE, lcKANNADA, lcKOREAN, lcLATVIAN, lcLITHUANIAN, lcMALAYALAM, lcMARATHI, lcNORWEGIAN, lcPOLISH, lcPORTUGUESE, lcPORTUGUESE_BRAZIL, lcPORTUGUESE_PORTUGAL, lcROMANIAN, lcRUSSIAN, lcSERBIAN, lcSLOVAK, lcSLOVENIAN, lcSPANISH, lcSWEDISH, lcTAGALOG, lcTAMIL, lcTELUGU, lcTHAI, lcTURKISH, lcUKRAINIAN, lcVIETNAMESE };

enum DECLSPEC_DENUM TRegion : unsigned char { r_NO_REGION, rAFGHANISTAN, rALAND, rALBANIA, rALGERIA, rAMERICAN_SAMOA, rANDORRA, rANGOLA, rANGUILLA, rANTARCTICA, rANTIGUA_AND_BARBUDA, rARGENTINA, rARMENIA, rARUBA, rASCENSION_ISLAND, rAUSTRALIA, rAUSTRIA, rAZERBAIJAN, rBAHAMAS, rBAHRAIN, rBANGLADESH, rBARBADOS, rBELARUS, rBELGIUM, rBELIZE, rBENIN, rBERMUDA, rBHUTAN, rBOLIVIA, rBOSNIA_AND_HERZEGOVINA, rBOTSWANA, rBRAZIL, rBRITISH_INDIAN_OCEAN_TERRITORY, rBRITISH_VIRGIN_ISLANDS, rBRUNEI, rBULGARIA, rBURKINA_FASO, rBURUNDI, rCAMBODIA, rCAMEROON, rCANADA, rCAPE_VERDE, rCAYMAN_ISLANDS, rCENTRAL_AFRICAN_REPUBLIC, rCHAD, rCHILE, rCHRISTMAS_ISLAND, rCOCOS_KEELING_ISLANDS, rCOLOMBIA, rCOMOROS, rCOOK_ISLANDS, rCOSTA_RICA, rCOTE_D_IVOIRE, rCROATIA, rCUBA, rCYPRUS, 
	rCZECH_REPUBLIC, rDEMOCRATIC_PEOPLE_S_REPUBLIC_OF_KOREA, rDEMOCRATIC_REPUBLIC_OF_THE_CONGO, rDENMARK, rDJIBOUTI, rDOMINICA, rDOMINICAN_REPUBLIC, rEAST_TIMOR, rECUADOR, rEGYPT, rEL_SALVADOR, rEQUATORIAL_GUINEA, rERITREA, rESTONIA, rETHIOPIA, rEUROPEAN_UNION, rFALKLAND_ISLANDS, rFAROE_ISLANDS, rFEDERATED_STATES_OF_MICRONESIA, rFIJI, rFINLAND, rFRANCE, rFRENCH_GUIANA, rFRENCH_POLYNESIA, rFRENCH_SOUTHERN_AND_ANTARCTIC_LANDS, rGABON, rGEORGIA, rGERMANY, rGHANA, rGIBRALTAR, rGREECE, rGREENLAND, rGRENADA, rGUADELOUPE, rGUAM, rGUATEMALA, rGUERNSEY, rGUINEA, rGUINEA_BISSAU, rGUYANA, rHAITI, rHEARD_ISLAND_AND_MCDONALD_ISLANDS, rHONDURAS, rHONG_KONG, rHUNGARY, rICELAND, rINDIA, rINDONESIA, rIRAN, rIRAQ, rISLE_OF_MAN, rISRAEL, rITALY, rJAMAICA, rJAPAN, rJERSEY, rJORDAN, 
	rKAZAKHSTAN, rKENYA, rKIRIBATI, rKUWAIT, rKYRGYZSTAN, rLAOS, rLATVIA, rLEBANON, rLESOTHO, rLIBERIA, rLIBYA, rLIECHTENSTEIN, rLITHUANIA, rLUXEMBOURG, rMACAU, rMACEDONIA, rMADAGASCAR, rMALAWI, rMALAYSIA, rMALDIVES, rMALI, rMALTA, rMARSHALL_ISLANDS, rMARTINIQUE, rMAURITANIA, rMAURITIUS, rMAYOTTE, rMEXICO, rMOLDOVA, rMONACO, rMONGOLIA, rMONTENEGRO, rMONTSERRAT, rMOROCCO, rMOZAMBIQUE, rMYANMAR, rNAMIBIA, rNAURU, rNEPAL, rNETHERLANDS, rNETHERLANDS_ANTILLES, rNEW_CALEDONIA, rNEW_ZEALAND, rNICARAGUA, rNIGER, rNIGERIA, rNIUE, rNORFOLK_ISLAND, rNORTHERN_MARIANA_ISLANDS, rNORWAY, rOMAN, rPAKISTAN, rPALAU, rPALESTINIAN_TERRITORIES, rPANAMA, rPAPUA_NEW_GUINEA, rPARAGUAY, rPEOPLE_S_REPUBLIC_OF_CHINA, rPERU, rPHILIPPINES, rPITCAIRN_ISLANDS, rPOLAND, rPORTUGAL, 
	rPUERTO_RICO, rQATAR, rREPUBLIC_OF_IRELAND_AND_NORTHERN_IRELAND, rREPUBLIC_OF_KOREA, rREPUBLIC_OF_THE_CONGO, rREUNION, rROMANIA, rRUSSIA, rRWANDA, rSAINT_HELENA, rSAINT_KITTS_AND_NEVIS, rSAINT_LUCIA, rSAINT_VINCENT_AND_THE_GRENADINES, rSAINT_PIERRE_AND_MIQUELON, rSAMOA, rSAN_MARINO, rSAO_TOME_AND_PRINCIPE, rSAUDI_ARABIA, rSENEGAL, rSERBIA, rSEYCHELLES, rSIERRA_LEONE, rSINGAPORE, rSLOVAKIA, rSLOVENIA, rSOLOMON_ISLANDS, rSOMALIA, rSOUTH_AFRICA, rSOUTH_GEORGIA_AND_THE_SOUTH_SANDWICH_ISLANDS, rSOUTH_SUDAN, rSPAIN, rSRI_LANKA, rSUDAN, rSURINAME, rSWAZILAND, rSWEDEN, rSWITZERLAND, rSYRIA, rTAIWAN, rTAJIKISTAN, rTANZANIA, rTHAILAND, rTHE_GAMBIA, rTOGO, rTOKELAU, rTONGA, rTRINIDAD_AND_TOBAGO, rTUNISIA, rTURKEY, rTURKMENISTAN, rTURKS_AND_CAICOS_ISLANDS, rTUVALU, 
	rUGANDA, rUKRAINE, rUNITED_ARAB_EMIRATES, rUNITED_KINGDOM, rUNITED_STATES_OF_AMERICA, rUNITED_STATES_VIRGIN_ISLANDS, rURUGUAY, rUZBEKISTAN, rVANUATU, rVATICAN_CITY, rVENEZUELA, rVIETNAM, rWALLIS_AND_FUTUNA, rWESTERN_SAHARA, rYEMEN, rZAMBIA, rZIMBABWE };

enum DECLSPEC_DENUM TTravelMode : unsigned char { tmBICYCLING, tmDRIVING, tmTRANSIT, tmWALKING };

enum DECLSPEC_DENUM TUnitSystem : unsigned char { usIMPERIAL, usMETRIC };

enum DECLSPEC_DENUM TVehicleType : unsigned char { vtRAIL, vtMETRO_RAIL, vtSUBWAY, vtTRAM, vtMONORAIL, vtHEAVY_RAIL, vtCOMMUTER_TRAIN, vtHIGH_SPEED_TRAIN, vtBUS, vtINTERCITY_BUS, vtTROLLEYBUS, vtSHARE_TAXI, vtFERRY, vtCABLE_CAR, vtGONDOLA_LIFT, vtFUNICULAR, vtOTHER };

enum DECLSPEC_DENUM TDirectionsStatus : unsigned char { dsINVALID_REQUEST, dsMAX_WAYPOINTS_EXCEEDED, dsNOT_FOUND, dsOK, dsOVER_QUERY_LIMIT, dsREQUEST_DENIED, dsUNKNOWN_ERROR, dsZERO_RESULTS };

enum DECLSPEC_DENUM TLabelColor : unsigned char { lcBLACK, lcWHITE };

enum DECLSPEC_DENUM TTemperatureUnit : unsigned char { tuCELSIUS, tuFAHRENHEIT };

enum DECLSPEC_DENUM TWindSpeedUnit : unsigned char { wsKILOMETERS_PER_HOUR, wsMETERS_PER_SECOND, wsMILES_PER_HOUR };

enum DECLSPEC_DENUM TSymbolPath : unsigned char { spNONE, spBACKWARD_CLOSED_ARROW, spBACKWARD_OPEN_ARROW, spCIRCLE, spFORWARD_CLOSED_ARROW, spFORWARD_OPEN_ARROW, spDASHEDLINE };

enum DECLSPEC_DENUM TMeasure : unsigned char { mPixels, mPercentage };

enum DECLSPEC_DENUM TMarkerType : unsigned char { mtStandard, mtColored, mtStyledMarker };

enum DECLSPEC_DENUM TStyledIcon : unsigned char { siMarker, siBubble };

enum DECLSPEC_DENUM TBorderStyle : unsigned char { bsNone, bsDotted, bsDsahed, bsSolid, bsDouble, bsGrove, bsRidge, bsInset, bsOutset };

enum DECLSPEC_DENUM TElevationType : unsigned char { etAlongPath, etForLocations };

enum DECLSPEC_DENUM TElevationStatus : unsigned char { esINVALID_REQUEST, esOK, esOVER_QUERY_LIMIT, esREQUEST_DENIED, esUNKNOWN_ERROR, esNO_REQUEST };

enum DECLSPEC_DENUM TGradient : unsigned char { grHot, grCool };

//-- var, const, procedure ---------------------------------------------------
#define GMLIB_Version L"[1.5.5 Final]"
#define GMLIB_VerText L"1.5.5 Final"
#define AboutGMLibTxt L"About GMLib"
#define MEditor L"Marker Editor"
#define StrColoredMarker L"http://chart.apis.google.com/chart?cht=mm&chs=%dx%d&chco=%"\
	L"s,%s,%s&ext=.png"
#define RES_MAPA_CODE L"RES_MAPCODE"
extern DELPHI_PACKAGE System::UnicodeString C_API_KEY;
#define MapForm L"mapdata"
#define LatLngBoundsForm L"latlngboundsdata"
#define ErrorForm L"errordata"
#define PolylineForm L"polylinedata"
#define RectangleForm L"rectangledata"
#define CircleForm L"circledata"
#define DirectionsForm L"directionsdata"
#define GeocoderForm L"geocoderdata"
#define ElevationsForm L"elevationsdata"
#define GeometryForm L"geometrydata"
#define MaxZoomdForm L"maxzoomdata"
#define EventsMapForm L"eventsMap"
#define EventsInfoWinForm L"eventsInfoWin"
#define EventsMarkerForm L"eventsMarker"
#define EventsPolylineForm L"eventsPolyline"
#define EventsRectangleForm L"eventsRectangle"
#define EventsCircleForm L"eventsCircle"
#define EventsDirectionForm L"eventsDirection"
#define EventsGroundOverlay L"eventsGO"
#define LatLngBoundsFormSWLat L"swLat"
#define LatLngBoundsFormSWLng L"swLng"
#define LatLngBoundsFormNELat L"neLat"
#define LatLngBoundsFormNELng L"neLng"
#define LatLngBoundsFormContains L"contains"
#define MapFormMapIsNull L"mapisnull"
#define MapFormLat L"lat"
#define MapFormLng L"lng"
#define MapFormMapTypeId L"maptype"
#define MapFormZoom L"zoom"
#define PolylineFormPath L"path"
#define PolylineFormLat L"lat"
#define PolylineFormLng L"lng"
#define RectangleFormLat L"lat"
#define RectangleFormLng L"lng"
#define CircleFormNELat L"NELat"
#define CircleFormNELng L"NELng"
#define CircleFormSWLat L"SWLat"
#define CircleFormSWLng L"SWLng"
#define DirectionsFormXML L"xml"
#define DirectionsFormResponse L"response"
#define GeocoderFormXML L"xml"
#define GeocoderFormResponse L"response"
#define ElevationsFormStatus L"status"
#define ElevationsFormElevations L"elevations"
#define ElevationsFormResponse L"response"
#define GeometryFormEncodedPath L"encodedPath"
#define GeometryFormDecodedPath L"decodedPath"
#define GeometryFormContainsLocation L"cntLoc"
#define GeometryFormIsLocationOnEdge L"isLoc"
#define GeometryFormComputeArea L"comArea"
#define GeometryFormComputeDist L"comDist"
#define GeometryFormComputeHea L"comHea"
#define GeometryFormComputeLength L"comLength"
#define GeometryFormComputeOffLat L"comOffLat"
#define GeometryFormComputeOffLng L"comOffLng"
#define GeometryFormComputeSigA L"comSigA"
#define GeometryFormInterLat L"interLat"
#define GeometryFormInterLng L"interLng"
#define ErrorFormErrorCode L"errorCode"
#define MaxZoomdFormStatus L"status"
#define MaxZoomdFormMaxZoom L"maxzoom"
#define MaxZoomdFormResponse L"response"
#define EventsFormEventFired L"eventfired"
#define EventsFormLinkCompId L"linkCompId"
#define EventsFormLinkCompZIndex L"linkCompZIndex"
#define EventsFormLat L"lat"
#define EventsFormLng L"lng"
#define EventsFormSWLat L"swLat"
#define EventsFormSWLng L"swLng"
#define EventsFormNELat L"neLat"
#define EventsFormNELng L"neLng"
#define EventsFormClick L"click"
#define EventsFormDblClick L"dblclick"
#define EventsFormDrag L"drag"
#define EventsFormDragEnd L"dragEnd"
#define EventsFormDragStart L"dragStart"
#define EventsFormMouseMove L"mouseMove"
#define EventsFormMouseOver L"mouseOver"
#define EventsFormMouseOut L"mouseOut"
#define EventsFormMouseDown L"mouseDown"
#define EventsFormMouseUp L"mouseUp"
#define EventsFormRightClick L"rightClick"
#define EventsFormBoundsChange L"boundsChange"
#define EventsFormCenterChange L"centerChange"
#define EventsFormMapTypeIdChanged L"mapTypeId_changed"
#define EventsFormTilesLoaded L"tilesLoaded"
#define EventsFormZoomChanged L"zoomChanged"
#define EventsFormMapTypeId L"mapTypeId"
#define EventsFormZoom L"zoom"
#define EventsFormWeatherClick L"weatherClick"
#define EventsFormWeatherLat L"weatherLat"
#define EventsFormWeatherLng L"weatherLng"
#define EventsFormWeatherFeature L"weatherFeature"
#define EventsFormPanoClick L"panoClick"
#define EventsFormPanoLat L"panoLat"
#define EventsFormPanoLng L"panoLng"
#define EventsFormPanoAuthor L"panoAuthor"
#define EventsFormPanoPhotoId L"panoPhotoId"
#define EventsFormPanoTitle L"panoTitle"
#define EventsFormPanoUrl L"panoUrl"
#define EventsFormPanoUserId L"panoUserId"
static const System::WideChar EventsFormX = (System::WideChar)(0x78);
static const System::WideChar EventsFormY = (System::WideChar)(0x79);
#define EventsMarkerAnimChng L"marker_animation_changed"
#define EventsMarkerAnim L"marker_animation"
#define EventsFormInfoWinCloseClick L"infoWinCloseClick"
#define EventsFormCircleRadiusChange L"radiusChange"
#define EventsFormCircleRadius L"radius"
#define EventsFormXML L"xml"
#define EventsFormDirectionsChanged L"directions_changed"
#define LBL_WEATHERFEATURE L"WeatherFeature"
#define LBL_W_LOCATION L"location"
#define LBL_W_TEMPERATUREUNIT L"temperatureUnit"
#define LBL_W_WINDSPEEDUNIT L"windSpeedUnit"
#define LBL_W_CURRENT L"current"
#define LBL_W_DAY L"day"
#define LBL_W_DESCRIPTION L"description"
#define LBL_W_HIGH L"high"
#define LBL_W_HUMIDITY L"humidity"
#define LBL_W_LOW L"low"
#define LBL_W_SHORTDAY L"shortDay"
#define LBL_W_TEMPERATURE L"temperature"
#define LBL_W_WINDDIRECTION L"windDirection"
#define LBL_W_WINDSPEED L"windSpeed"
#define LBL_W_FORECAST L"forecast"
#define LBL_GEOCODERESPONSE L"GeocodeResponse"
#define LBL_STATUS L"status"
#define LBL_RESULT L"result"
#define LBL_TYPE L"type"
#define LBL_FORMATTED_ADDRESS L"formatted_address"
#define LBL_ADDRCOMPONENT L"address_component"
#define LBL_GEOMETRY L"geometry"
#define LBL_LOCATION L"location"
#define LBL_LAT L"lat"
#define LBL_LNG L"lng"
#define LBL_LOCATION_TYPE L"location_type"
#define LBL_VIEWPORT L"viewport"
#define LBL_BOUNDS L"bounds"
#define LBL_SOUTHWEST L"southwest"
#define LBL_NORTHEAST L"northeast"
#define LBL_LONG_NAME L"long_name"
#define LBL_SHORT_NAME L"short_name"
#define LBL_D_DIRECTIONSRESPONSE L"DirectionsResponse"
#define LBL_D_STATUS L"status"
#define LBL_D_ROUTE L"route"
#define LBL_D_SUMMARY L"summary"
#define LBL_D_COPYRIGHTS L"copyrights"
#define LBL_D_BOUNDS L"bounds"
#define LBL_D_SOUTHWEST L"southwest"
#define LBL_D_NORTHEAST L"northeast"
#define LBL_D_LAT L"lat"
#define LBL_D_LNG L"lng"
#define LBL_D_WARNING L"warning"
#define LBL_D_WAYPOINTORDER L"waypoint_order"
#define LBL_D_OVERVIEWPATH L"overview_path"
#define LBL_D_LEG L"leg"
#define LBL_D_ARRIVALTIME L"arrival_time"
#define LBL_D_TEXT L"text"
#define LBL_D_VALUE L"value"
#define LBL_D_DEPARTURETIME L"departure_time"
#define LBL_D_DISTANCE L"distance"
#define LBL_D_DURATION L"duration"
#define LBL_D_ENDADDRESS L"end_address"
#define LBL_D_STARTADDRESS L"start_address"
#define LBL_D_ENDLOCATION L"end_location"
#define LBL_D_STARTLOCATION L"start_location"
#define LBL_D_VIAWAYPOINTS L"via_waypoints"
#define LBL_D_STEP L"step"
#define LBL_D_INSTRUCTIONS L"instructions"
#define LBL_D_PATH L"path"
#define LBL_D_STEPS L"steps"
#define LBL_D_TRAVELMODE L"travel_mode"
#define LBL_D_TRANSIT L"transit"
#define LBL_D_ARRIVALSTOP L"arrival_stop"
#define LBL_D_LOCATION L"location"
#define LBL_D_NAME L"name"
#define LBL_D_TIMEZONE L"time_zone"
#define LBL_D_DEPARTURESTOP L"departure_stop"
#define LBL_D_HEADSIGN L"headsign"
#define LBL_D_HEADWAY L"headway"
#define LBL_D_NUMSTOPS L"num_stops"
#define LBL_D_LINE L"line"
#define LBL_D_COLOR L"color"
#define LBL_D_ICON L"icon"
#define LBL_D_SHORTNAME L"short_name"
#define LBL_D_TEXTCOLOR L"text_color"
#define LBL_D_URL L"url"
#define LBL_D_VEHICLE L"vehicle"
#define LBL_D_LOCALICON L"local_icon"
#define LBL_D_TYPE L"type"
#define LBL_D_AGENCIES L"agencies"
#define LBL_D_PHONE L"phone"
}	/* namespace Gmconstants */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMCONSTANTS)
using namespace Gmconstants;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmconstantsHPP
