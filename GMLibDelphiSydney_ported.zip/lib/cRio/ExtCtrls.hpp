//-- WARNING -----------------------------------------------------------------
// Deprecated legacy header
//----------------------------------------------------------------------------
#ifdef WARN_LEGACY_HEADER_USAGE
  #pragma message("Include <Vcl.ExtCtrls.hpp> instead")
#endif
#ifdef ERROR_LEGACY_HEADER_USAGE
  #error Include 'Vcl.ExtCtrls.hpp' instead
#endif

#include <Vcl.ExtCtrls.hpp>
