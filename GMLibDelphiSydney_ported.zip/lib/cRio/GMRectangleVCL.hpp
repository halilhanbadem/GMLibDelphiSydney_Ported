﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMRectangleVCL.pas' rev: 34.00 (Windows)

#ifndef GmrectanglevclHPP
#define GmrectanglevclHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Vcl.Graphics.hpp>
#include <System.Classes.hpp>
#include <GMRectangle.hpp>
#include <GMLinkedComponents.hpp>
#include <System.UITypes.hpp>
#include <GMMap.hpp>
#include <GMClasses.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmrectanglevcl
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TRectangle;
class DELPHICLASS TRectangles;
class DELPHICLASS TGMRectangle;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TRectangle : public Gmrectangle::TCustomRectangle
{
	typedef Gmrectangle::TCustomRectangle inherited;
	
private:
	System::Uitypes::TColor FFillColor;
	System::Uitypes::TColor FStrokeColor;
	void __fastcall SetFillColor(const System::Uitypes::TColor Value);
	void __fastcall SetStrokeColor(const System::Uitypes::TColor Value);
	
protected:
	virtual System::UnicodeString __fastcall GetFillColor();
	virtual System::UnicodeString __fastcall GetStrokeColor();
	
public:
	__fastcall virtual TRectangle(System::Classes::TCollection* Collection);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::Uitypes::TColor FillColor = {read=FFillColor, write=SetFillColor, default=255};
	__property System::Uitypes::TColor StrokeColor = {read=FStrokeColor, write=SetStrokeColor, default=0};
public:
	/* TCustomRectangle.Destroy */ inline __fastcall virtual ~TRectangle() { }
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TRectangles : public Gmrectangle::TCustomRectangles
{
	typedef Gmrectangle::TCustomRectangles inherited;
	
public:
	TRectangle* operator[](int I) { return this->Items[I]; }
	
private:
	HIDESBASE void __fastcall SetItems(int I, TRectangle* const Value);
	HIDESBASE TRectangle* __fastcall GetItems(int I);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	HIDESBASE TRectangle* __fastcall Add();
	HIDESBASE TRectangle* __fastcall Insert(int Index);
	__property TRectangle* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TLinkedComponents.Create */ inline __fastcall virtual TRectangles(Gmlinkedcomponents::TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass) : Gmrectangle::TCustomRectangles(GMLinkedComponent, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TRectangles() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TGMRectangle : public Gmrectangle::TCustomGMRectangle
{
	typedef Gmrectangle::TCustomGMRectangle inherited;
	
public:
	TRectangle* operator[](int I) { return this->Items[I]; }
	
protected:
	HIDESBASE TRectangle* __fastcall GetItems(int I);
	virtual Gmlinkedcomponents::TLinkedComponentClass __fastcall GetCollectionItemClass();
	virtual Gmlinkedcomponents::TLinkedComponentsClass __fastcall GetCollectionClass();
	
public:
	HIDESBASE TRectangle* __fastcall Add(double SWLat = 0.000000E+00, double SWLng = 0.000000E+00, double NELat = 0.000000E+00, double NELng = 0.000000E+00);
	__property TRectangle* Items[int I] = {read=GetItems/*, default*/};
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual TGMRectangle(System::Classes::TComponent* AOwner) : Gmrectangle::TCustomGMRectangle(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~TGMRectangle() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmrectanglevcl */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMRECTANGLEVCL)
using namespace Gmrectanglevcl;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmrectanglevclHPP
