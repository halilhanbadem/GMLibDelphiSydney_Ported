﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMFunctionsVCL.pas' rev: 34.00 (Windows)

#ifndef GmfunctionsvclHPP
#define GmfunctionsvclHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Vcl.Graphics.hpp>
#include <GMFunctions.hpp>
#include <GMPolygonVCL.hpp>
#include <GMClasses.hpp>
#include <GMPolyline.hpp>
#include <GMLinkedComponents.hpp>
#include <GMMap.hpp>
#include <System.Classes.hpp>
#include <System.UITypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmfunctionsvcl
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS THackGMPolygon;
class DELPHICLASS TGeometry;
class DELPHICLASS TTransform;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION THackGMPolygon : public Gmpolygonvcl::TGMPolygon
{
	typedef Gmpolygonvcl::TGMPolygon inherited;
	
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual THackGMPolygon(System::Classes::TComponent* AOwner) : Gmpolygonvcl::TGMPolygon(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~THackGMPolygon() { }
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TGeometry : public Gmfunctions::TGeometry
{
	typedef Gmfunctions::TGeometry inherited;
	
public:
	__classmethod bool __fastcall ContainsLocation(Gmpolygonvcl::TGMPolygon* GMPoly, int Idx, Gmclasses::TLatLng* LatLng);
public:
	/* TObject.Create */ inline __fastcall TGeometry() : Gmfunctions::TGeometry() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TGeometry() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TTransform : public Gmfunctions::TCustomTransform
{
	typedef Gmfunctions::TCustomTransform inherited;
	
public:
	__classmethod System::UnicodeString __fastcall TColorToStr(System::Uitypes::TColor Color);
public:
	/* TObject.Create */ inline __fastcall TTransform() : Gmfunctions::TCustomTransform() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TTransform() { }
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmfunctionsvcl */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMFUNCTIONSVCL)
using namespace Gmfunctionsvcl;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmfunctionsvclHPP
