﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMFunctions.pas' rev: 34.00 (Windows)

#ifndef GmfunctionsHPP
#define GmfunctionsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <GMConstants.hpp>
#include <GMPolyline.hpp>
#include <GMClasses.hpp>
#include <GMLinkedComponents.hpp>
#include <GMMap.hpp>
#include <System.Classes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmfunctions
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TGMGenFunc;
class DELPHICLASS THackGMLinkedComponent;
class DELPHICLASS THackMap;
class DELPHICLASS TGeometry;
class DELPHICLASS TPath;
class DELPHICLASS TCustomTransform;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TGMGenFunc : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void __fastcall ProcessMessages();
	__classmethod System::UnicodeString __fastcall PointsToStr(Gmclasses::TLatLng* *Points, const int Points_High, int Precision);
public:
	/* TObject.Create */ inline __fastcall TGMGenFunc() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TGMGenFunc() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION THackGMLinkedComponent : public Gmlinkedcomponents::TGMLinkedComponent
{
	typedef Gmlinkedcomponents::TGMLinkedComponent inherited;
	
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual THackGMLinkedComponent(System::Classes::TComponent* AOwner) : Gmlinkedcomponents::TGMLinkedComponent(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~THackGMLinkedComponent() { }
	
};


class PASCALIMPLEMENTATION THackMap : public Gmmap::TCustomGMMap
{
	typedef Gmmap::TCustomGMMap inherited;
	
public:
	/* TCustomGMMap.Create */ inline __fastcall virtual THackMap(System::Classes::TComponent* AOwner) : Gmmap::TCustomGMMap(AOwner) { }
	/* TCustomGMMap.Destroy */ inline __fastcall virtual ~THackMap() { }
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TGeometry : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	__classmethod bool __fastcall CheckPointsStr(System::UnicodeString PointsStr);
	
public:
	__classmethod System::UnicodeString __fastcall EncodePath(Gmmap::TCustomGMMap* Map, System::UnicodeString PointsStr);
	__classmethod System::UnicodeString __fastcall DecodePath(Gmmap::TCustomGMMap* Map, System::UnicodeString EncodedPath);
	__classmethod bool __fastcall IsLocationOnEdge(Gmpolyline::TGMBasePolyline* GMPoly, int Idx, Gmclasses::TLatLng* LatLng, int Tolerance);
	__classmethod double __fastcall ComputeArea(Gmmap::TCustomGMMap* Map, System::UnicodeString PointsStr, double Radius = -1.000000E+00);
	__classmethod double __fastcall ComputeDistanceBetween(Gmmap::TCustomGMMap* Map, Gmclasses::TLatLng* Origin, Gmclasses::TLatLng* Dest, double Radius = -1.000000E+00);
	__classmethod double __fastcall ComputeHeading(Gmmap::TCustomGMMap* Map, Gmclasses::TLatLng* Origin, Gmclasses::TLatLng* Dest);
	__classmethod double __fastcall ComputeLength(Gmmap::TCustomGMMap* Map, System::UnicodeString PointsStr, double Radius = -1.000000E+00);
	__classmethod void __fastcall ComputeOffset(Gmmap::TCustomGMMap* Map, Gmclasses::TLatLng* Origin, double Distance, double Heading, Gmclasses::TLatLng* Result, double Radius = -1.000000E+00);
	__classmethod void __fastcall ComputeOffsetOrigin(Gmmap::TCustomGMMap* Map, Gmclasses::TLatLng* Dest, double Distance, double Heading, Gmclasses::TLatLng* Result, double Radius = -1.000000E+00);
	__classmethod double __fastcall ComputeSignedArea(Gmmap::TCustomGMMap* Map, System::UnicodeString PointsStr, double Radius = -1.000000E+00);
	__classmethod void __fastcall Interpolate(Gmmap::TCustomGMMap* Map, Gmclasses::TLatLng* Origin, Gmclasses::TLatLng* Dest, double Fraction, Gmclasses::TLatLng* Result);
public:
	/* TObject.Create */ inline __fastcall TGeometry() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TGeometry() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TPath : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod System::UnicodeString __fastcall GetTempPath();
	__classmethod System::UnicodeString __fastcall GetTempFileName();
public:
	/* TObject.Create */ inline __fastcall TPath() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TPath() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomTransform : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod System::UnicodeString __fastcall GMBoolToStr(bool B, bool UseBoolStrs = false);
	__classmethod System::UnicodeString __fastcall RegionToStr(Gmconstants::TRegion Region);
	__classmethod System::UnicodeString __fastcall RegionToStr2(Gmconstants::TRegion Region);
	__classmethod System::UnicodeString __fastcall LangCodeToStr(Gmconstants::TLangCode LangCode);
	__classmethod System::UnicodeString __fastcall TravelModeToStr(Gmconstants::TTravelMode TravelMode);
	__classmethod System::UnicodeString __fastcall UnitSystemToStr(Gmconstants::TUnitSystem UnitSystem);
	__classmethod System::UnicodeString __fastcall GeocoderLocationTypeToStr(Gmconstants::TGeocoderLocationType GeocoderLocationType);
	__classmethod System::UnicodeString __fastcall GeocoderStatusToStr(Gmconstants::TGeocoderStatus GeocoderStatus);
	__classmethod System::UnicodeString __fastcall LangCodeToStr2(Gmconstants::TLangCode LangCode);
	__classmethod System::UnicodeString __fastcall LabelColorToStr(Gmconstants::TLabelColor LabelColor);
	__classmethod System::UnicodeString __fastcall TemperatureUnitToStr(Gmconstants::TTemperatureUnit TemperatureUnit);
	__classmethod System::UnicodeString __fastcall WindSpeedUnitToStr(Gmconstants::TWindSpeedUnit WindSpeedUnit);
	__classmethod System::UnicodeString __fastcall DirectionsStatusToStr(Gmconstants::TDirectionsStatus DirectionsStatus);
	__classmethod System::UnicodeString __fastcall VehicleTypeToStr(Gmconstants::TVehicleType VehicleType);
	__classmethod System::UnicodeString __fastcall SymbolPathToStr(Gmconstants::TSymbolPath SymbolPath);
	__classmethod System::UnicodeString __fastcall MeasureToStr(Gmconstants::TMeasure Measure);
	__classmethod System::UnicodeString __fastcall MarkerTypeToStr(Gmconstants::TMarkerType MarkerType);
	__classmethod System::UnicodeString __fastcall StyledIconToStr(Gmconstants::TStyledIcon StyledIcon);
	__classmethod System::UnicodeString __fastcall ElevationTypeToStr(Gmconstants::TElevationType ElevationType);
	__classmethod System::UnicodeString __fastcall ElevationStatusToStr(Gmconstants::TElevationStatus ElevationStatus);
	__classmethod System::UnicodeString __fastcall MapTypeIdToStr(Gmconstants::TMapTypeId MapTypeId);
	__classmethod System::UnicodeString __fastcall MapTypeIdsToStr(Gmconstants::TMapTypeIds MapTypeIds, System::WideChar Delimiter = (System::WideChar)(0x3b));
	__classmethod System::UnicodeString __fastcall PositionToStr(Gmconstants::TControlPosition Position);
	__classmethod System::UnicodeString __fastcall MapTypeControlStyleToStr(Gmconstants::TMapTypeControlStyle MapTypeControlStyle);
	__classmethod System::UnicodeString __fastcall ScaleControlStyleToStr(Gmconstants::TScaleControlStyle ScaleControlStyle);
	__classmethod System::UnicodeString __fastcall ZoomControlStyleToStr(Gmconstants::TZoomControlStyle ZoomControlStyle);
	__classmethod System::UnicodeString __fastcall GradientToStr(Gmconstants::TGradient Gradient);
	__classmethod Gmconstants::TUnitSystem __fastcall StrToUnitSystem(System::UnicodeString UnitSystem);
	__classmethod Gmconstants::TTravelMode __fastcall StrToTravelMode(System::UnicodeString TravelMode);
	__classmethod Gmconstants::TRegion __fastcall StrToRegion2(System::UnicodeString Region);
	__classmethod Gmconstants::TGeocoderLocationType __fastcall StrToGeocoderLocationType(System::UnicodeString GeocoderLocationType);
	__classmethod Gmconstants::TGeocoderStatus __fastcall StrToGeocoderStatus(System::UnicodeString GeocoderStatus);
	__classmethod Gmconstants::TLangCode __fastcall StrToLangCode2(System::UnicodeString LangCode);
	__classmethod Gmconstants::TLabelColor __fastcall StrToLabelColor(System::UnicodeString LabelColor);
	__classmethod Gmconstants::TTemperatureUnit __fastcall StrToTemperatureUnit(System::UnicodeString TemperatureUnit);
	__classmethod Gmconstants::TWindSpeedUnit __fastcall StrToWindSpeedUnit(System::UnicodeString WindSpeedUnit);
	__classmethod Gmconstants::TDirectionsStatus __fastcall StrToDirectionsStatus(System::UnicodeString DirectionsStatus);
	__classmethod Gmconstants::TVehicleType __fastcall StrToVehicleType(System::UnicodeString VehicleType);
	__classmethod Gmconstants::TSymbolPath __fastcall StrToSymbolPath(System::UnicodeString SymbolPath);
	__classmethod Gmconstants::TMeasure __fastcall StrToMeasure(System::UnicodeString Measure);
	__classmethod Gmconstants::TMarkerType __fastcall StrToMarkerType(System::UnicodeString MarkerType);
	__classmethod Gmconstants::TStyledIcon __fastcall StrToStyledIcon(System::UnicodeString StyledIcon);
	__classmethod Gmconstants::TElevationType __fastcall StrToElevationType(System::UnicodeString ElevationType);
	__classmethod Gmconstants::TElevationStatus __fastcall StrToElevationStatus(System::UnicodeString ElevationStatus);
	__classmethod Gmconstants::TMapTypeId __fastcall StrToMapTypeId(System::UnicodeString MapTypeId);
	__classmethod Gmconstants::TControlPosition __fastcall StrToPosition(System::UnicodeString Position);
	__classmethod Gmconstants::TMapTypeControlStyle __fastcall StrToMapTypeControlStyle(System::UnicodeString MapTypeControlStyle);
	__classmethod Gmconstants::TScaleControlStyle __fastcall StrToScaleControlStyle(System::UnicodeString ScaleControlStyle);
	__classmethod Gmconstants::TZoomControlStyle __fastcall StrToZoomControlStyle(System::UnicodeString ZoomControlStyle);
	__classmethod Gmconstants::TGradient __fastcall StrToGradient(System::UnicodeString Gradient);
public:
	/* TObject.Create */ inline __fastcall TCustomTransform() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TCustomTransform() { }
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmfunctions */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMFUNCTIONS)
using namespace Gmfunctions;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmfunctionsHPP
