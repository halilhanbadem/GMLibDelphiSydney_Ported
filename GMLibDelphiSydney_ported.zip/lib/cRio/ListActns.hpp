//-- WARNING -----------------------------------------------------------------
// Deprecated legacy header
//----------------------------------------------------------------------------
#ifdef WARN_LEGACY_HEADER_USAGE
  #pragma message("Include <Vcl.ListActns.hpp> instead")
#endif
#ifdef ERROR_LEGACY_HEADER_USAGE
  #error Include 'Vcl.ListActns.hpp' instead
#endif

#include <Vcl.ListActns.hpp>
