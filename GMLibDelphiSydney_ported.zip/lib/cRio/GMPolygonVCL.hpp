﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMPolygonVCL.pas' rev: 34.00 (Windows)

#ifndef GmpolygonvclHPP
#define GmpolygonvclHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <Vcl.Graphics.hpp>
#include <GMPolyline.hpp>
#include <GMPolylineVCL.hpp>
#include <GMLinkedComponents.hpp>
#include <GMClasses.hpp>
#include <System.UITypes.hpp>
#include <GMMap.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmpolygonvcl
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TPolygon;
class DELPHICLASS TPolygons;
class DELPHICLASS TGMPolygon;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TPolygon : public Gmpolylinevcl::TBasePolylineVCL
{
	typedef Gmpolylinevcl::TBasePolylineVCL inherited;
	
private:
	System::Uitypes::TColor FFillColor;
	double FFillOpacity;
	void __fastcall SetFillColor(const System::Uitypes::TColor Value);
	void __fastcall SetFillOpacity(const double Value);
	
protected:
	virtual bool __fastcall ChangeProperties();
	
public:
	__fastcall virtual TPolygon(System::Classes::TCollection* Collection);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	bool __fastcall ContainsLocation(Gmclasses::TLatLng* LatLng)/* overload */;
	bool __fastcall ContainsLocation(double Lat, double Lng)/* overload */;
	
__published:
	__property System::Uitypes::TColor FillColor = {read=FFillColor, write=SetFillColor, default=255};
	__property double FillOpacity = {read=FFillOpacity, write=SetFillOpacity};
public:
	/* TBasePolyline.Destroy */ inline __fastcall virtual ~TPolygon() { }
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TPolygons : public Gmpolyline::TBasePolylines
{
	typedef Gmpolyline::TBasePolylines inherited;
	
public:
	TPolygon* operator[](int I) { return this->Items[I]; }
	
private:
	HIDESBASE void __fastcall SetItems(int I, TPolygon* const Value);
	HIDESBASE TPolygon* __fastcall GetItems(int I);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	HIDESBASE TPolygon* __fastcall Add();
	HIDESBASE TPolygon* __fastcall Insert(int Index);
	__property TPolygon* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TLinkedComponents.Create */ inline __fastcall virtual TPolygons(Gmlinkedcomponents::TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass) : Gmpolyline::TBasePolylines(GMLinkedComponent, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TPolygons() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TGMPolygon : public Gmpolyline::TGMBasePolyline
{
	typedef Gmpolyline::TGMBasePolyline inherited;
	
public:
	TPolygon* operator[](int I) { return this->Items[I]; }
	
private:
	Gmlinkedcomponents::TLinkedComponentChange FOnFillOpacityChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnFillColorChange;
	
protected:
	virtual System::UnicodeString __fastcall GetAPIUrl();
	HIDESBASE TPolygon* __fastcall GetItems(int I);
	virtual Gmlinkedcomponents::TLinkedComponentClass __fastcall GetCollectionItemClass();
	virtual Gmlinkedcomponents::TLinkedComponentsClass __fastcall GetCollectionClass();
	
public:
	HIDESBASE TPolygon* __fastcall Add();
	__property TPolygon* Items[int I] = {read=GetItems/*, default*/};
	
__published:
	__property Gmlinkedcomponents::TLinkedComponentChange OnFillColorChange = {read=FOnFillColorChange, write=FOnFillColorChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnFillOpacityChange = {read=FOnFillOpacityChange, write=FOnFillOpacityChange};
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual TGMPolygon(System::Classes::TComponent* AOwner) : Gmpolyline::TGMBasePolyline(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~TGMPolygon() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmpolygonvcl */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMPOLYGONVCL)
using namespace Gmpolygonvcl;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmpolygonvclHPP
