﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UAboutFrm.pas' rev: 34.00 (Windows)

#ifndef UaboutfrmHPP
#define UaboutfrmHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.Variants.hpp>
#include <System.Classes.hpp>
#include <Vcl.Graphics.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.Dialogs.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Imaging.jpeg.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uaboutfrm
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TAboutFrm;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TAboutFrm : public Vcl::Forms::TForm
{
	typedef Vcl::Forms::TForm inherited;
	
__published:
	Vcl::Extctrls::TImage* Image1;
	Vcl::Stdctrls::TLabel* Label1;
	Vcl::Stdctrls::TLabel* Label2;
	Vcl::Stdctrls::TLabel* Label3;
	Vcl::Stdctrls::TLabel* Label4;
	Vcl::Stdctrls::TLabel* lVersion;
	Vcl::Stdctrls::TLabel* Label5;
	Vcl::Stdctrls::TLabel* lMail;
	Vcl::Stdctrls::TLabel* lWeb;
	Vcl::Extctrls::TImage* Image2;
	Vcl::Stdctrls::TLabel* Label6;
	Vcl::Stdctrls::TLabel* lWeb2;
	Vcl::Stdctrls::TLabel* Label7;
	Vcl::Stdctrls::TLabel* lBugs;
	Vcl::Stdctrls::TLabel* Label8;
	Vcl::Stdctrls::TLabel* Label9;
	Vcl::Stdctrls::TLabel* Label10;
	Vcl::Stdctrls::TLabel* Label11;
	Vcl::Stdctrls::TLabel* Label12;
	void __fastcall lMailClick(System::TObject* Sender);
	void __fastcall lWebClick(System::TObject* Sender);
	void __fastcall FormKeyPress(System::TObject* Sender, System::WideChar &Key);
	void __fastcall Image2Click(System::TObject* Sender);
	
public:
	__fastcall virtual TAboutFrm(System::Classes::TComponent* aOwner);
public:
	/* TCustomForm.CreateNew */ inline __fastcall virtual TAboutFrm(System::Classes::TComponent* AOwner, int Dummy) : Vcl::Forms::TForm(AOwner, Dummy) { }
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TAboutFrm() { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TAboutFrm(HWND ParentWindow) : Vcl::Forms::TForm(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE TAboutFrm* AboutFrm;
}	/* namespace Uaboutfrm */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UABOUTFRM)
using namespace Uaboutfrm;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UaboutfrmHPP
