﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMMapVCL.pas' rev: 34.00 (Windows)

#ifndef GmmapvclHPP
#define GmmapvclHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <SHDocVw.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <Vcl.Dialogs.hpp>
#include <Vcl.Graphics.hpp>
#include <GMMap.hpp>
#include <GMFunctionsVCL.hpp>
#include <System.UITypes.hpp>
#include <GMClasses.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmmapvcl
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TVisualProp;
class DELPHICLASS TCustomGMMapVCL;
class DELPHICLASS TGMMap;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TVisualProp : public Gmmap::TCustomVisualProp
{
	typedef Gmmap::TCustomVisualProp inherited;
	
private:
	System::Uitypes::TColor FBGColor;
	
protected:
	virtual System::UnicodeString __fastcall GetBckgroundColor();
	
public:
	__fastcall virtual TVisualProp();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::Uitypes::TColor BGColor = {read=FBGColor, write=FBGColor, default=12632256};
public:
	/* TCustomVisualProp.Destroy */ inline __fastcall virtual ~TVisualProp() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TCustomGMMapVCL : public Gmmap::TCustomGMMap
{
	typedef Gmmap::TCustomGMMap inherited;
	
private:
	TVisualProp* FVisualProp;
	Vcl::Extctrls::TTimer* FTimer;
	
protected:
	virtual System::UnicodeString __fastcall VisualPropToStr();
	virtual void __fastcall SetEnableTimer(bool State);
	virtual void __fastcall SetIntervalTimer(int Interval);
	
public:
	__fastcall virtual TCustomGMMapVCL(System::Classes::TComponent* AOwner);
	__fastcall virtual ~TCustomGMMapVCL();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	virtual void __fastcall SaveToJPGFile(System::Sysutils::TFileName FileName = System::Sysutils::TFileName());
	virtual void __fastcall SaveHTML(System::Sysutils::TFileName FileName = System::Sysutils::TFileName());
	
__published:
	__property TVisualProp* VisualProp = {read=FVisualProp, write=FVisualProp};
};


class PASCALIMPLEMENTATION TGMMap : public TCustomGMMapVCL
{
	typedef TCustomGMMapVCL inherited;
	
private:
	_di_IDispatch CurDispatch;
	Shdocvw::TWebBrowserBeforeNavigate2 OldBeforeNavigate2;
	Shdocvw::TWebBrowserDocumentComplete OldDocumentComplete;
	Shdocvw::TWebBrowserNavigateComplete2 OldNavigateComplete2;
	void __fastcall BeforeNavigate2(System::TObject* ASender, const _di_IDispatch pDisp, const System::OleVariant &URL, const System::OleVariant &Flags, const System::OleVariant &TargetFrameName, const System::OleVariant &PostData, const System::OleVariant &Headers, System::WordBool &Cancel);
	void __fastcall DocumentComplete(System::TObject* ASender, const _di_IDispatch pDisp, const System::OleVariant &URL);
	void __fastcall NavigateComplete2(System::TObject* ASender, const _di_IDispatch pDisp, const System::OleVariant &URL);
	Shdocvw::TWebBrowser* __fastcall GetWebBrowser();
	void __fastcall SetWebBrowser(Shdocvw::TWebBrowser* const Value);
	
protected:
	virtual void __fastcall BrowserEventsControl();
	virtual bool __fastcall ExecuteScript(System::UnicodeString NameFunct, System::UnicodeString Params);
	virtual void __fastcall LoadBaseWeb();
	virtual void __fastcall LoadBlankPage();
	
public:
	__fastcall virtual TGMMap(System::Classes::TComponent* AOwner);
	__fastcall virtual ~TGMMap();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	System::UnicodeString __fastcall GetIEVersion();
	
__published:
	__property Shdocvw::TWebBrowser* WebBrowser = {read=GetWebBrowser, write=SetWebBrowser};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmmapvcl */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMMAPVCL)
using namespace Gmmapvcl;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmmapvclHPP
