﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMMarker.pas' rev: 34.00 (Windows)

#ifndef GmmarkerHPP
#define GmmarkerHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>
#include <Data.DB.hpp>
#include <GMLinkedComponents.hpp>
#include <GMConstants.hpp>
#include <GMClasses.hpp>
#include <GMMap.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmmarker
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TAnimation;
class DELPHICLASS TCustomColoredMarker;
class DELPHICLASS TCustomStyledMarker;
class DELPHICLASS TCustomGMBorder;
class DELPHICLASS TCustomGMFont;
class DELPHICLASS TCustomStyleLabel;
class DELPHICLASS TCustomMarker;
class DELPHICLASS TCustomMarkers;
class DELPHICLASS TCustomGMMarker;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TAnimation : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TCustomMarker* FMarker;
	bool FOnDrop;
	bool FBounce;
	unsigned FIdxList;
	void __fastcall SetOnDrop(const bool Value);
	
protected:
	virtual void __fastcall SetBounce(const bool Value);
	__property unsigned IdxList = {read=FIdxList, write=FIdxList, nodefault};
	
public:
	__fastcall virtual TAnimation(TCustomMarker* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property bool OnDrop = {read=FOnDrop, write=SetOnDrop, default=0};
	__property bool Bounce = {read=FBounce, write=SetBounce, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TAnimation() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomColoredMarker : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	int FWidth;
	int FHeight;
	void __fastcall SetHeight(const int Value);
	void __fastcall SetWidth(const int Value);
	
protected:
	TCustomMarker* FMarker;
	virtual System::UnicodeString __fastcall GetCornerColor() = 0 ;
	virtual System::UnicodeString __fastcall GetPrimaryColor() = 0 ;
	virtual System::UnicodeString __fastcall GetStrokeColor() = 0 ;
	
public:
	__fastcall virtual TCustomColoredMarker(TCustomMarker* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property int Width = {read=FWidth, write=SetWidth, default=32};
	__property int Height = {read=FHeight, write=SetHeight, default=32};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TCustomColoredMarker() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomStyledMarker : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	bool FShowStar;
	Gmconstants::TStyledIcon FStyledIcon;
	void __fastcall SetShowStar(const bool Value);
	void __fastcall SetStyledIcon(const Gmconstants::TStyledIcon Value);
	
protected:
	TCustomMarker* FMarker;
	virtual System::UnicodeString __fastcall GetBackgroundColor() = 0 ;
	virtual System::UnicodeString __fastcall GetTextColor() = 0 ;
	virtual System::UnicodeString __fastcall GetStarColor() = 0 ;
	
public:
	__fastcall virtual TCustomStyledMarker(TCustomMarker* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property Gmconstants::TStyledIcon StyledIcon = {read=FStyledIcon, write=SetStyledIcon, default=0};
	__property bool ShowStar = {read=FShowStar, write=SetShowStar, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TCustomStyledMarker() { }
	
};

#pragma pack(pop)

enum DECLSPEC_DENUM TGMFontStyle : unsigned char { fstBold, fstItalic, fstOverline, fstUnderline, fstStrikeOut };

typedef System::Set<TGMFontStyle, TGMFontStyle::fstBold, TGMFontStyle::fstStrikeOut> TGMFontStyles;

#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomGMBorder : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	int FSize;
	Gmconstants::TBorderStyle FStyle;
	void __fastcall SetSize(const int Value);
	void __fastcall SetStyle(const Gmconstants::TBorderStyle Value);
	
protected:
	TCustomMarker* FMarker;
	
public:
	__fastcall virtual TCustomGMBorder(TCustomMarker* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property int Size = {read=FSize, write=SetSize, nodefault};
	__property Gmconstants::TBorderStyle Style = {read=FStyle, write=SetStyle, nodefault};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TCustomGMBorder() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomGMFont : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	int FSize;
	TGMFontStyles FStyle;
	void __fastcall SetSize(const int Value);
	void __fastcall SetStyle(const TGMFontStyles Value);
	
protected:
	TCustomMarker* FMarker;
	
public:
	__fastcall virtual TCustomGMFont(TCustomMarker* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property TGMFontStyles Style = {read=FStyle, write=SetStyle, nodefault};
	__property int Size = {read=FSize, write=SetSize, nodefault};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TCustomGMFont() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TCustomStyleLabel : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TCustomGMFont* FFont;
	TCustomGMBorder* FBorder;
	double FOpacity;
	bool FNoBackground;
	void __fastcall SetOpacity(const double Value);
	void __fastcall SetNoBackground(const bool Value);
	
protected:
	TCustomMarker* FMarker;
	
public:
	__fastcall virtual TCustomStyleLabel(TCustomMarker* aOwner);
	__fastcall virtual ~TCustomStyleLabel();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property TCustomGMFont* Font = {read=FFont, write=FFont};
	__property TCustomGMBorder* Border = {read=FBorder, write=FBorder};
	__property double Opacity = {read=FOpacity, write=SetOpacity};
	__property bool NoBackground = {read=FNoBackground, write=SetNoBackground, nodefault};
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomMarker : public Gmlinkedcomponents::TLinkedComponent
{
	typedef Gmlinkedcomponents::TLinkedComponent inherited;
	
private:
	TAnimation* FAnimation;
	bool FClickable;
	bool FDraggable;
	bool FFlat;
	bool FOptimized;
	Gmclasses::TLatLng* FPosition;
	bool FRaiseOnDrag;
	System::UnicodeString FTitle;
	bool FVisible;
	System::UnicodeString FIcon;
	Gmconstants::TMarkerType FMarkerType;
	bool FCrossOnDrag;
	bool FIsUpdating;
	int FDirection;
	void __fastcall SetClickable(const bool Value);
	void __fastcall SetDraggable(const bool Value);
	void __fastcall SetFlat(const bool Value);
	void __fastcall SetRaiseOnDrag(const bool Value);
	void __fastcall SetVisible(const bool Value);
	int __fastcall GetZIndex();
	void __fastcall SetOptimized(const bool Value);
	void __fastcall SetTitle(const System::UnicodeString Value);
	void __fastcall SetIcon(const System::UnicodeString Value);
	void __fastcall OnLatLngChange(System::TObject* Sender);
	void __fastcall SetMarkerType(const Gmconstants::TMarkerType Value);
	void __fastcall SetCrossOnDrag(const bool Value);
	void __fastcall SetDirection(const int Value);
	
protected:
	virtual void __fastcall SetIdxList(const unsigned Value);
	virtual System::UnicodeString __fastcall GetDisplayName();
	virtual bool __fastcall ChangeProperties();
	virtual void __fastcall CreatePropertiesWithColor() = 0 ;
	virtual System::UnicodeString __fastcall ColoredMarkerToStr() = 0 ;
	virtual System::UnicodeString __fastcall StyledMarkerToStr() = 0 ;
	
public:
	__fastcall virtual TCustomMarker(System::Classes::TCollection* Collection);
	__fastcall virtual ~TCustomMarker();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	void __fastcall CenterMapToMarker _DEPRECATED_ATTRIBUTE0 ();
	virtual void __fastcall CenterMapTo();
	
__published:
	__property int Direction = {read=FDirection, write=SetDirection, default=0};
	__property Gmconstants::TMarkerType MarkerType = {read=FMarkerType, write=SetMarkerType, default=0};
	__property TAnimation* Animation = {read=FAnimation, write=FAnimation};
	__property bool Clickable = {read=FClickable, write=SetClickable, default=1};
	__property bool Draggable = {read=FDraggable, write=SetDraggable, default=0};
	__property bool Flat = {read=FFlat, write=SetFlat, default=0};
	__property Gmclasses::TLatLng* Position = {read=FPosition, write=FPosition};
	__property System::UnicodeString Title = {read=FTitle, write=SetTitle};
	__property bool Visible = {read=FVisible, write=SetVisible, default=1};
	__property bool Optimized = {read=FOptimized, write=SetOptimized, default=1};
	__property bool RaiseOnDrag = {read=FRaiseOnDrag, write=SetRaiseOnDrag, default=1};
	__property System::UnicodeString Icon = {read=FIcon, write=SetIcon};
	__property bool CrossOnDrag = {read=FCrossOnDrag, write=SetCrossOnDrag, default=1};
	__property int ZIndex = {read=GetZIndex, nodefault};
	__property InfoWindow;
	__property ShowInfoWinMouseOver = {default=0};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomMarkers : public Gmlinkedcomponents::TLinkedComponents
{
	typedef Gmlinkedcomponents::TLinkedComponents inherited;
	
public:
	TCustomMarker* operator[](int I) { return this->Items[I]; }
	
private:
	HIDESBASE void __fastcall SetItems(int I, TCustomMarker* const Value);
	HIDESBASE TCustomMarker* __fastcall GetItems(int I);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	HIDESBASE TCustomMarker* __fastcall Add();
	HIDESBASE TCustomMarker* __fastcall Insert(int Index);
	__property TCustomMarker* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TLinkedComponents.Create */ inline __fastcall virtual TCustomMarkers(Gmlinkedcomponents::TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass) : Gmlinkedcomponents::TLinkedComponents(GMLinkedComponent, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TCustomMarkers() { }
	
};

#pragma pack(pop)

typedef void __fastcall (__closure *TOnLoadFile)(TCustomGMMarker* Sender, TCustomMarker* Marker, int Current, int Count, bool &Stop);

typedef void __fastcall (__closure *TAfterLoadFile)(TCustomGMMarker* Sender, int Loaded, int Count);

class PASCALIMPLEMENTATION TCustomGMMarker : public Gmlinkedcomponents::TGMLinkedComponent
{
	typedef Gmlinkedcomponents::TGMLinkedComponent inherited;
	
public:
	TCustomMarker* operator[](int I) { return this->Items[I]; }
	
private:
	Gmlinkedcomponents::TLatLngIdxEvent FOnClick;
	Gmlinkedcomponents::TLatLngIdxEvent FOnDblClick;
	Gmlinkedcomponents::TLatLngIdxEvent FOnDrag;
	Gmlinkedcomponents::TLatLngIdxEvent FOnDragEnd;
	Gmlinkedcomponents::TLatLngIdxEvent FOnRightClick;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseDown;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseUp;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseOut;
	Gmlinkedcomponents::TLatLngIdxEvent FOnDragStart;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseOver;
	Gmlinkedcomponents::TLinkedComponentChange FOnClickableChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnDraggableChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnFlatChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnPositionChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnTitleChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnVisibleChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnIconChange;
	TOnLoadFile FOnLoadFile;
	TAfterLoadFile FAfterLoadFile;
	Gmlinkedcomponents::TLinkedComponentChange FOnColoredMarkerChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnStyledMarkerChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnCrossOnDragChange;
	
protected:
	virtual System::UnicodeString __fastcall GetAPIUrl();
	HIDESBASE TCustomMarker* __fastcall GetItems(int I);
	virtual void __fastcall EventFired(Gmconstants::TEventType EventType, System::TVarRec *Params, const int Params_High);
	virtual Gmlinkedcomponents::TLinkedComponentClass __fastcall GetCollectionItemClass();
	virtual Gmlinkedcomponents::TLinkedComponentsClass __fastcall GetCollectionClass();
	
public:
	void __fastcall LoadFromCSV(int LatColumn, int LngColumn, System::UnicodeString FileName, int TitleColumn = 0xffffffff, System::WideChar Delimiter = (System::WideChar)(0x2c), bool DeleteBeforeLoad = true, bool WithRownTitle = true, int IconColumn = 0xffffffff);
	void __fastcall LoadFromDataSet(Data::Db::TDataSet* DataSet, System::UnicodeString LatField, System::UnicodeString LngField, System::UnicodeString TitleField = System::UnicodeString(), System::UnicodeString IconField = System::UnicodeString(), bool DeleteBeforeLoad = true, System::UnicodeString HTMLContentField = System::UnicodeString());
	HIDESBASE TCustomMarker* __fastcall Add(double Lat = 0.000000E+00, double Lng = 0.000000E+00, System::UnicodeString Title = System::UnicodeString());
	void __fastcall ZoomMapToAllMarkers _DEPRECATED_ATTRIBUTE0 ();
	void __fastcall ZoomToPoints();
	__property TCustomMarker* Items[int I] = {read=GetItems/*, default*/};
	
__published:
	__property VisualObjects;
	__property TOnLoadFile OnLoadFile = {read=FOnLoadFile, write=FOnLoadFile};
	__property TAfterLoadFile AfterLoadFile = {read=FAfterLoadFile, write=FAfterLoadFile};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnClick = {read=FOnClick, write=FOnClick};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnDblClick = {read=FOnDblClick, write=FOnDblClick};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnDrag = {read=FOnDrag, write=FOnDrag};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnDragEnd = {read=FOnDragEnd, write=FOnDragEnd};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnDragStart = {read=FOnDragStart, write=FOnDragStart};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseDown = {read=FOnMouseDown, write=FOnMouseDown};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseOut = {read=FOnMouseOut, write=FOnMouseOut};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseOver = {read=FOnMouseOver, write=FOnMouseOver};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseUp = {read=FOnMouseUp, write=FOnMouseUp};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnRightClick = {read=FOnRightClick, write=FOnRightClick};
	__property Gmlinkedcomponents::TLinkedComponentChange OnClickableChange = {read=FOnClickableChange, write=FOnClickableChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnDraggableChange = {read=FOnDraggableChange, write=FOnDraggableChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnFlatChange = {read=FOnFlatChange, write=FOnFlatChange};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnPositionChange = {read=FOnPositionChange, write=FOnPositionChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnTitleChange = {read=FOnTitleChange, write=FOnTitleChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnVisibleChange = {read=FOnVisibleChange, write=FOnVisibleChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnIconChange = {read=FOnIconChange, write=FOnIconChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnColoredMarkerChange = {read=FOnColoredMarkerChange, write=FOnColoredMarkerChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnStyledMarkerChange = {read=FOnStyledMarkerChange, write=FOnStyledMarkerChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnCrossOnDragChange = {read=FOnCrossOnDragChange, write=FOnCrossOnDragChange};
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual TCustomGMMarker(System::Classes::TComponent* AOwner) : Gmlinkedcomponents::TGMLinkedComponent(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~TCustomGMMarker() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmmarker */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMMARKER)
using namespace Gmmarker;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmmarkerHPP
