﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMMarkerVCL.pas' rev: 34.00 (Windows)

#ifndef GmmarkervclHPP
#define GmmarkervclHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <Vcl.Graphics.hpp>
#include <GMMarker.hpp>
#include <GMLinkedComponents.hpp>
#include <System.UITypes.hpp>
#include <GMMap.hpp>
#include <GMClasses.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmmarkervcl
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TColoredMarker;
class DELPHICLASS TStyledMarker;
class DELPHICLASS TGMBorder;
class DELPHICLASS TGMFont;
class DELPHICLASS TStyleLabel;
class DELPHICLASS TMarker;
class DELPHICLASS TMarkers;
class DELPHICLASS TGMMarker;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TColoredMarker : public Gmmarker::TCustomColoredMarker
{
	typedef Gmmarker::TCustomColoredMarker inherited;
	
private:
	System::Uitypes::TColor FStrokeColor;
	System::Uitypes::TColor FCornerColor;
	System::Uitypes::TColor FPrimaryColor;
	void __fastcall SetCornerColor(const System::Uitypes::TColor Value);
	void __fastcall SetPrimaryColor(const System::Uitypes::TColor Value);
	void __fastcall SetStrokeColor(const System::Uitypes::TColor Value);
	
protected:
	virtual System::UnicodeString __fastcall GetCornerColor();
	virtual System::UnicodeString __fastcall GetPrimaryColor();
	virtual System::UnicodeString __fastcall GetStrokeColor();
	
public:
	__fastcall virtual TColoredMarker(TMarker* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::Uitypes::TColor PrimaryColor = {read=FPrimaryColor, write=SetPrimaryColor, default=255};
	__property System::Uitypes::TColor StrokeColor = {read=FStrokeColor, write=SetStrokeColor, default=0};
	__property System::Uitypes::TColor CornerColor = {read=FCornerColor, write=SetCornerColor, default=16777215};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TColoredMarker() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TStyledMarker : public Gmmarker::TCustomStyledMarker
{
	typedef Gmmarker::TCustomStyledMarker inherited;
	
private:
	System::Uitypes::TColor FStarColor;
	System::Uitypes::TColor FTextColor;
	System::Uitypes::TColor FBackgroundColor;
	void __fastcall SetBackgroundColor(const System::Uitypes::TColor Value);
	void __fastcall SetStarColor(const System::Uitypes::TColor Value);
	void __fastcall SetTextColor(const System::Uitypes::TColor Value);
	
protected:
	virtual System::UnicodeString __fastcall GetBackgroundColor();
	virtual System::UnicodeString __fastcall GetTextColor();
	virtual System::UnicodeString __fastcall GetStarColor();
	
public:
	__fastcall virtual TStyledMarker(TMarker* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::Uitypes::TColor BackgroundColor = {read=FBackgroundColor, write=SetBackgroundColor, default=255};
	__property System::Uitypes::TColor TextColor = {read=FTextColor, write=SetTextColor, default=0};
	__property System::Uitypes::TColor StarColor = {read=FStarColor, write=SetStarColor, default=65280};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TStyledMarker() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TGMBorder : public Gmmarker::TCustomGMBorder
{
	typedef Gmmarker::TCustomGMBorder inherited;
	
private:
	System::Uitypes::TColor FColor;
	void __fastcall SetColor(const System::Uitypes::TColor Value);
	
public:
	__fastcall virtual TGMBorder(TMarker* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::Uitypes::TColor Color = {read=FColor, write=SetColor, nodefault};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TGMBorder() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TGMFont : public Gmmarker::TCustomGMFont
{
	typedef Gmmarker::TCustomGMFont inherited;
	
private:
	System::Uitypes::TColor FColor;
	void __fastcall SetColor(const System::Uitypes::TColor Value);
	
public:
	__fastcall virtual TGMFont(TMarker* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::Uitypes::TColor Color = {read=FColor, write=SetColor, nodefault};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TGMFont() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TStyleLabel : public Gmmarker::TCustomStyleLabel
{
	typedef Gmmarker::TCustomStyleLabel inherited;
	
private:
	System::Uitypes::TColor FBackground;
	void __fastcall SetBackground(const System::Uitypes::TColor Value);
	
public:
	__fastcall virtual TStyleLabel(TMarker* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::Uitypes::TColor Background = {read=FBackground, write=SetBackground, nodefault};
public:
	/* TCustomStyleLabel.Destroy */ inline __fastcall virtual ~TStyleLabel() { }
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TMarker : public Gmmarker::TCustomMarker
{
	typedef Gmmarker::TCustomMarker inherited;
	
private:
	TStyledMarker* FStyledMarker;
	TColoredMarker* FColoredMarker;
	
protected:
	virtual void __fastcall CreatePropertiesWithColor();
	virtual System::UnicodeString __fastcall ColoredMarkerToStr();
	virtual System::UnicodeString __fastcall StyledMarkerToStr();
	
public:
	__fastcall virtual ~TMarker();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property TColoredMarker* ColoredMarker = {read=FColoredMarker, write=FColoredMarker};
	__property TStyledMarker* StyledMarker = {read=FStyledMarker, write=FStyledMarker};
public:
	/* TCustomMarker.Create */ inline __fastcall virtual TMarker(System::Classes::TCollection* Collection) : Gmmarker::TCustomMarker(Collection) { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TMarkers : public Gmmarker::TCustomMarkers
{
	typedef Gmmarker::TCustomMarkers inherited;
	
public:
	TMarker* operator[](int I) { return this->Items[I]; }
	
private:
	HIDESBASE void __fastcall SetItems(int I, TMarker* const Value);
	HIDESBASE TMarker* __fastcall GetItems(int I);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	HIDESBASE TMarker* __fastcall Add();
	HIDESBASE TMarker* __fastcall Insert(int Index);
	__property TMarker* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TLinkedComponents.Create */ inline __fastcall virtual TMarkers(Gmlinkedcomponents::TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass) : Gmmarker::TCustomMarkers(GMLinkedComponent, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TMarkers() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TGMMarker : public Gmmarker::TCustomGMMarker
{
	typedef Gmmarker::TCustomGMMarker inherited;
	
public:
	TMarker* operator[](int I) { return this->Items[I]; }
	
protected:
	HIDESBASE TMarker* __fastcall GetItems(int I);
	virtual Gmlinkedcomponents::TLinkedComponentClass __fastcall GetCollectionItemClass();
	virtual Gmlinkedcomponents::TLinkedComponentsClass __fastcall GetCollectionClass();
	
public:
	HIDESBASE TMarker* __fastcall Add(double Lat = 0.000000E+00, double Lng = 0.000000E+00, System::UnicodeString Title = System::UnicodeString());
	__property TMarker* Items[int I] = {read=GetItems/*, default*/};
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual TGMMarker(System::Classes::TComponent* AOwner) : Gmmarker::TCustomGMMarker(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~TGMMarker() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmmarkervcl */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMMARKERVCL)
using namespace Gmmarkervcl;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmmarkervclHPP
