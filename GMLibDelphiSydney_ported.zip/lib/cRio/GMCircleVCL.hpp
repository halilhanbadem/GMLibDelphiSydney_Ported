﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMCircleVCL.pas' rev: 34.00 (Windows)

#ifndef GmcirclevclHPP
#define GmcirclevclHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Vcl.Graphics.hpp>
#include <System.Classes.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <GMCircle.hpp>
#include <GMLinkedComponents.hpp>
#include <System.UITypes.hpp>
#include <GMMap.hpp>
#include <GMClasses.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmcirclevcl
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TSizeable;
class DELPHICLASS TCircle;
class DELPHICLASS TCircles;
class DELPHICLASS TGMCircle;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TSizeable : public Gmcircle::TCustomSizeable
{
	typedef Gmcircle::TCustomSizeable inherited;
	
private:
	Vcl::Extctrls::TTimer* FTimer;
	
protected:
	virtual void __fastcall SetActive(const bool Value);
	virtual void __fastcall SetSpeed(const int Value);
	
public:
	__fastcall virtual TSizeable(TCircle* aOwner);
	__fastcall virtual ~TSizeable();
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TCircle : public Gmcircle::TCustomCircle
{
	typedef Gmcircle::TCustomCircle inherited;
	
private:
	System::Uitypes::TColor FFillColor;
	System::Uitypes::TColor FStrokeColor;
	void __fastcall SetFillColor(const System::Uitypes::TColor Value);
	void __fastcall SetStrokeColor(const System::Uitypes::TColor Value);
	
protected:
	virtual System::UnicodeString __fastcall GetFillColor();
	virtual System::UnicodeString __fastcall GetStrokeColor();
	
public:
	__fastcall virtual TCircle(System::Classes::TCollection* Collection);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::Uitypes::TColor FillColor = {read=FFillColor, write=SetFillColor, default=255};
	__property System::Uitypes::TColor StrokeColor = {read=FStrokeColor, write=SetStrokeColor, default=0};
public:
	/* TCustomCircle.Destroy */ inline __fastcall virtual ~TCircle() { }
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TCircles : public Gmcircle::TCustomCircles
{
	typedef Gmcircle::TCustomCircles inherited;
	
public:
	TCircle* operator[](int I) { return this->Items[I]; }
	
private:
	HIDESBASE void __fastcall SetItems(int I, TCircle* const Value);
	HIDESBASE TCircle* __fastcall GetItems(int I);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	HIDESBASE TCircle* __fastcall Add();
	HIDESBASE TCircle* __fastcall Insert(int Index);
	__property TCircle* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TLinkedComponents.Create */ inline __fastcall virtual TCircles(Gmlinkedcomponents::TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass) : Gmcircle::TCustomCircles(GMLinkedComponent, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TCircles() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TGMCircle : public Gmcircle::TCustomGMCircle
{
	typedef Gmcircle::TCustomGMCircle inherited;
	
public:
	TCircle* operator[](int I) { return this->Items[I]; }
	
protected:
	HIDESBASE TCircle* __fastcall GetItems(int I);
	virtual Gmlinkedcomponents::TLinkedComponentClass __fastcall GetCollectionItemClass();
	virtual Gmlinkedcomponents::TLinkedComponentsClass __fastcall GetCollectionClass();
	
public:
	HIDESBASE TCircle* __fastcall Add(double Lat = 0.000000E+00, double Lng = 0.000000E+00, int Radius = 0x0);
	__property TCircle* Items[int I] = {read=GetItems/*, default*/};
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual TGMCircle(System::Classes::TComponent* AOwner) : Gmcircle::TCustomGMCircle(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~TGMCircle() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmcirclevcl */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMCIRCLEVCL)
using namespace Gmcirclevcl;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmcirclevclHPP
