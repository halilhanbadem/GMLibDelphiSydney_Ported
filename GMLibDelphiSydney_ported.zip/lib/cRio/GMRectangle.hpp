﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMRectangle.pas' rev: 34.00 (Windows)

#ifndef GmrectangleHPP
#define GmrectangleHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <GMLinkedComponents.hpp>
#include <GMClasses.hpp>
#include <GMConstants.hpp>
#include <GMMap.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmrectangle
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCustomRectangle;
class DELPHICLASS TCustomRectangles;
class DELPHICLASS TCustomGMRectangle;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCustomRectangle : public Gmlinkedcomponents::TLinkedComponent
{
	typedef Gmlinkedcomponents::TLinkedComponent inherited;
	
private:
	bool FVisible;
	Gmclasses::TLatLngBounds* FBounds;
	int FStrokeWeight;
	double FFillOpacity;
	bool FClickable;
	double FStrokeOpacity;
	bool FEditable;
	bool FIsBoundsUpdt;
	void __fastcall SetClickable(const bool Value);
	void __fastcall SetEditable(const bool Value);
	void __fastcall SetFillOpacity(const double Value);
	void __fastcall SetStrokeOpacity(const double Value);
	void __fastcall SetStrokeWeight(const int Value);
	void __fastcall SetVisible(const bool Value);
	void __fastcall OnChangeBounds(System::TObject* Sender);
	
protected:
	virtual System::UnicodeString __fastcall GetFillColor() = 0 ;
	virtual System::UnicodeString __fastcall GetStrokeColor() = 0 ;
	virtual bool __fastcall ChangeProperties();
	
public:
	__fastcall virtual TCustomRectangle(System::Classes::TCollection* Collection);
	__fastcall virtual ~TCustomRectangle();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	void __fastcall ZoomToPoints();
	System::UnicodeString __fastcall GetStrPath();
	double __fastcall ComputeArea(double Radius = -1.000000E+00);
	void __fastcall GetCenter(Gmclasses::TLatLng* LL);
	virtual void __fastcall CenterMapTo();
	
__published:
	__property Gmclasses::TLatLngBounds* Bounds = {read=FBounds, write=FBounds};
	__property bool Clickable = {read=FClickable, write=SetClickable, default=1};
	__property bool Editable = {read=FEditable, write=SetEditable, default=0};
	__property double FillOpacity = {read=FFillOpacity, write=SetFillOpacity};
	__property double StrokeOpacity = {read=FStrokeOpacity, write=SetStrokeOpacity};
	__property int StrokeWeight = {read=FStrokeWeight, write=SetStrokeWeight, default=2};
	__property bool Visible = {read=FVisible, write=SetVisible, default=1};
	__property InfoWindow;
	__property Text = {default=0};
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomRectangles : public Gmlinkedcomponents::TLinkedComponents
{
	typedef Gmlinkedcomponents::TLinkedComponents inherited;
	
public:
	TCustomRectangle* operator[](int I) { return this->Items[I]; }
	
private:
	HIDESBASE void __fastcall SetItems(int I, TCustomRectangle* const Value);
	HIDESBASE TCustomRectangle* __fastcall GetItems(int I);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	HIDESBASE TCustomRectangle* __fastcall Add();
	HIDESBASE TCustomRectangle* __fastcall Insert(int Index);
	__property TCustomRectangle* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TLinkedComponents.Create */ inline __fastcall virtual TCustomRectangles(Gmlinkedcomponents::TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass) : Gmlinkedcomponents::TLinkedComponents(GMLinkedComponent, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TCustomRectangles() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TCustomGMRectangle : public Gmlinkedcomponents::TGMLinkedComponent
{
	typedef Gmlinkedcomponents::TGMLinkedComponent inherited;
	
public:
	TCustomRectangle* operator[](int I) { return this->Items[I]; }
	
private:
	Gmlinkedcomponents::TLinkedComponentChange FOnStrokeColorChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnRightClick;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseDown;
	Gmlinkedcomponents::TLinkedComponentChange FOnVisibleChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseMove;
	Gmlinkedcomponents::TLinkedComponentChange FOnStrokeWeightChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseUp;
	Gmlinkedcomponents::TLinkedComponentChange FOnFillOpacityChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnClickableChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseOut;
	Gmlinkedcomponents::TLinkedComponentChange FOnStrokeOpacityChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnEditableChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnBoundsChanged;
	Gmlinkedcomponents::TLatLngIdxEvent FOnDblClick;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseOver;
	Gmlinkedcomponents::TLinkedComponentChange FOnFillColorChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnClick;
	
protected:
	virtual System::UnicodeString __fastcall GetAPIUrl();
	HIDESBASE TCustomRectangle* __fastcall GetItems(int I);
	virtual void __fastcall EventFired(Gmconstants::TEventType EventType, System::TVarRec *Params, const int Params_High);
	virtual Gmlinkedcomponents::TLinkedComponentClass __fastcall GetCollectionItemClass();
	virtual Gmlinkedcomponents::TLinkedComponentsClass __fastcall GetCollectionClass();
	
public:
	HIDESBASE TCustomRectangle* __fastcall Add(double SWLat = 0.000000E+00, double SWLng = 0.000000E+00, double NELat = 0.000000E+00, double NELng = 0.000000E+00);
	__property TCustomRectangle* Items[int I] = {read=GetItems/*, default*/};
	
__published:
	__property VisualObjects;
	__property Gmlinkedcomponents::TLinkedComponentChange OnBoundsChanged = {read=FOnBoundsChanged, write=FOnBoundsChanged};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnClick = {read=FOnClick, write=FOnClick};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnDblClick = {read=FOnDblClick, write=FOnDblClick};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseDown = {read=FOnMouseDown, write=FOnMouseDown};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseMove = {read=FOnMouseMove, write=FOnMouseMove};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseOut = {read=FOnMouseOut, write=FOnMouseOut};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseOver = {read=FOnMouseOver, write=FOnMouseOver};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseUp = {read=FOnMouseUp, write=FOnMouseUp};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnRightClick = {read=FOnRightClick, write=FOnRightClick};
	__property Gmlinkedcomponents::TLinkedComponentChange OnClickableChange = {read=FOnClickableChange, write=FOnClickableChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnEditableChange = {read=FOnEditableChange, write=FOnEditableChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnFillColorChange = {read=FOnFillColorChange, write=FOnFillColorChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnFillOpacityChange = {read=FOnFillOpacityChange, write=FOnFillOpacityChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnStrokeColorChange = {read=FOnStrokeColorChange, write=FOnStrokeColorChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnStrokeOpacityChange = {read=FOnStrokeOpacityChange, write=FOnStrokeOpacityChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnStrokeWeightChange = {read=FOnStrokeWeightChange, write=FOnStrokeWeightChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnVisibleChange = {read=FOnVisibleChange, write=FOnVisibleChange};
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual TCustomGMRectangle(System::Classes::TComponent* AOwner) : Gmlinkedcomponents::TGMLinkedComponent(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~TCustomGMRectangle() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmrectangle */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMRECTANGLE)
using namespace Gmrectangle;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmrectangleHPP
