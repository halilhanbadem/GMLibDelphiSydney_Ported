﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMCircle.pas' rev: 34.00 (Windows)

#ifndef GmcircleHPP
#define GmcircleHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <GMLinkedComponents.hpp>
#include <GMClasses.hpp>
#include <GMConstants.hpp>
#include <GMMap.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmcircle
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCustomSizeable;
class DELPHICLASS TCustomCircle;
class DELPHICLASS TCustomCircles;
class DELPHICLASS TCustomGMCircle;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomSizeable : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	int FMax;
	int FIncrement;
	int FMin;
	bool FCircular;
	bool FActive;
	int FSpeed;
	TCustomCircle* FOwner;
	
protected:
	virtual void __fastcall SetActive(const bool Value);
	virtual void __fastcall SetSpeed(const int Value);
	HIDESBASE virtual TCustomCircle* __fastcall GetOwner();
	void __fastcall OnTimer(System::TObject* Sender);
	
public:
	__fastcall virtual TCustomSizeable(TCustomCircle* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property bool Active = {read=FActive, write=SetActive, default=0};
	__property int Min = {read=FMin, write=FMin, default=0};
	__property int Max = {read=FMax, write=FMax, default=0};
	__property int Increment = {read=FIncrement, write=FIncrement, default=100};
	__property bool Circular = {read=FCircular, write=FCircular, default=1};
	__property int Speed = {read=FSpeed, write=SetSpeed, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TCustomSizeable() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TCustomCircle : public Gmlinkedcomponents::TLinkedComponent
{
	typedef Gmlinkedcomponents::TLinkedComponent inherited;
	
private:
	double FRadius;
	bool FVisible;
	int FStrokeWeight;
	double FFillOpacity;
	bool FClickable;
	Gmclasses::TLatLng* FCenter;
	double FStrokeOpacity;
	bool FEditable;
	TCustomSizeable* FAutoResize;
	bool FIsUpdating;
	void __fastcall SetClickable(const bool Value);
	void __fastcall SetEditable(const bool Value);
	void __fastcall SetFillOpacity(const double Value);
	void __fastcall SetRadius(const double Value);
	void __fastcall SetStrokeOpacity(const double Value);
	void __fastcall SetStrokeWeight(const int Value);
	void __fastcall SetVisible(const bool Value);
	void __fastcall OnChangeLatLng(System::TObject* Sender);
	
protected:
	virtual bool __fastcall ChangeProperties();
	virtual System::UnicodeString __fastcall GetFillColor() = 0 ;
	virtual System::UnicodeString __fastcall GetStrokeColor() = 0 ;
	
public:
	__fastcall virtual TCustomCircle(System::Classes::TCollection* Collection);
	__fastcall virtual ~TCustomCircle();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	virtual void __fastcall CenterMapTo();
	void __fastcall GetBounds(Gmclasses::TLatLngBounds* LLB);
	
__published:
	__property Gmclasses::TLatLng* Center = {read=FCenter, write=FCenter};
	__property bool Clickable = {read=FClickable, write=SetClickable, default=1};
	__property bool Editable = {read=FEditable, write=SetEditable, default=0};
	__property double FillOpacity = {read=FFillOpacity, write=SetFillOpacity};
	__property double Radius = {read=FRadius, write=SetRadius};
	__property double StrokeOpacity = {read=FStrokeOpacity, write=SetStrokeOpacity};
	__property int StrokeWeight = {read=FStrokeWeight, write=SetStrokeWeight, default=2};
	__property bool Visible = {read=FVisible, write=SetVisible, default=1};
	__property TCustomSizeable* AutoResize = {read=FAutoResize, write=FAutoResize};
	__property InfoWindow;
	__property Text = {default=0};
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TCustomCircles : public Gmlinkedcomponents::TLinkedComponents
{
	typedef Gmlinkedcomponents::TLinkedComponents inherited;
	
public:
	TCustomCircle* operator[](int I) { return this->Items[I]; }
	
private:
	HIDESBASE void __fastcall SetItems(int I, TCustomCircle* const Value);
	HIDESBASE TCustomCircle* __fastcall GetItems(int I);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	HIDESBASE TCustomCircle* __fastcall Add();
	HIDESBASE TCustomCircle* __fastcall Insert(int Index);
	__property TCustomCircle* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TLinkedComponents.Create */ inline __fastcall virtual TCustomCircles(Gmlinkedcomponents::TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass) : Gmlinkedcomponents::TLinkedComponents(GMLinkedComponent, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TCustomCircles() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TCustomGMCircle : public Gmlinkedcomponents::TGMLinkedComponent
{
	typedef Gmlinkedcomponents::TGMLinkedComponent inherited;
	
public:
	TCustomCircle* operator[](int I) { return this->Items[I]; }
	
private:
	Gmlinkedcomponents::TLinkedComponentChange FOnStrokeColorChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnRightClick;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseDown;
	Gmlinkedcomponents::TLinkedComponentChange FOnVisibleChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseMove;
	Gmlinkedcomponents::TLinkedComponentChange FOnStrokeWeightChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseUp;
	Gmlinkedcomponents::TLinkedComponentChange FOnFillOpacityChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnClickableChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnCenterChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseOut;
	Gmlinkedcomponents::TLinkedComponentChange FOnStrokeOpacityChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnEditableChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnDblClick;
	Gmlinkedcomponents::TLatLngIdxEvent FOnMouseOver;
	Gmlinkedcomponents::TLinkedComponentChange FOnFillColorChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnRadiusChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnClick;
	
protected:
	virtual System::UnicodeString __fastcall GetAPIUrl();
	HIDESBASE TCustomCircle* __fastcall GetItems(int I);
	virtual void __fastcall EventFired(Gmconstants::TEventType EventType, System::TVarRec *Params, const int Params_High);
	virtual Gmlinkedcomponents::TLinkedComponentClass __fastcall GetCollectionItemClass();
	virtual Gmlinkedcomponents::TLinkedComponentsClass __fastcall GetCollectionClass();
	
public:
	HIDESBASE TCustomCircle* __fastcall Add(double Lat = 0.000000E+00, double Lng = 0.000000E+00, int Radius = 0x0);
	__property TCustomCircle* Items[int I] = {read=GetItems/*, default*/};
	
__published:
	__property VisualObjects;
	__property Gmlinkedcomponents::TLatLngIdxEvent OnCenterChange = {read=FOnCenterChange, write=FOnCenterChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnRadiusChange = {read=FOnRadiusChange, write=FOnRadiusChange};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnClick = {read=FOnClick, write=FOnClick};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnDblClick = {read=FOnDblClick, write=FOnDblClick};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseDown = {read=FOnMouseDown, write=FOnMouseDown};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseMove = {read=FOnMouseMove, write=FOnMouseMove};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseOut = {read=FOnMouseOut, write=FOnMouseOut};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseOver = {read=FOnMouseOver, write=FOnMouseOver};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnMouseUp = {read=FOnMouseUp, write=FOnMouseUp};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnRightClick = {read=FOnRightClick, write=FOnRightClick};
	__property Gmlinkedcomponents::TLinkedComponentChange OnClickableChange = {read=FOnClickableChange, write=FOnClickableChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnEditableChange = {read=FOnEditableChange, write=FOnEditableChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnFillColorChange = {read=FOnFillColorChange, write=FOnFillColorChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnFillOpacityChange = {read=FOnFillOpacityChange, write=FOnFillOpacityChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnStrokeColorChange = {read=FOnStrokeColorChange, write=FOnStrokeColorChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnStrokeOpacityChange = {read=FOnStrokeOpacityChange, write=FOnStrokeOpacityChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnStrokeWeightChange = {read=FOnStrokeWeightChange, write=FOnStrokeWeightChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnVisibleChange = {read=FOnVisibleChange, write=FOnVisibleChange};
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual TCustomGMCircle(System::Classes::TComponent* AOwner) : Gmlinkedcomponents::TGMLinkedComponent(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~TCustomGMCircle() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmcircle */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMCIRCLE)
using namespace Gmcircle;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmcircleHPP
