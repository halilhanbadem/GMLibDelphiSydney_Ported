﻿// CodeGear C++Builder
// Copyright (c) 1995, 2020 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Vcl.ComStrs.pas' rev: 34.00 (Windows)

#ifndef Vcl_ComstrsHPP
#define Vcl_ComstrsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>

//-- user supplied -----------------------------------------------------------

namespace Vcl
{
namespace Comstrs
{
//-- forward type declarations -----------------------------------------------
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE System::ResourceString _sTabFailClear;
#define Vcl_Comstrs_sTabFailClear System::LoadResourceString(&Vcl::Comstrs::_sTabFailClear)
extern DELPHI_PACKAGE System::ResourceString _sTabFailDelete;
#define Vcl_Comstrs_sTabFailDelete System::LoadResourceString(&Vcl::Comstrs::_sTabFailDelete)
extern DELPHI_PACKAGE System::ResourceString _sTabFailRetrieve;
#define Vcl_Comstrs_sTabFailRetrieve System::LoadResourceString(&Vcl::Comstrs::_sTabFailRetrieve)
extern DELPHI_PACKAGE System::ResourceString _sTabFailGetObject;
#define Vcl_Comstrs_sTabFailGetObject System::LoadResourceString(&Vcl::Comstrs::_sTabFailGetObject)
extern DELPHI_PACKAGE System::ResourceString _sTabFailSet;
#define Vcl_Comstrs_sTabFailSet System::LoadResourceString(&Vcl::Comstrs::_sTabFailSet)
extern DELPHI_PACKAGE System::ResourceString _sTabFailSetObject;
#define Vcl_Comstrs_sTabFailSetObject System::LoadResourceString(&Vcl::Comstrs::_sTabFailSetObject)
extern DELPHI_PACKAGE System::ResourceString _sTabMustBeMultiLine;
#define Vcl_Comstrs_sTabMustBeMultiLine System::LoadResourceString(&Vcl::Comstrs::_sTabMustBeMultiLine)
extern DELPHI_PACKAGE System::ResourceString _sInvalidLevel;
#define Vcl_Comstrs_sInvalidLevel System::LoadResourceString(&Vcl::Comstrs::_sInvalidLevel)
extern DELPHI_PACKAGE System::ResourceString _sInvalidLevelEx;
#define Vcl_Comstrs_sInvalidLevelEx System::LoadResourceString(&Vcl::Comstrs::_sInvalidLevelEx)
extern DELPHI_PACKAGE System::ResourceString _sInvalidIndex;
#define Vcl_Comstrs_sInvalidIndex System::LoadResourceString(&Vcl::Comstrs::_sInvalidIndex)
extern DELPHI_PACKAGE System::ResourceString _sInsertError;
#define Vcl_Comstrs_sInsertError System::LoadResourceString(&Vcl::Comstrs::_sInsertError)
extern DELPHI_PACKAGE System::ResourceString _sInvalidOwner;
#define Vcl_Comstrs_sInvalidOwner System::LoadResourceString(&Vcl::Comstrs::_sInvalidOwner)
extern DELPHI_PACKAGE System::ResourceString _sUnableToCreateColumn;
#define Vcl_Comstrs_sUnableToCreateColumn System::LoadResourceString(&Vcl::Comstrs::_sUnableToCreateColumn)
extern DELPHI_PACKAGE System::ResourceString _sUnableToCreateItem;
#define Vcl_Comstrs_sUnableToCreateItem System::LoadResourceString(&Vcl::Comstrs::_sUnableToCreateItem)
extern DELPHI_PACKAGE System::ResourceString _sRichEditInsertError;
#define Vcl_Comstrs_sRichEditInsertError System::LoadResourceString(&Vcl::Comstrs::_sRichEditInsertError)
extern DELPHI_PACKAGE System::ResourceString _sRichEditLoadFail;
#define Vcl_Comstrs_sRichEditLoadFail System::LoadResourceString(&Vcl::Comstrs::_sRichEditLoadFail)
extern DELPHI_PACKAGE System::ResourceString _sRichEditSaveFail;
#define Vcl_Comstrs_sRichEditSaveFail System::LoadResourceString(&Vcl::Comstrs::_sRichEditSaveFail)
extern DELPHI_PACKAGE System::ResourceString _sTooManyPanels;
#define Vcl_Comstrs_sTooManyPanels System::LoadResourceString(&Vcl::Comstrs::_sTooManyPanels)
extern DELPHI_PACKAGE System::ResourceString _sHKError;
#define Vcl_Comstrs_sHKError System::LoadResourceString(&Vcl::Comstrs::_sHKError)
extern DELPHI_PACKAGE System::ResourceString _sHKInvalid;
#define Vcl_Comstrs_sHKInvalid System::LoadResourceString(&Vcl::Comstrs::_sHKInvalid)
extern DELPHI_PACKAGE System::ResourceString _sHKInvalidWindow;
#define Vcl_Comstrs_sHKInvalidWindow System::LoadResourceString(&Vcl::Comstrs::_sHKInvalidWindow)
extern DELPHI_PACKAGE System::ResourceString _sHKAssigned;
#define Vcl_Comstrs_sHKAssigned System::LoadResourceString(&Vcl::Comstrs::_sHKAssigned)
extern DELPHI_PACKAGE System::ResourceString _sUDAssociated;
#define Vcl_Comstrs_sUDAssociated System::LoadResourceString(&Vcl::Comstrs::_sUDAssociated)
extern DELPHI_PACKAGE System::ResourceString _sPageIndexError;
#define Vcl_Comstrs_sPageIndexError System::LoadResourceString(&Vcl::Comstrs::_sPageIndexError)
extern DELPHI_PACKAGE System::ResourceString _sInvalidComCtl32;
#define Vcl_Comstrs_sInvalidComCtl32 System::LoadResourceString(&Vcl::Comstrs::_sInvalidComCtl32)
extern DELPHI_PACKAGE System::ResourceString _sDateTimeMax;
#define Vcl_Comstrs_sDateTimeMax System::LoadResourceString(&Vcl::Comstrs::_sDateTimeMax)
extern DELPHI_PACKAGE System::ResourceString _sDateTimeMin;
#define Vcl_Comstrs_sDateTimeMin System::LoadResourceString(&Vcl::Comstrs::_sDateTimeMin)
extern DELPHI_PACKAGE System::ResourceString _sNeedAllowNone;
#define Vcl_Comstrs_sNeedAllowNone System::LoadResourceString(&Vcl::Comstrs::_sNeedAllowNone)
extern DELPHI_PACKAGE System::ResourceString _sFailSetCalDateTime;
#define Vcl_Comstrs_sFailSetCalDateTime System::LoadResourceString(&Vcl::Comstrs::_sFailSetCalDateTime)
extern DELPHI_PACKAGE System::ResourceString _sFailSetCalMaxSelRange;
#define Vcl_Comstrs_sFailSetCalMaxSelRange System::LoadResourceString(&Vcl::Comstrs::_sFailSetCalMaxSelRange)
extern DELPHI_PACKAGE System::ResourceString _sFailSetCalMinMaxRange;
#define Vcl_Comstrs_sFailSetCalMinMaxRange System::LoadResourceString(&Vcl::Comstrs::_sFailSetCalMinMaxRange)
extern DELPHI_PACKAGE System::ResourceString _sCalRangeNeedsMultiSelect;
#define Vcl_Comstrs_sCalRangeNeedsMultiSelect System::LoadResourceString(&Vcl::Comstrs::_sCalRangeNeedsMultiSelect)
extern DELPHI_PACKAGE System::ResourceString _sFailsetCalSelRange;
#define Vcl_Comstrs_sFailsetCalSelRange System::LoadResourceString(&Vcl::Comstrs::_sFailsetCalSelRange)
}	/* namespace Comstrs */
}	/* namespace Vcl */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_VCL_COMSTRS)
using namespace Vcl::Comstrs;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_VCL)
using namespace Vcl;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Vcl_ComstrsHPP
