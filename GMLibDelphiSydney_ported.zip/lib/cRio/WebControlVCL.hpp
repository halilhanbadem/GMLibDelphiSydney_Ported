﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'WebControlVCL.pas' rev: 34.00 (Windows)

#ifndef WebcontrolvclHPP
#define WebcontrolvclHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <MSHTML.hpp>
#include <SHDocVw.hpp>
#include <System.SysUtils.hpp>
#include <WebControl.hpp>

//-- user supplied -----------------------------------------------------------

namespace Webcontrolvcl
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWebControl;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TWebControl : public Webcontrol::TCustomWeb
{
	typedef Webcontrol::TCustomWeb inherited;
	
protected:
	Mshtml::_di_IHTMLFormElement __fastcall WebFormGet(const int FormNumber);
	virtual System::UnicodeString __fastcall WebFormFieldValue(const int FormIdx, const System::UnicodeString FieldName)/* overload */;
	
public:
	__fastcall virtual TWebControl(Shdocvw::TWebBrowser* WebBrowser);
	virtual void __fastcall WebFormNames();
	virtual void __fastcall WebFormFields(const int FormIdx)/* overload */;
	virtual void __fastcall WebFormSetFieldValue(const int FormIdx, const System::UnicodeString FieldName, const System::UnicodeString NewValue)/* overload */;
	virtual void __fastcall WebFormSubmit(const int FormIdx)/* overload */;
	virtual System::UnicodeString __fastcall WebHTMLCode();
	virtual void __fastcall WebPrintWithoutDialog();
	virtual void __fastcall WebPrintWithDialog();
	virtual void __fastcall WebPrintPageSetup();
	virtual void __fastcall WebPreview();
	virtual void __fastcall SaveToJPGFile(System::Sysutils::TFileName FileName = System::Sysutils::TFileName());
	HIDESBASE virtual void __fastcall SetBrowser(Shdocvw::TWebBrowser* Browser);
public:
	/* TCustomWeb.Destroy */ inline __fastcall virtual ~TWebControl() { }
	
	/* Hoisted overloads: */
	
protected:
	inline System::UnicodeString __fastcall  WebFormFieldValue(const System::UnicodeString FormName, const System::UnicodeString FieldName){ return Webcontrol::TCustomWeb::WebFormFieldValue(FormName, FieldName); }
	
public:
	inline void __fastcall  WebFormFields(const System::UnicodeString FormName){ Webcontrol::TCustomWeb::WebFormFields(FormName); }
	inline void __fastcall  WebFormSetFieldValue(const System::UnicodeString FormName, const System::UnicodeString FieldName, const System::UnicodeString NewValue){ Webcontrol::TCustomWeb::WebFormSetFieldValue(FormName, FieldName, NewValue); }
	inline void __fastcall  WebFormSubmit(const System::UnicodeString FormName){ Webcontrol::TCustomWeb::WebFormSubmit(FormName); }
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Webcontrolvcl */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_WEBCONTROLVCL)
using namespace Webcontrolvcl;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// WebcontrolvclHPP
