﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMDirectionVCL.pas' rev: 34.00 (Windows)

#ifndef GmdirectionvclHPP
#define GmdirectionvclHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <Vcl.Graphics.hpp>
#include <GMDirection.hpp>
#include <System.UITypes.hpp>
#include <GMMap.hpp>
#include <GMClasses.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmdirectionvcl
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TPolylineOptions;
class DELPHICLASS TDirectionsRenderer;
class DELPHICLASS TDirectionsResult;
class DELPHICLASS TGMDirection;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TPolylineOptions : public Gmdirection::TCustomPolylineOptions
{
	typedef Gmdirection::TCustomPolylineOptions inherited;
	
private:
	System::Uitypes::TColor FStrokeColor;
	void __fastcall SetStrokeColor(const System::Uitypes::TColor Value);
	
protected:
	virtual System::UnicodeString __fastcall GetStrokeColor();
	
public:
	__fastcall virtual TPolylineOptions(System::Classes::TPersistent* aOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::Uitypes::TColor StrokeColor = {read=FStrokeColor, write=SetStrokeColor, default=16711680};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TPolylineOptions() { }
	
};


class PASCALIMPLEMENTATION TDirectionsRenderer : public Gmdirection::TCustomDirectionsRenderer
{
	typedef Gmdirection::TCustomDirectionsRenderer inherited;
	
private:
	TPolylineOptions* FPolylineOptions;
	
protected:
	virtual void __fastcall CreatePolylineOptions();
	virtual System::UnicodeString __fastcall PolylineOptionsToStr();
	
public:
	__fastcall virtual ~TDirectionsRenderer();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property TPolylineOptions* PolylineOptions = {read=FPolylineOptions, write=FPolylineOptions};
public:
	/* TCustomDirectionsRenderer.Create */ inline __fastcall virtual TDirectionsRenderer(System::TObject* aOwner) : Gmdirection::TCustomDirectionsRenderer(aOwner) { }
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TDirectionsResult : public Gmdirection::TCustomDirectionsResult
{
	typedef Gmdirection::TCustomDirectionsResult inherited;
	
private:
	TDirectionsRenderer* FDirectionsRender;
	
protected:
	virtual void __fastcall CreateDirectionsRenderObject();
	virtual System::UnicodeString __fastcall DirectionsRenderToStr();
	
public:
	__fastcall virtual ~TDirectionsResult();
	virtual void __fastcall Assign(System::TObject* Source);
	__property TDirectionsRenderer* DirectionsRender = {read=FDirectionsRender, write=FDirectionsRender};
public:
	/* TCustomDirectionsResult.Create */ inline __fastcall virtual TDirectionsResult(Gmdirection::TCustomGMDirection* aOwner, int Index) : Gmdirection::TCustomDirectionsResult(aOwner, Index) { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TGMDirection : public Gmdirection::TCustomGMDirection
{
	typedef Gmdirection::TCustomGMDirection inherited;
	
public:
	TDirectionsResult* operator[](int I) { return this->DirectionsResult[I]; }
	
private:
	TDirectionsRenderer* FDirectionsRender;
	HIDESBASE TDirectionsResult* __fastcall GetDirectionResult(int I);
	
protected:
	virtual System::UnicodeString __fastcall DirectionsRenderToStr();
	virtual void __fastcall CreateDirectionsRenderObject();
	virtual int __fastcall GetRetournedData();
	
public:
	__fastcall virtual ~TGMDirection();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	__property TDirectionsResult* DirectionsResult[int I] = {read=GetDirectionResult/*, default*/};
	
__published:
	__property TDirectionsRenderer* DirectionsRender = {read=FDirectionsRender, write=FDirectionsRender};
public:
	/* TCustomGMDirection.Create */ inline __fastcall virtual TGMDirection(System::Classes::TComponent* aOwner) : Gmdirection::TCustomGMDirection(aOwner) { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmdirectionvcl */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMDIRECTIONVCL)
using namespace Gmdirectionvcl;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmdirectionvclHPP
