﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMHeatmap.pas' rev: 34.00 (Windows)

#ifndef GmheatmapHPP
#define GmheatmapHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <GMMap.hpp>
#include <GMClasses.hpp>
#include <GMConstants.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmheatmap
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TGMHeatmap;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TGMHeatmap : public Gmmap::TGMObjects
{
	typedef Gmmap::TGMObjects inherited;
	
public:
	Gmclasses::TLinePoint* operator[](int I) { return this->Items[I]; }
	
private:
	double FOpacity;
	int FRadius;
	bool FDissipating;
	bool FShow;
	double FMaxIntensity;
	Gmclasses::TLinePoints* FData;
	Gmconstants::TGradient FGradient;
	Gmclasses::TLinePoint* __fastcall GetItems(int I);
	void __fastcall SetShow(const bool Value);
	int __fastcall GetCount();
	void __fastcall SetDissipating(const bool Value);
	void __fastcall SetMaxIntensity(const double Value);
	void __fastcall SetOpacity(const double Value);
	void __fastcall SetRadius(const int Value);
	void __fastcall SetGradient(const Gmconstants::TGradient Value);
	
protected:
	virtual void __fastcall HideHeapmap();
	virtual void __fastcall ShowHeapmap();
	System::UnicodeString __fastcall PolylineToStr();
	virtual System::UnicodeString __fastcall GetAPIUrl();
	virtual void __fastcall DeleteMapObjects();
	virtual void __fastcall ShowElements();
	virtual void __fastcall EventFired(Gmconstants::TEventType EventType, System::TVarRec *Params, const int Params_High);
	void __fastcall LinePointChanged();
	
public:
	__fastcall virtual TGMHeatmap(System::Classes::TComponent* aOwner);
	__fastcall virtual ~TGMHeatmap();
	void __fastcall LoadFromCSV(int LatColumn, int LngColumn, System::UnicodeString FileName, System::WideChar Delimiter = (System::WideChar)(0x2c), bool DeleteBeforeLoad = true, bool WithRownTitle = true);
	void __fastcall Clear();
	__property int Count = {read=GetCount, nodefault};
	__property Gmclasses::TLinePoint* Items[int I] = {read=GetItems/*, default*/};
	
__published:
	__property bool Show = {read=FShow, write=SetShow, default=0};
	__property Gmclasses::TLinePoints* Data = {read=FData, write=FData};
	__property bool Dissipating = {read=FDissipating, write=SetDissipating, default=0};
	__property double MaxIntensity = {read=FMaxIntensity, write=SetMaxIntensity};
	__property double Opacity = {read=FOpacity, write=SetOpacity};
	__property int Radius = {read=FRadius, write=SetRadius, default=15};
	__property Gmconstants::TGradient Gradient = {read=FGradient, write=SetGradient, default=0};
private:
	void *__ILinePoint;	// Gmclasses::ILinePoint 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {35926390-118A-4604-A343-73D200A36006}
	operator Gmclasses::_di_ILinePoint()
	{
		Gmclasses::_di_ILinePoint intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Gmclasses::ILinePoint*(void) { return (Gmclasses::ILinePoint*)&__ILinePoint; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmheatmap */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMHEATMAP)
using namespace Gmheatmap;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmheatmapHPP
