﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMGeoCode.pas' rev: 34.00 (Windows)

#ifndef GmgeocodeHPP
#define GmgeocodeHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.Contnrs.hpp>
#include <GMMap.hpp>
#include <GMClasses.hpp>
#include <GMMarker.hpp>
#include <GMConstants.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmgeocode
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TAddressComponent;
class DELPHICLASS TAddressComponentsList;
class DELPHICLASS TGeocodeGeometry;
class DELPHICLASS TGeoResult;
class DELPHICLASS TGMGeoCode;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TAddressComponent : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FShortName;
	System::Classes::TStringList* FAddrCompTypeList;
	System::UnicodeString FLongName;
	
public:
	__fastcall virtual TAddressComponent();
	__fastcall virtual ~TAddressComponent();
	virtual void __fastcall Assign(System::TObject* Source);
	__property System::UnicodeString ShortName = {read=FShortName};
	__property System::UnicodeString LongName = {read=FLongName};
	__property System::Classes::TStringList* AddrCompTypeList = {read=FAddrCompTypeList};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TAddressComponentsList : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	TAddressComponent* operator[](int Index) { return this->Items[Index]; }
	
private:
	System::Contnrs::TObjectList* FAddrComponents;
	TAddressComponent* __fastcall GetItem(int Index);
	int __fastcall GetCount();
	
public:
	__fastcall virtual TAddressComponentsList();
	__fastcall virtual ~TAddressComponentsList();
	virtual void __fastcall Assign(System::TObject* Source);
	int __fastcall Add(TAddressComponent* AddrComp);
	__property int Count = {read=GetCount, nodefault};
	__property TAddressComponent* Items[int Index] = {read=GetItem/*, default*/};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TGeocodeGeometry : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Gmclasses::TLatLng* FLocation;
	Gmconstants::TGeocoderLocationType FLocationType;
	Gmclasses::TLatLngBounds* FViewport;
	Gmclasses::TLatLngBounds* FBounds;
	
public:
	__fastcall virtual TGeocodeGeometry();
	__fastcall virtual ~TGeocodeGeometry();
	virtual void __fastcall Assign(System::TObject* Source);
	__property Gmclasses::TLatLng* Location = {read=FLocation};
	__property Gmconstants::TGeocoderLocationType LocationType = {read=FLocationType, nodefault};
	__property Gmclasses::TLatLngBounds* Viewport = {read=FViewport};
	__property Gmclasses::TLatLngBounds* Bounds = {read=FBounds};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TGeoResult : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::Classes::TStringList* FTypeList;
	System::UnicodeString FFormatedAddr;
	TAddressComponentsList* FAddrCompList;
	TGeocodeGeometry* FGeometry;
	
public:
	__fastcall virtual TGeoResult();
	__fastcall virtual ~TGeoResult();
	virtual void __fastcall Assign(System::TObject* Source);
	__property System::Classes::TStringList* TypeList = {read=FTypeList};
	__property System::UnicodeString FormatedAddr = {read=FFormatedAddr};
	__property TAddressComponentsList* AddrCompList = {read=FAddrCompList};
	__property TGeocodeGeometry* Geometry = {read=FGeometry};
};

#pragma pack(pop)

typedef void __fastcall (__closure *TParseData)(System::TObject* Sender, int ActualNode, int CountNodes, bool &Continue);

class PASCALIMPLEMENTATION TGMGeoCode : public Gmmap::TGMObjects
{
	typedef Gmmap::TGMObjects inherited;
	
public:
	TGeoResult* operator[](int Index) { return this->GeoResult[Index]; }
	
private:
	Gmmarker::TCustomGMMarker* FMarker;
	System::Classes::TStringList* FXMLData;
	System::Classes::TNotifyEvent FAfterGetData;
	System::Classes::TNotifyEvent FBeforeParseData;
	System::Classes::TNotifyEvent FAfterParseData;
	Gmconstants::TGeocoderStatus FGeoStatus;
	TParseData FOnParseData;
	System::Contnrs::TObjectList* FGeoResults;
	System::UnicodeString FIcon;
	Gmclasses::TLatLngBounds* FBounds;
	Gmconstants::TRegion FRegion;
	Gmconstants::TLangCode FLangCode;
	bool FPaintMarkerFound;
	void __fastcall GeocodeData(System::UnicodeString Data);
	void __fastcall ParseData();
	TGeoResult* __fastcall GetGeoResult(int Index);
	int __fastcall GetCount();
	
protected:
	virtual void __fastcall Notification(System::Classes::TComponent* AComponent, System::Classes::TOperation Operation);
	virtual System::UnicodeString __fastcall GetAPIUrl();
	virtual void __fastcall DeleteMapObjects();
	virtual void __fastcall ShowElements();
	virtual void __fastcall EventFired(Gmconstants::TEventType EventType, System::TVarRec *Params, const int Params_High);
	Gmconstants::TGeocoderLocationType __fastcall StrToGeocoderLocationType(System::UnicodeString GeocoderLocationType);
	
public:
	__fastcall virtual TGMGeoCode(System::Classes::TComponent* aOwner);
	__fastcall virtual ~TGMGeoCode();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	void __fastcall Geocode(System::UnicodeString Address)/* overload */;
	void __fastcall Geocode(Gmclasses::TLatLng* LatLng)/* overload */;
	void __fastcall Geocode(double Lat, double Lng)/* overload */;
	void __fastcall DoMarkers();
	void __fastcall Clear();
	__property int Count = {read=GetCount, nodefault};
	__property TGeoResult* GeoResult[int Index] = {read=GetGeoResult/*, default*/};
	__property System::Classes::TStringList* XMLData = {read=FXMLData, write=FXMLData};
	__property Gmconstants::TGeocoderStatus GeoStatus = {read=FGeoStatus, nodefault};
	
__published:
	__property Gmmarker::TCustomGMMarker* Marker = {read=FMarker, write=FMarker};
	__property System::UnicodeString Icon = {read=FIcon, write=FIcon};
	__property Gmclasses::TLatLngBounds* Bounds = {read=FBounds, write=FBounds};
	__property Gmconstants::TRegion Region = {read=FRegion, write=FRegion, default=0};
	__property Gmconstants::TLangCode LangCode = {read=FLangCode, write=FLangCode, default=12};
	__property bool PaintMarkerFound = {read=FPaintMarkerFound, write=FPaintMarkerFound, default=0};
	__property System::Classes::TNotifyEvent AfterGetData = {read=FAfterGetData, write=FAfterGetData};
	__property System::Classes::TNotifyEvent BeforeParseData = {read=FBeforeParseData, write=FBeforeParseData};
	__property System::Classes::TNotifyEvent AfterParseData = {read=FAfterParseData, write=FAfterParseData};
	__property TParseData OnParseData = {read=FOnParseData, write=FOnParseData};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmgeocode */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMGEOCODE)
using namespace Gmgeocode;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmgeocodeHPP
