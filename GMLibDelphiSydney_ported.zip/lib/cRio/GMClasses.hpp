﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMClasses.pas' rev: 34.00 (Windows)

#ifndef GmclassesHPP
#define GmclassesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <GMConstants.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmclasses
{
//-- forward type declarations -----------------------------------------------
__interface DELPHIINTERFACE ILinePoint;
typedef System::DelphiInterface<ILinePoint> _di_ILinePoint;
class DELPHICLASS TLatLng;
class DELPHICLASS TLinePoint;
class DELPHICLASS TLinePoints;
class DELPHICLASS TGMBase;
class DELPHICLASS TLatLngBounds;
class DELPHICLASS TGMSize;
class DELPHICLASS TBaseInfoWindow;
//-- type declarations -------------------------------------------------------
__interface  INTERFACE_UUID("{35926390-118A-4604-A343-73D200A36006}") ILinePoint  : public System::IInterface 
{
	virtual void __fastcall LinePointChanged() = 0 ;
};

class PASCALIMPLEMENTATION TLatLng : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	double FLat;
	double FLng;
	System::Classes::TNotifyEvent FOnChange;
	
protected:
	virtual void __fastcall SetLat(const double Value);
	virtual void __fastcall SetLng(const double Value);
	void __fastcall LatLngToStr(System::UnicodeString &aLat, System::UnicodeString &aLng, int Precision = 0x6);
	
public:
	__fastcall virtual TLatLng(double Lat, double Lng);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	virtual bool __fastcall IsEqual(TLatLng* Other);
	System::UnicodeString __fastcall ToStr(int Precision = 0x6);
	System::UnicodeString __fastcall ToUrlValue(int Precision = 0x6);
	System::UnicodeString __fastcall LatToStr(int Precision = 0x6);
	System::UnicodeString __fastcall LngToStr(int Precision = 0x6);
	double __fastcall StringToReal(System::UnicodeString Value);
	__property System::Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	
__published:
	__property double Lat = {read=FLat, write=SetLat};
	__property double Lng = {read=FLng, write=SetLng};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TLatLng() { }
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TLinePoint : public System::Classes::TCollectionItem
{
	typedef System::Classes::TCollectionItem inherited;
	
private:
	TLatLng* FLatLng;
	int FTag;
	double __fastcall GetLat();
	double __fastcall GetLng();
	void __fastcall SetLat(const double Value);
	void __fastcall SetLng(const double Value);
	void __fastcall OnChangeFLatLng(System::TObject* Sender);
	
public:
	__fastcall virtual TLinePoint(System::Classes::TCollection* Collection);
	__fastcall virtual ~TLinePoint();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	void __fastcall SetLatLng(TLatLng* LatLng);
	System::UnicodeString __fastcall LatToStr(int Precision = 0x6);
	System::UnicodeString __fastcall LngToStr(int Precision = 0x6);
	System::UnicodeString __fastcall ToStr(int Precision = 0x6);
	double __fastcall StringToReal(System::UnicodeString Value);
	TLatLng* __fastcall GetLatLng();
	
__published:
	__property double Lat = {read=GetLat, write=SetLat};
	__property double Lng = {read=GetLng, write=SetLng};
	__property int Tag = {read=FTag, write=FTag, default=0};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TLinePoints : public System::Classes::TCollection
{
	typedef System::Classes::TCollection inherited;
	
public:
	TLinePoint* operator[](int I) { return this->Items[I]; }
	
private:
	System::TObject* FOwner;
	TLinePoint* __fastcall GetItems(int I);
	void __fastcall SetItems(int I, TLinePoint* const Value);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	__fastcall virtual TLinePoints(System::TObject* Owner, System::Classes::TCollectionItemClass ItemClass);
	HIDESBASE TLinePoint* __fastcall Add();
	HIDESBASE TLinePoint* __fastcall Insert(int Index);
	HIDESBASE void __fastcall Delete(int Index);
	void __fastcall Move(int CurIndex, int NewIndex);
	HIDESBASE void __fastcall Clear();
	System::UnicodeString __fastcall PointsToStr _DEPRECATED_ATTRIBUTE0 (int Precision = 0x6);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	__property TLinePoint* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TLinePoints() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TGMBase : public System::Classes::TComponent
{
	typedef System::Classes::TComponent inherited;
	
private:
	System::UnicodeString FAboutGMLib;
	Gmconstants::TLang FLanguage;
	
protected:
	virtual System::UnicodeString __fastcall GetAPIUrl();
	virtual double __fastcall ControlPrecision(double Value, int Prec);
	System::UnicodeString __fastcall GetConvertedString(System::UnicodeString Value);
	
public:
	__fastcall virtual TGMBase(System::Classes::TComponent* AOwner);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::UnicodeString APIUrl = {read=GetAPIUrl};
	__property Gmconstants::TLang Language = {read=FLanguage, write=FLanguage, default=1};
	__property System::UnicodeString AboutGMLib = {read=FAboutGMLib, stored=false};
public:
	/* TComponent.Destroy */ inline __fastcall virtual ~TGMBase() { }
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TLatLngBounds : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	TLatLng* FNE;
	TLatLng* FSW;
	
public:
	__fastcall virtual TLatLngBounds(double SWLat, double SWLng, double NELat, double NELng)/* overload */;
	__fastcall virtual TLatLngBounds(TLatLng* SW, TLatLng* NE)/* overload */;
	__fastcall virtual ~TLatLngBounds();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	bool __fastcall IsEqual(TLatLngBounds* Other);
	System::UnicodeString __fastcall ToStr(int Precision = 0x6);
	System::UnicodeString __fastcall ToUrlValue(int Precision = 0x6);
	
__published:
	__property TLatLng* SW = {read=FSW, write=FSW};
	__property TLatLng* NE = {read=FNE, write=FNE};
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TGMSize : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	int FWidth;
	int FHeight;
	System::Classes::TNotifyEvent FOnChange;
	
protected:
	virtual void __fastcall SetHeight(const int Value);
	virtual void __fastcall SetWidth(const int Value);
	
public:
	__fastcall virtual TGMSize();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	__property System::Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	
__published:
	__property int Height = {read=FHeight, write=SetHeight, default=0};
	__property int Width = {read=FWidth, write=SetWidth, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TGMSize() { }
	
};


class PASCALIMPLEMENTATION TBaseInfoWindow : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
private:
	System::Classes::TPersistent* FOwner;
	System::UnicodeString FHTMLContent;
	bool FDisableAutoPan;
	int FMaxWidth;
	TGMSize* FPixelOffset;
	bool FCloseOtherBeforeOpen;
	System::Classes::TNotifyEvent FOnMaxWidthChange;
	System::Classes::TNotifyEvent FOnCloseOtherBeforeOpenChange;
	System::Classes::TNotifyEvent FOnDisableAutoPanChange;
	System::Classes::TNotifyEvent FOnPixelOffsetChange;
	System::Classes::TNotifyEvent FOnHTMLContentChange;
	void __fastcall SetCloseOtherBeforeOpen(const bool Value);
	void __fastcall SetDisableAutoPan(const bool Value);
	void __fastcall SetHTMLContent(const System::UnicodeString Value);
	void __fastcall SetMaxWidth(const int Value);
	void __fastcall SetPixelOffset(TGMSize* const Value);
	
protected:
	void __fastcall PixelOffsetChange(System::TObject* Sender);
	
public:
	__fastcall virtual TBaseInfoWindow(System::Classes::TPersistent* aOwner);
	__fastcall virtual ~TBaseInfoWindow();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	System::UnicodeString __fastcall GetConvertedString();
	__property System::Classes::TNotifyEvent OnHTMLContentChange = {read=FOnHTMLContentChange, write=FOnHTMLContentChange};
	__property System::Classes::TNotifyEvent OnDisableAutoPanChange = {read=FOnDisableAutoPanChange, write=FOnDisableAutoPanChange};
	__property System::Classes::TNotifyEvent OnMaxWidthChange = {read=FOnMaxWidthChange, write=FOnMaxWidthChange};
	__property System::Classes::TNotifyEvent OnPixelOffsetChange = {read=FOnPixelOffsetChange, write=FOnPixelOffsetChange};
	__property System::Classes::TNotifyEvent OnCloseOtherBeforeOpenChange = {read=FOnCloseOtherBeforeOpenChange, write=FOnCloseOtherBeforeOpenChange};
	
__published:
	__property System::UnicodeString HTMLContent = {read=FHTMLContent, write=SetHTMLContent};
	__property bool DisableAutoPan = {read=FDisableAutoPan, write=SetDisableAutoPan, default=0};
	__property int MaxWidth = {read=FMaxWidth, write=SetMaxWidth, default=0};
	__property TGMSize* PixelOffset = {read=FPixelOffset, write=SetPixelOffset};
	__property bool CloseOtherBeforeOpen = {read=FCloseOtherBeforeOpen, write=SetCloseOtherBeforeOpen, default=1};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmclasses */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMCLASSES)
using namespace Gmclasses;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmclassesHPP
