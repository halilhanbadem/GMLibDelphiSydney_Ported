﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Lang.pas' rev: 34.00 (Windows)

#ifndef LangHPP
#define LangHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <GMConstants.hpp>

//-- user supplied -----------------------------------------------------------

namespace Lang
{
//-- forward type declarations -----------------------------------------------
//-- type declarations -------------------------------------------------------
typedef System::StaticArray<System::UnicodeString, 16> Lang__1;

typedef System::StaticArray<System::UnicodeString, 16> Lang__2;

typedef System::StaticArray<System::UnicodeString, 16> Lang__3;

typedef System::StaticArray<System::UnicodeString, 16> Lang__4;

typedef System::StaticArray<System::UnicodeString, 16> Lang__5;

typedef System::StaticArray<System::UnicodeString, 16> Lang__6;

typedef System::StaticArray<System::UnicodeString, 16> Lang__7;

typedef System::StaticArray<System::UnicodeString, 16> Lang__8;

typedef System::StaticArray<System::UnicodeString, 16> Lang__9;

//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE Lang__1 Lang_ESP;
extern DELPHI_PACKAGE Lang__2 Lang_ENG;
extern DELPHI_PACKAGE Lang__3 Lang_FRE;
extern DELPHI_PACKAGE Lang__4 Lang_PTBR;
extern DELPHI_PACKAGE Lang__5 Lang_DAN;
extern DELPHI_PACKAGE Lang__6 Lang_GER;
extern DELPHI_PACKAGE Lang__7 Lang_RUS;
extern DELPHI_PACKAGE Lang__8 Lang_HUN;
extern DELPHI_PACKAGE Lang__9 Lang_ITA;
extern DELPHI_PACKAGE System::UnicodeString __fastcall GetTranslateText(System::UnicodeString Text, Gmconstants::TLang Lang);
}	/* namespace Lang */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_LANG)
using namespace Lang;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// LangHPP
