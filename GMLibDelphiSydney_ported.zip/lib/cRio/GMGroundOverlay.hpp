﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMGroundOverlay.pas' rev: 34.00 (Windows)

#ifndef GmgroundoverlayHPP
#define GmgroundoverlayHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <GMLinkedComponents.hpp>
#include <GMClasses.hpp>
#include <GMConstants.hpp>
#include <GMMap.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmgroundoverlay
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TGroundOverlay;
class DELPHICLASS TGroundOverlays;
class DELPHICLASS TGMGroundOverlay;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TGroundOverlay : public Gmlinkedcomponents::TLinkedComponent
{
	typedef Gmlinkedcomponents::TLinkedComponent inherited;
	
private:
	double FOpacity;
	Gmclasses::TLatLngBounds* FBounds;
	System::UnicodeString FUrl;
	bool FClickable;
	bool FVisible;
	void __fastcall SetClickable(const bool Value);
	void __fastcall SetOpacity(const double Value);
	void __fastcall SetUrl(const System::UnicodeString Value);
	void __fastcall OnChangeBounds(System::TObject* Sender);
	void __fastcall SetVisible(const bool Value);
	
protected:
	virtual bool __fastcall ChangeProperties();
	
public:
	__fastcall virtual TGroundOverlay(System::Classes::TCollection* Collection);
	__fastcall virtual ~TGroundOverlay();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	virtual void __fastcall CenterMapTo();
	
__published:
	__property Gmclasses::TLatLngBounds* Bounds = {read=FBounds, write=FBounds};
	__property bool Clickable = {read=FClickable, write=SetClickable, nodefault};
	__property bool Visible = {read=FVisible, write=SetVisible, nodefault};
	__property double Opacity = {read=FOpacity, write=SetOpacity};
	__property System::UnicodeString Url = {read=FUrl, write=SetUrl};
	__property InfoWindow;
	__property Text = {default=0};
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TGroundOverlays : public Gmlinkedcomponents::TLinkedComponents
{
	typedef Gmlinkedcomponents::TLinkedComponents inherited;
	
public:
	TGroundOverlay* operator[](int I) { return this->Items[I]; }
	
private:
	HIDESBASE void __fastcall SetItems(int I, TGroundOverlay* const Value);
	HIDESBASE TGroundOverlay* __fastcall GetItems(int I);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	HIDESBASE TGroundOverlay* __fastcall Add();
	HIDESBASE TGroundOverlay* __fastcall Insert(int Index);
	__property TGroundOverlay* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TLinkedComponents.Create */ inline __fastcall virtual TGroundOverlays(Gmlinkedcomponents::TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass) : Gmlinkedcomponents::TLinkedComponents(GMLinkedComponent, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TGroundOverlays() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TGMGroundOverlay : public Gmlinkedcomponents::TGMLinkedComponent
{
	typedef Gmlinkedcomponents::TGMLinkedComponent inherited;
	
public:
	TGroundOverlay* operator[](int I) { return this->Items[I]; }
	
private:
	Gmlinkedcomponents::TLinkedComponentChange FOnClickableChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnOpacityChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnUrlChange;
	Gmlinkedcomponents::TLatLngIdxEvent FOnDblClick;
	Gmlinkedcomponents::TLatLngIdxEvent FOnClick;
	Gmlinkedcomponents::TLinkedComponentChange FOnBoundsChanged;
	Gmlinkedcomponents::TLinkedComponentChange FOnVisibleChange;
	
protected:
	virtual System::UnicodeString __fastcall GetAPIUrl();
	HIDESBASE TGroundOverlay* __fastcall GetItems(int I);
	virtual void __fastcall EventFired(Gmconstants::TEventType EventType, System::TVarRec *Params, const int Params_High);
	virtual Gmlinkedcomponents::TLinkedComponentClass __fastcall GetCollectionItemClass();
	virtual Gmlinkedcomponents::TLinkedComponentsClass __fastcall GetCollectionClass();
	
public:
	HIDESBASE TGroundOverlay* __fastcall Add(System::UnicodeString Url, double SWLat = 0.000000E+00, double SWLng = 0.000000E+00, double NELat = 0.000000E+00, double NELng = 0.000000E+00);
	__property TGroundOverlay* Items[int I] = {read=GetItems/*, default*/};
	
__published:
	__property VisualObjects;
	__property Gmlinkedcomponents::TLatLngIdxEvent OnClick = {read=FOnClick, write=FOnClick};
	__property Gmlinkedcomponents::TLatLngIdxEvent OnDblClick = {read=FOnDblClick, write=FOnDblClick};
	__property Gmlinkedcomponents::TLinkedComponentChange OnClickableChange = {read=FOnClickableChange, write=FOnClickableChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnBoundsChanged = {read=FOnBoundsChanged, write=FOnBoundsChanged};
	__property Gmlinkedcomponents::TLinkedComponentChange OnOpacityChange = {read=FOnOpacityChange, write=FOnOpacityChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnUrlChange = {read=FOnUrlChange, write=FOnUrlChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnVisibleChange = {read=FOnVisibleChange, write=FOnVisibleChange};
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual TGMGroundOverlay(System::Classes::TComponent* AOwner) : Gmlinkedcomponents::TGMLinkedComponent(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~TGMGroundOverlay() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmgroundoverlay */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMGROUNDOVERLAY)
using namespace Gmgroundoverlay;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmgroundoverlayHPP
