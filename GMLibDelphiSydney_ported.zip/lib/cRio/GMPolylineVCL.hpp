﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'GMPolylineVCL.pas' rev: 34.00 (Windows)

#ifndef GmpolylinevclHPP
#define GmpolylinevclHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <Vcl.Graphics.hpp>
#include <GMPolyline.hpp>
#include <GMLinkedComponents.hpp>
#include <System.UITypes.hpp>
#include <GMMap.hpp>
#include <GMClasses.hpp>

//-- user supplied -----------------------------------------------------------

namespace Gmpolylinevcl
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TSymbol;
class DELPHICLASS TIconSequence;
class DELPHICLASS TBasePolylineVCL;
class DELPHICLASS TPolyline;
class DELPHICLASS TPolylines;
class DELPHICLASS TGMPolyline;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TSymbol : public Gmpolyline::TCustomSymbol
{
	typedef Gmpolyline::TCustomSymbol inherited;
	
private:
	System::Uitypes::TColor FFillColor;
	System::Uitypes::TColor FStrokeColor;
	void __fastcall SetFillColor(const System::Uitypes::TColor Value);
	void __fastcall SetStrokeColor(const System::Uitypes::TColor Value);
	
protected:
	virtual System::UnicodeString __fastcall GetFillColor();
	virtual System::UnicodeString __fastcall GetStrokeColor();
	
public:
	__fastcall virtual TSymbol();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::Uitypes::TColor FillColor = {read=FFillColor, write=SetFillColor, default=255};
	__property System::Uitypes::TColor StrokeColor = {read=FStrokeColor, write=SetStrokeColor, default=255};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TSymbol() { }
	
};


class PASCALIMPLEMENTATION TIconSequence : public Gmpolyline::TCustomIconSequence
{
	typedef Gmpolyline::TCustomIconSequence inherited;
	
private:
	TSymbol* FIcon;
	
protected:
	virtual void __fastcall CreatePropertiesWithColor();
	
public:
	__fastcall virtual ~TIconSequence();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property TSymbol* Icon = {read=FIcon, write=FIcon};
public:
	/* TCustomIconSequence.Create */ inline __fastcall virtual TIconSequence(Gmpolyline::TBasePolyline* aOwner) : Gmpolyline::TCustomIconSequence(aOwner) { }
	
};


class PASCALIMPLEMENTATION TBasePolylineVCL : public Gmpolyline::TBasePolyline
{
	typedef Gmpolyline::TBasePolyline inherited;
	
private:
	System::Uitypes::TColor FStrokeColor;
	void __fastcall SetStrokeColor(const System::Uitypes::TColor Value);
	
protected:
	virtual System::UnicodeString __fastcall GetStrokeColor();
	
public:
	__fastcall virtual TBasePolylineVCL(System::Classes::TCollection* Collection);
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property System::Uitypes::TColor StrokeColor = {read=FStrokeColor, write=SetStrokeColor, default=0};
public:
	/* TBasePolyline.Destroy */ inline __fastcall virtual ~TBasePolylineVCL() { }
	
};


class PASCALIMPLEMENTATION TPolyline : public TBasePolylineVCL
{
	typedef TBasePolylineVCL inherited;
	
private:
	Gmpolyline::TCurveLine* FCurveLine;
	TIconSequence* FIcon;
	void __fastcall OnIconChange(System::TObject* Sender);
	void __fastcall OnCurveLineChange(System::TObject* Sender);
	
protected:
	virtual bool __fastcall ChangeProperties();
	
public:
	__fastcall virtual TPolyline(System::Classes::TCollection* Collection);
	__fastcall virtual ~TPolyline();
	virtual void __fastcall Assign(System::Classes::TPersistent* Source);
	
__published:
	__property TIconSequence* Icon = {read=FIcon, write=FIcon};
	__property Gmpolyline::TCurveLine* CurveLine = {read=FCurveLine, write=FCurveLine};
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TPolylines : public Gmpolyline::TBasePolylines
{
	typedef Gmpolyline::TBasePolylines inherited;
	
public:
	TPolyline* operator[](int I) { return this->Items[I]; }
	
private:
	HIDESBASE void __fastcall SetItems(int I, TPolyline* const Value);
	HIDESBASE TPolyline* __fastcall GetItems(int I);
	
protected:
	DYNAMIC System::Classes::TPersistent* __fastcall GetOwner();
	
public:
	HIDESBASE TPolyline* __fastcall Add();
	HIDESBASE TPolyline* __fastcall Insert(int Index);
	__property TPolyline* Items[int I] = {read=GetItems, write=SetItems/*, default*/};
public:
	/* TLinkedComponents.Create */ inline __fastcall virtual TPolylines(Gmlinkedcomponents::TGMLinkedComponent* GMLinkedComponent, System::Classes::TCollectionItemClass ItemClass) : Gmpolyline::TBasePolylines(GMLinkedComponent, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TPolylines() { }
	
};

#pragma pack(pop)

class PASCALIMPLEMENTATION TGMPolyline : public Gmpolyline::TGMBasePolyline
{
	typedef Gmpolyline::TGMBasePolyline inherited;
	
public:
	TPolyline* operator[](int I) { return this->Items[I]; }
	
private:
	Gmlinkedcomponents::TLinkedComponentChange FOnIconChange;
	Gmlinkedcomponents::TLinkedComponentChange FOnCurveLineChange;
	
protected:
	virtual System::UnicodeString __fastcall GetAPIUrl();
	HIDESBASE TPolyline* __fastcall GetItems(int I);
	virtual Gmlinkedcomponents::TLinkedComponentClass __fastcall GetCollectionItemClass();
	virtual Gmlinkedcomponents::TLinkedComponentsClass __fastcall GetCollectionClass();
	
public:
	HIDESBASE TPolyline* __fastcall Add();
	__property TPolyline* Items[int I] = {read=GetItems/*, default*/};
	
__published:
	__property Gmlinkedcomponents::TLinkedComponentChange OnIconChange = {read=FOnIconChange, write=FOnIconChange};
	__property Gmlinkedcomponents::TLinkedComponentChange OnCurveLineChange = {read=FOnCurveLineChange, write=FOnCurveLineChange};
public:
	/* TGMLinkedComponent.Create */ inline __fastcall virtual TGMPolyline(System::Classes::TComponent* AOwner) : Gmpolyline::TGMBasePolyline(AOwner) { }
	/* TGMLinkedComponent.Destroy */ inline __fastcall virtual ~TGMPolyline() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Gmpolylinevcl */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_GMPOLYLINEVCL)
using namespace Gmpolylinevcl;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// GmpolylinevclHPP
